unsigned char tree0(unsigned char* features, float* result){
    if (features[5] <= 89) {
        if (features[1] <= 70) {
            if (features[5] <= 79) {
                if (features[1] <= 50) {
                    if (features[5] <= 62) {
                        if (features[7] <= 34) {
                            return 2;
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[4] <= 41) {
                            if (features[7] <= 12) {
                                return 3;
                            } else {
                                return 4;

                            }
                        } else {
                            return 2;

                        }

                    }
                } else {
                    if (features[1] <= 59) {
                        if (features[7] <= 57) {
                            if (features[2] <= 54) {
                                if (features[2] <= 33) {
                                    return 1;
                                } else {
                                    return 2;

                                }
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[5] <= 61) {
                                if (features[3] <= 72) {
                                    return 1;
                                } else {
                                    if (features[1] <= 57) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[5] <= 70) {
                                    if (features[3] <= 55) {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 2;

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 75) {
                            if (features[5] <= 75) {
                                if (features[5] <= 69) {
                                    if (features[2] <= 75) {
                                        result[2] = 0.5;

                                        result[3] = 0.5;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[8] <= 79) {
                                        result[0] = 0.2;

                                        result[1] = 0.2;

                                        result[2] = 0.6;

                                        return 255;
                                    } else {
                                        result[0] = 0.875;

                                        result[2] = 0.125;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 78) {
                                    if (features[3] <= 67) {
                                        return 0;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[5] <= 71) {
                                if (features[8] <= 78) {
                                    if (features[3] <= 65) {
                                        return 2;
                                    } else {
                                        result[0] = 0.012345679012345678;

                                        result[1] = 0.9012345679012346;

                                        result[2] = 0.08641975308641975;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 86) {
                                        result[0] = 0.09090909090909091;

                                        result[1] = 0.09090909090909091;

                                        result[2] = 0.8181818181818182;

                                        return 255;
                                    } else {
                                        result[1] = 0.5454545454545454;

                                        result[2] = 0.45454545454545453;

                                        return 255;

                                    }

                                }
                            } else {
                                return 2;

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 82) {
                    if (features[1] <= 59) {
                        if (features[2] <= 58) {
                            return 0;
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[6] <= 66) {
                            return 0;
                        } else {
                            if (features[0] <= 64) {
                                return 0;
                            } else {
                                if (features[7] <= 80) {
                                    if (features[6] <= 72) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }
                } else {
                    return 2;

                }

            }
        } else {
            if (features[2] <= 79) {
                if (features[4] <= 74) {
                    if (features[3] <= 46) {
                        return 3;
                    } else {
                        if (features[1] <= 74) {
                            if (features[3] <= 67) {
                                if (features[8] <= 81) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[3] <= 77) {
                                    if (features[7] <= 74) {
                                        result[0] = 0.46153846153846156;

                                        result[1] = 0.38461538461538464;

                                        result[3] = 0.15384615384615385;

                                        return 255;
                                    } else {
                                        result[0] = 0.2;

                                        result[1] = 0.2;

                                        result[2] = 0.6;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 84) {
                                        result[0] = 0.4444444444444444;

                                        result[1] = 0.4444444444444444;

                                        result[2] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 85) {
                                if (features[2] <= 75) {
                                    if (features[7] <= 76) {
                                        result[0] = 0.7777777777777778;

                                        result[3] = 0.2222222222222222;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[7] <= 74) {
                                        result[1] = 0.16666666666666666;

                                        result[3] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[1] = 0.8;

                                        result[2] = 0.2;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 80) {
                                    if (features[0] <= 83) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= 71) {
                        if (features[0] <= 80) {
                            if (features[6] <= 78) {
                                if (features[2] <= 66) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[1] <= 77) {
                                    return 1;
                                } else {
                                    if (features[6] <= 80) {
                                        return 1;
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 88) {
                                if (features[1] <= 80) {
                                    if (features[3] <= 93) {
                                        result[0] = 0.16666666666666666;

                                        result[1] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[4] <= 80) {
                                        result[0] = 0.7777777777777778;

                                        result[1] = 0.1111111111111111;

                                        result[3] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 81) {
                                    return 3;
                                } else {
                                    if (features[4] <= 91) {
                                        return 2;
                                    } else {
                                        result[0] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 87) {
                            if (features[7] <= 80) {
                                if (features[0] <= 76) {
                                    if (features[0] <= 65) {
                                        return 0;
                                    } else {
                                        result[0] = 0.3157894736842105;

                                        result[1] = 0.6842105263157895;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 84) {
                                        result[0] = 0.25555555555555554;

                                        result[1] = 0.07777777777777778;

                                        result[2] = 0.5;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.5384615384615384;

                                        result[1] = 0.057692307692307696;

                                        result[2] = 0.23076923076923078;

                                        result[3] = 0.1346153846153846;

                                        result[4] = 0.038461538461538464;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 87) {
                                    if (features[8] <= 84) {
                                        result[0] = 0.06896551724137931;

                                        result[1] = 0.3620689655172414;

                                        result[2] = 0.5689655172413793;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[2] <= 51) {
                                        return 0;
                                    } else {
                                        result[0] = 0.06060606060606061;

                                        result[2] = 0.9393939393939394;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 96) {
                                if (features[8] <= 80) {
                                    if (features[8] <= 64) {
                                        result[1] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.6615384615384615;

                                        result[1] = 0.26153846153846155;

                                        result[3] = 0.06153846153846154;

                                        result[4] = 0.015384615384615385;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 86) {
                                        result[0] = 0.5;

                                        result[1] = 0.2222222222222222;

                                        result[2] = 0.2222222222222222;

                                        result[3] = 0.05555555555555555;

                                        return 255;
                                    } else {
                                        result[0] = 0.08333333333333333;

                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.75;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 90) {
                                    return 0;
                                } else {
                                    if (features[7] <= 100) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[7] <= 72) {
                    if (features[1] <= 81) {
                        if (features[0] <= 76) {
                            if (features[8] <= 75) {
                                if (features[6] <= 68) {
                                    return 3;
                                } else {
                                    if (features[2] <= 89) {
                                        return 1;
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[5] <= 81) {
                                    if (features[5] <= 79) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[4] <= 71) {
                                return 3;
                            } else {
                                if (features[8] <= 78) {
                                    return 3;
                                } else {
                                    if (features[7] <= 32) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 20) {
                            if (features[1] <= 84) {
                                return 0;
                            } else {
                                if (features[1] <= 91) {
                                    return 3;
                                } else {
                                    if (features[5] <= 83) {
                                        return 2;
                                    } else {
                                        result[1] = 0.5;

                                        result[3] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 85) {
                                return 3;
                            } else {
                                if (features[1] <= 93) {
                                    if (features[8] <= 89) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 3;

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 87) {
                        if (features[1] <= 80) {
                            if (features[3] <= 70) {
                                if (features[4] <= 68) {
                                    return 1;
                                } else {
                                    if (features[8] <= 83) {
                                        result[0] = 0.9230769230769231;

                                        result[1] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[7] <= 74) {
                                    if (features[1] <= 78) {
                                        return 1;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[3] = 0.8333333333333334;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 87) {
                                        result[0] = 0.34328358208955223;

                                        result[1] = 0.5970149253731343;

                                        result[2] = 0.014925373134328358;

                                        result[3] = 0.029850746268656716;

                                        result[4] = 0.014925373134328358;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }
                        } else {
                            if (features[2] <= 82) {
                                if (features[5] <= 84) {
                                    if (features[8] <= 87) {
                                        result[0] = 0.2222222222222222;

                                        result[1] = 0.6;

                                        result[2] = 0.06666666666666667;

                                        result[3] = 0.044444444444444446;

                                        result[4] = 0.06666666666666667;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[6] <= 86) {
                                        return 2;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.16666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 83) {
                                    if (features[0] <= 77) {
                                        result[0] = 0.4230769230769231;

                                        result[1] = 0.4230769230769231;

                                        result[3] = 0.07692307692307693;

                                        result[4] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        result[0] = 0.025396825396825397;

                                        result[1] = 0.12698412698412698;

                                        result[2] = 0.047619047619047616;

                                        result[3] = 0.580952380952381;

                                        result[4] = 0.21904761904761905;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 84) {
                                        result[0] = 0.7777777777777778;

                                        result[1] = 0.1111111111111111;

                                        result[4] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        result[0] = 0.043478260869565216;

                                        result[1] = 0.24347826086956523;

                                        result[2] = 0.034782608695652174;

                                        result[3] = 0.4260869565217391;

                                        result[4] = 0.25217391304347825;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 87) {
                            if (features[6] <= 73) {
                                return 3;
                            } else {
                                if (features[5] <= 87) {
                                    if (features[2] <= 89) {
                                        result[0] = 0.014285714285714285;

                                        result[1] = 0.1;

                                        result[2] = 0.8571428571428571;

                                        result[4] = 0.02857142857142857;

                                        return 255;
                                    } else {
                                        result[0] = 0.1;

                                        result[1] = 0.2;

                                        result[2] = 0.6;

                                        result[4] = 0.1;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 84) {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.27906976744186046;

                                        result[2] = 0.7209302325581395;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 90) {
                                if (features[7] <= 91) {
                                    if (features[6] <= 88) {
                                        result[0] = 0.17391304347826086;

                                        result[1] = 0.30434782608695654;

                                        result[3] = 0.2608695652173913;

                                        result[4] = 0.2608695652173913;

                                        return 255;
                                    } else {
                                        result[0] = 0.07865168539325842;

                                        result[1] = 0.797752808988764;

                                        result[2] = 0.0449438202247191;

                                        result[3] = 0.011235955056179775;

                                        result[4] = 0.06741573033707865;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 93) {
                                        result[0] = 0.08695652173913043;

                                        result[1] = 0.43478260869565216;

                                        result[2] = 0.2391304347826087;

                                        result[3] = 0.021739130434782608;

                                        result[4] = 0.21739130434782608;

                                        return 255;
                                    } else {
                                        result[0] = 0.15384615384615385;

                                        result[1] = 0.15384615384615385;

                                        result[2] = 0.6923076923076923;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 94) {
                                    if (features[5] <= 85) {
                                        result[0] = 0.12121212121212122;

                                        result[1] = 0.18181818181818182;

                                        result[2] = 0.2727272727272727;

                                        result[3] = 0.09090909090909091;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.019230769230769232;

                                        result[1] = 0.038461538461538464;

                                        result[2] = 0.019230769230769232;

                                        result[3] = 0.38461538461538464;

                                        result[4] = 0.5384615384615384;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 49) {
                                        result[2] = 0.36363636363636365;

                                        result[3] = 0.6363636363636364;

                                        return 255;
                                    } else {
                                        result[0] = 0.061224489795918366;

                                        result[1] = 0.5918367346938775;

                                        result[2] = 0.04081632653061224;

                                        result[3] = 0.030612244897959183;

                                        result[4] = 0.2755102040816326;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[0] <= 78) {
            if (features[3] <= 92) {
                if (features[3] <= 79) {
                    if (features[2] <= 85) {
                        if (features[0] <= 67) {
                            return 0;
                        } else {
                            return 2;

                        }
                    } else {
                        return 0;

                    }
                } else {
                    if (features[1] <= 89) {
                        if (features[5] <= 92) {
                            return 0;
                        } else {
                            if (features[0] <= 71) {
                                return 0;
                            } else {
                                if (features[7] <= 90) {
                                    if (features[0] <= 73) {
                                        return 0;
                                    } else {
                                        result[0] = 0.2;

                                        result[1] = 0.8;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 89) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 83) {
                            return 1;
                        } else {
                            if (features[7] <= 93) {
                                return 0;
                            } else {
                                return 2;

                            }

                        }

                    }

                }
            } else {
                if (features[7] <= 88) {
                    if (features[7] <= 15) {
                        return 3;
                    } else {
                        return 0;

                    }
                } else {
                    if (features[8] <= 87) {
                        return 2;
                    } else {
                        if (features[2] <= 95) {
                            return 4;
                        } else {
                            return 1;

                        }

                    }

                }

            }
        } else {
            if (features[3] <= 86) {
                if (features[1] <= 92) {
                    if (features[1] <= 88) {
                        if (features[5] <= 96) {
                            if (features[6] <= 65) {
                                return 3;
                            } else {
                                if (features[6] <= 79) {
                                    if (features[5] <= 92) {
                                        result[0] = 0.14285714285714285;

                                        result[4] = 0.8571428571428571;

                                        return 255;
                                    } else {
                                        result[0] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 89) {
                                        result[0] = 0.8375;

                                        result[1] = 0.1125;

                                        result[4] = 0.05;

                                        return 255;
                                    } else {
                                        result[0] = 0.6296296296296297;

                                        result[1] = 0.1111111111111111;

                                        result[2] = 0.25925925925925924;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 99) {
                                if (features[2] <= 95) {
                                    if (features[1] <= 84) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[1] <= 83) {
                                        return 3;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[7] <= 52) {
                                    return 2;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[4] <= 90) {
                            if (features[0] <= 86) {
                                if (features[1] <= 91) {
                                    if (features[6] <= 88) {
                                        result[1] = 0.19047619047619047;

                                        result[4] = 0.8095238095238095;

                                        return 255;
                                    } else {
                                        result[1] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[6] <= 83) {
                                    if (features[7] <= 80) {
                                        result[1] = 0.1;

                                        result[3] = 0.7;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[0] <= 89) {
                                        return 0;
                                    } else {
                                        return 3;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 89) {
                                if (features[3] <= 81) {
                                    if (features[6] <= 59) {
                                        return 0;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[4] <= 94) {
                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[4] <= 97) {
                                    if (features[7] <= 96) {
                                        result[0] = 0.9230769230769231;

                                        result[1] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[5] <= 99) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 87) {
                        if (features[5] <= 98) {
                            if (features[6] <= 85) {
                                if (features[0] <= 91) {
                                    if (features[0] <= 89) {
                                        return 4;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 4;

                            }
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[4] <= 81) {
                            if (features[2] <= 88) {
                                return 2;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[4] <= 89) {
                                if (features[6] <= 95) {
                                    if (features[4] <= 86) {
                                        result[3] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.07142857142857142;

                                        result[1] = 0.07142857142857142;

                                        result[4] = 0.8571428571428571;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 98) {
                                        return 1;
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[7] <= 93) {
                                    if (features[1] <= 100) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[2] <= 96) {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 90) {
                    if (features[2] <= 91) {
                        if (features[6] <= 94) {
                            if (features[7] <= 92) {
                                if (features[4] <= 91) {
                                    if (features[8] <= 91) {
                                        result[1] = 0.14285714285714285;

                                        result[2] = 0.10714285714285714;

                                        result[3] = 0.6071428571428571;

                                        result[4] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        result[0] = 0.38461538461538464;

                                        result[2] = 0.38461538461538464;

                                        result[3] = 0.07692307692307693;

                                        result[4] = 0.15384615384615385;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 91) {
                                        result[0] = 0.09090909090909091;

                                        result[3] = 0.09090909090909091;

                                        result[4] = 0.8181818181818182;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[4] <= 99) {
                                    return 2;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[5] <= 97) {
                                if (features[7] <= 24) {
                                    return 3;
                                } else {
                                    if (features[8] <= 98) {
                                        result[2] = 0.9411764705882353;

                                        result[4] = 0.058823529411764705;

                                        return 255;
                                    } else {
                                        result[0] = 0.4;

                                        result[2] = 0.6;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 88) {
                                    return 0;
                                } else {
                                    if (features[3] <= 100) {
                                        return 2;
                                    } else {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 88) {
                            if (features[0] <= 87) {
                                if (features[0] <= 83) {
                                    return 1;
                                } else {
                                    if (features[6] <= 91) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[0] <= 90) {
                                    if (features[6] <= 86) {
                                        result[0] = 0.07692307692307693;

                                        result[4] = 0.9230769230769231;

                                        return 255;
                                    } else {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.14285714285714285;

                                        result[4] = 0.42857142857142855;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[0] <= 88) {
                                if (features[1] <= 86) {
                                    if (features[2] <= 99) {
                                        return 2;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 93) {
                                        result[0] = 0.7142857142857143;

                                        result[1] = 0.047619047619047616;

                                        result[2] = 0.047619047619047616;

                                        result[4] = 0.19047619047619047;

                                        return 255;
                                    } else {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.09523809523809523;

                                        result[2] = 0.42857142857142855;

                                        result[4] = 0.047619047619047616;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 92) {
                                    if (features[5] <= 96) {
                                        result[1] = 0.21428571428571427;

                                        result[3] = 0.14285714285714285;

                                        result[4] = 0.6428571428571429;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[6] <= 91) {
                                        result[0] = 0.8571428571428571;

                                        result[1] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[2] <= 90) {
                        if (features[3] <= 92) {
                            if (features[8] <= 90) {
                                if (features[1] <= 90) {
                                    if (features[1] <= 89) {
                                        return 3;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[6] <= 99) {
                                    if (features[1] <= 90) {
                                        return 2;
                                    } else {
                                        result[2] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[1] <= 100) {
                                if (features[0] <= 95) {
                                    if (features[0] <= 93) {
                                        result[1] = 0.5;

                                        result[2] = 0.08333333333333333;

                                        result[3] = 0.25;

                                        result[4] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[2] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 94) {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.2222222222222222;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.038461538461538464;

                                        result[1] = 0.7692307692307693;

                                        result[2] = 0.07692307692307693;

                                        result[4] = 0.11538461538461539;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 96) {
                                    if (features[2] <= 81) {
                                        return 2;
                                    } else {
                                        result[1] = 0.18181818181818182;

                                        result[4] = 0.8181818181818182;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 98) {
                                        return 1;
                                    } else {
                                        result[1] = 0.2;

                                        result[2] = 0.8;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 96) {
                            if (features[2] <= 96) {
                                if (features[5] <= 92) {
                                    if (features[8] <= 89) {
                                        result[1] = 0.12;

                                        result[3] = 0.5733333333333334;

                                        result[4] = 0.30666666666666664;

                                        return 255;
                                    } else {
                                        result[0] = 0.009523809523809525;

                                        result[1] = 0.10476190476190476;

                                        result[2] = 0.05714285714285714;

                                        result[3] = 0.11428571428571428;

                                        result[4] = 0.7142857142857143;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 91) {
                                        result[0] = 0.08333333333333333;

                                        result[1] = 0.08333333333333333;

                                        result[2] = 0.5;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.0410958904109589;

                                        result[1] = 0.0365296803652968;

                                        result[2] = 0.1050228310502283;

                                        result[3] = 0.1689497716894977;

                                        result[4] = 0.6484018264840182;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[4] <= 76) {
                                    if (features[5] <= 94) {
                                        return 3;
                                    } else {
                                        result[2] = 0.3333333333333333;

                                        result[3] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 97) {
                                        result[0] = 0.05454545454545454;

                                        result[1] = 0.07272727272727272;

                                        result[2] = 0.045454545454545456;

                                        result[3] = 0.32727272727272727;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.1;

                                        result[1] = 0.3;

                                        result[2] = 0.05;

                                        result[3] = 0.4;

                                        result[4] = 0.15;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 98) {
                                if (features[1] <= 96) {
                                    if (features[3] <= 95) {
                                        result[0] = 0.4576271186440678;

                                        result[1] = 0.03389830508474576;

                                        result[2] = 0.0847457627118644;

                                        result[3] = 0.13559322033898305;

                                        result[4] = 0.288135593220339;

                                        return 255;
                                    } else {
                                        result[1] = 0.34615384615384615;

                                        result[2] = 0.3076923076923077;

                                        result[3] = 0.11538461538461539;

                                        result[4] = 0.23076923076923078;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 96) {
                                        result[0] = 0.047619047619047616;

                                        result[1] = 0.015873015873015872;

                                        result[2] = 0.015873015873015872;

                                        result[3] = 0.1746031746031746;

                                        result[4] = 0.746031746031746;

                                        return 255;
                                    } else {
                                        result[0] = 0.3269230769230769;

                                        result[1] = 0.057692307692307696;

                                        result[2] = 0.23076923076923078;

                                        result[3] = 0.1346153846153846;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[2] <= 98) {
                                    if (features[3] <= 99) {
                                        result[1] = 0.25;

                                        result[2] = 0.5;

                                        result[3] = 0.125;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[0] = 0.043478260869565216;

                                        result[1] = 0.1956521739130435;

                                        result[2] = 0.10869565217391304;

                                        result[3] = 0.17391304347826086;

                                        result[4] = 0.4782608695652174;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 98) {
                                        result[0] = 0.375;

                                        result[1] = 0.1875;

                                        result[2] = 0.25;

                                        result[4] = 0.1875;

                                        return 255;
                                    } else {
                                        result[0] = 0.0875;

                                        result[1] = 0.0875;

                                        result[2] = 0.2375;

                                        result[3] = 0.4375;

                                        result[4] = 0.15;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree1(unsigned char* features, float* result){
    if (features[7] <= 88) {
        if (features[2] <= 73) {
            if (features[3] <= 84) {
                if (features[6] <= 78) {
                    if (features[8] <= 57) {
                        if (features[7] <= 53) {
                            return 3;
                        } else {
                            if (features[3] <= 69) {
                                return 2;
                            } else {
                                if (features[6] <= 77) {
                                    return 3;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 53) {
                            if (features[0] <= 17) {
                                return 3;
                            } else {
                                if (features[0] <= 67) {
                                    return 2;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[8] <= 75) {
                                if (features[0] <= 80) {
                                    if (features[0] <= 65) {
                                        result[1] = 0.2857142857142857;

                                        result[2] = 0.5714285714285714;

                                        result[3] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        result[0] = 0.5161290322580645;

                                        result[1] = 0.45161290322580644;

                                        result[3] = 0.03225806451612903;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 73) {
                                        result[0] = 0.875;

                                        result[3] = 0.125;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[6] <= 73) {
                                    if (features[3] <= 77) {
                                        result[0] = 0.6538461538461539;

                                        result[2] = 0.34615384615384615;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[0] <= 64) {
                                        result[0] = 0.0625;

                                        result[2] = 0.9375;

                                        return 255;
                                    } else {
                                        result[1] = 0.38461538461538464;

                                        result[2] = 0.6153846153846154;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 68) {
                        if (features[3] <= 66) {
                            return 2;
                        } else {
                            if (features[6] <= 81) {
                                if (features[6] <= 80) {
                                    return 0;
                                } else {
                                    return 1;

                                }
                            } else {
                                return 1;

                            }

                        }
                    } else {
                        if (features[0] <= 66) {
                            if (features[8] <= 98) {
                                if (features[4] <= 65) {
                                    return 1;
                                } else {
                                    if (features[2] <= 57) {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.021739130434782608;

                                        result[2] = 0.9782608695652174;

                                        return 255;

                                    }

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[3] <= 80) {
                                if (features[8] <= 73) {
                                    if (features[8] <= 69) {
                                        return 1;
                                    } else {
                                        result[0] = 0.6875;

                                        result[1] = 0.125;

                                        result[2] = 0.1875;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 60) {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        result[1] = 0.07142857142857142;

                                        result[2] = 0.9285714285714286;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 67) {
                                    return 1;
                                } else {
                                    if (features[0] <= 81) {
                                        result[0] = 0.0625;

                                        result[1] = 0.25;

                                        result[2] = 0.625;

                                        result[3] = 0.0625;

                                        return 255;
                                    } else {
                                        result[1] = 0.7692307692307693;

                                        result[2] = 0.23076923076923078;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[3] <= 93) {
                    if (features[5] <= 73) {
                        if (features[2] <= 67) {
                            if (features[7] <= 65) {
                                return 2;
                            } else {
                                if (features[1] <= 93) {
                                    if (features[1] <= 76) {
                                        return 1;
                                    } else {
                                        result[0] = 0.15384615384615385;

                                        result[1] = 0.8461538461538461;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[3] <= 85) {
                                return 1;
                            } else {
                                if (features[6] <= 82) {
                                    return 0;
                                } else {
                                    if (features[5] <= 64) {
                                        return 1;
                                    } else {
                                        result[0] = 0.3684210526315789;

                                        result[1] = 0.5789473684210527;

                                        result[2] = 0.05263157894736842;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[8] <= 76) {
                            if (features[5] <= 92) {
                                if (features[4] <= 80) {
                                    if (features[1] <= 84) {
                                        return 0;
                                    } else {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[5] <= 79) {
                                if (features[7] <= 79) {
                                    if (features[4] <= 79) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[7] <= 82) {
                                        return 2;
                                    } else {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[2] <= 34) {
                                    return 3;
                                } else {
                                    if (features[7] <= 82) {
                                        result[0] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 81) {
                        if (features[1] <= 77) {
                            if (features[1] <= 56) {
                                return 2;
                            } else {
                                if (features[5] <= 77) {
                                    return 1;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[0] <= 95) {
                            if (features[8] <= 85) {
                                return 1;
                            } else {
                                return 2;

                            }
                        } else {
                            return 1;

                        }

                    }

                }

            }
        } else {
            if (features[2] <= 87) {
                if (features[8] <= 78) {
                    if (features[2] <= 77) {
                        if (features[0] <= 79) {
                            if (features[6] <= 71) {
                                if (features[0] <= 75) {
                                    if (features[3] <= 68) {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.1111111111111111;

                                        result[3] = 0.2222222222222222;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[7] <= 22) {
                                        return 0;
                                    } else {
                                        result[1] = 0.1;

                                        result[3] = 0.9;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 69) {
                                    if (features[7] <= 75) {
                                        return 3;
                                    } else {
                                        result[0] = 0.4;

                                        result[1] = 0.6;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 67) {
                                        return 1;
                                    } else {
                                        result[1] = 0.13333333333333333;

                                        result[2] = 0.8;

                                        result[3] = 0.06666666666666667;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 87) {
                                if (features[8] <= 67) {
                                    return 3;
                                } else {
                                    if (features[6] <= 84) {
                                        result[0] = 0.8275862068965517;

                                        result[2] = 0.10344827586206896;

                                        result[3] = 0.06896551724137931;

                                        return 255;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.375;

                                        result[2] = 0.375;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[2] <= 75) {
                                    return 1;
                                } else {
                                    if (features[0] <= 83) {
                                        return 1;
                                    } else {
                                        result[0] = 0.5294117647058824;

                                        result[1] = 0.29411764705882354;

                                        result[2] = 0.058823529411764705;

                                        result[4] = 0.11764705882352941;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 77) {
                            if (features[0] <= 85) {
                                if (features[0] <= 74) {
                                    if (features[7] <= 67) {
                                        result[0] = 0.14285714285714285;

                                        result[3] = 0.8571428571428571;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[7] <= 68) {
                                        return 3;
                                    } else {
                                        result[0] = 0.01818181818181818;

                                        result[1] = 0.21818181818181817;

                                        result[2] = 0.07272727272727272;

                                        result[3] = 0.6909090909090909;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 72) {
                                    if (features[2] <= 80) {
                                        result[0] = 0.07692307692307693;

                                        result[3] = 0.9230769230769231;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[2] <= 81) {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[3] = 0.8333333333333334;

                                        result[4] = 0.16666666666666666;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 83) {
                                if (features[1] <= 80) {
                                    if (features[7] <= 78) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[3] <= 86) {
                                        result[1] = 0.8;

                                        result[2] = 0.2;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 86) {
                                    if (features[1] <= 88) {
                                        result[1] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 89) {
                                        return 2;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 76) {
                        if (features[7] <= 81) {
                            if (features[6] <= 78) {
                                if (features[5] <= 61) {
                                    return 2;
                                } else {
                                    if (features[3] <= 76) {
                                        result[0] = 0.9313725490196079;

                                        result[1] = 0.058823529411764705;

                                        result[2] = 0.00980392156862745;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[5] <= 85) {
                                    if (features[4] <= 75) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[2] <= 78) {
                                if (features[4] <= 76) {
                                    if (features[5] <= 80) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[5] <= 77) {
                                        return 2;
                                    } else {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 73) {
                                    return 0;
                                } else {
                                    if (features[8] <= 88) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[2] <= 81) {
                            if (features[0] <= 82) {
                                if (features[2] <= 79) {
                                    if (features[3] <= 79) {
                                        result[0] = 0.3157894736842105;

                                        result[1] = 0.42105263157894735;

                                        result[2] = 0.05263157894736842;

                                        result[3] = 0.21052631578947367;

                                        return 255;
                                    } else {
                                        result[0] = 0.05405405405405406;

                                        result[1] = 0.13513513513513514;

                                        result[2] = 0.8108108108108109;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 83) {
                                        result[0] = 0.21428571428571427;

                                        result[1] = 0.7142857142857143;

                                        result[3] = 0.07142857142857142;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[0] <= 89) {
                                    if (features[7] <= 84) {
                                        result[0] = 0.45454545454545453;

                                        result[1] = 0.09090909090909091;

                                        result[2] = 0.3181818181818182;

                                        result[3] = 0.045454545454545456;

                                        result[4] = 0.09090909090909091;

                                        return 255;
                                    } else {
                                        result[1] = 0.6190476190476191;

                                        result[2] = 0.38095238095238093;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 82) {
                                        result[0] = 0.2;

                                        result[3] = 0.8;

                                        return 255;
                                    } else {
                                        result[0] = 0.4722222222222222;

                                        result[1] = 0.4722222222222222;

                                        result[2] = 0.05555555555555555;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 89) {
                                if (features[3] <= 79) {
                                    if (features[0] <= 70) {
                                        return 0;
                                    } else {
                                        result[0] = 0.29411764705882354;

                                        result[1] = 0.5882352941176471;

                                        result[3] = 0.058823529411764705;

                                        result[4] = 0.058823529411764705;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 84) {
                                        result[0] = 0.23076923076923078;

                                        result[1] = 0.23076923076923078;

                                        result[2] = 0.38461538461538464;

                                        result[3] = 0.07692307692307693;

                                        result[4] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        result[0] = 0.10434782608695652;

                                        result[1] = 0.3391304347826087;

                                        result[2] = 0.06956521739130435;

                                        result[3] = 0.2782608695652174;

                                        result[4] = 0.20869565217391303;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[4] <= 58) {
                                    return 3;
                                } else {
                                    if (features[4] <= 87) {
                                        return 0;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[1] <= 77) {
                    if (features[4] <= 20) {
                        return 3;
                    } else {
                        if (features[5] <= 79) {
                            if (features[0] <= 72) {
                                return 0;
                            } else {
                                if (features[1] <= 76) {
                                    return 1;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[3] <= 66) {
                                return 0;
                            } else {
                                if (features[7] <= 77) {
                                    if (features[0] <= 69) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 93) {
                        if (features[1] <= 82) {
                            if (features[8] <= 85) {
                                if (features[3] <= 75) {
                                    return 3;
                                } else {
                                    if (features[0] <= 78) {
                                        result[0] = 0.625;

                                        result[1] = 0.25;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[0] = 0.043478260869565216;

                                        result[1] = 0.43478260869565216;

                                        result[3] = 0.391304347826087;

                                        result[4] = 0.13043478260869565;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[4] <= 81) {
                                    return 0;
                                } else {
                                    if (features[2] <= 97) {
                                        result[0] = 0.6428571428571429;

                                        result[1] = 0.2857142857142857;

                                        result[3] = 0.07142857142857142;

                                        return 255;
                                    } else {
                                        result[1] = 0.75;

                                        result[2] = 0.25;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 80) {
                                if (features[0] <= 80) {
                                    if (features[1] <= 86) {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.2222222222222222;

                                        result[3] = 0.2222222222222222;

                                        result[4] = 0.4444444444444444;

                                        return 255;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.14285714285714285;

                                        result[3] = 0.7142857142857143;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 87) {
                                        result[0] = 0.05172413793103448;

                                        result[1] = 0.06896551724137931;

                                        result[3] = 0.5172413793103449;

                                        result[4] = 0.3620689655172414;

                                        return 255;
                                    } else {
                                        result[1] = 0.005988023952095809;

                                        result[2] = 0.011976047904191617;

                                        result[3] = 0.8622754491017964;

                                        result[4] = 0.11976047904191617;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 96) {
                                    if (features[3] <= 80) {
                                        result[0] = 0.4473684210526316;

                                        result[1] = 0.07894736842105263;

                                        result[3] = 0.02631578947368421;

                                        result[4] = 0.4473684210526316;

                                        return 255;
                                    } else {
                                        result[0] = 0.005208333333333333;

                                        result[1] = 0.16666666666666666;

                                        result[3] = 0.4479166666666667;

                                        result[4] = 0.3802083333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 100) {
                                        return 1;
                                    } else {
                                        result[1] = 0.125;

                                        result[4] = 0.875;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 42) {
                            if (features[4] <= 90) {
                                return 3;
                            } else {
                                if (features[0] <= 64) {
                                    return 3;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[0] <= 74) {
                                return 0;
                            } else {
                                if (features[8] <= 99) {
                                    if (features[3] <= 83) {
                                        result[0] = 0.8888888888888888;

                                        result[1] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        result[0] = 0.18181818181818182;

                                        result[1] = 0.18181818181818182;

                                        result[3] = 0.18181818181818182;

                                        result[4] = 0.45454545454545453;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 85) {
                                        result[0] = 0.16666666666666666;

                                        result[1] = 0.6666666666666666;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.1;

                                        result[1] = 0.1;

                                        result[2] = 0.1;

                                        result[3] = 0.4;

                                        result[4] = 0.3;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[0] <= 83) {
            if (features[7] <= 90) {
                if (features[5] <= 78) {
                    return 2;
                } else {
                    if (features[7] <= 88) {
                        if (features[2] <= 86) {
                            if (features[0] <= 80) {
                                return 0;
                            } else {
                                if (features[4] <= 84) {
                                    if (features[2] <= 78) {
                                        return 2;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[8] <= 90) {
                                if (features[6] <= 86) {
                                    if (features[1] <= 82) {
                                        result[0] = 0.8571428571428571;

                                        result[1] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[1] <= 89) {
                                    return 0;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 86) {
                            return 2;
                        } else {
                            if (features[4] <= 84) {
                                return 1;
                            } else {
                                if (features[6] <= 87) {
                                    if (features[2] <= 96) {
                                        result[0] = 0.9333333333333333;

                                        result[1] = 0.06666666666666667;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[5] <= 92) {
                                        return 2;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 83) {
                    if (features[8] <= 88) {
                        if (features[1] <= 84) {
                            return 2;
                        } else {
                            return 1;

                        }
                    } else {
                        return 0;

                    }
                } else {
                    if (features[5] <= 94) {
                        if (features[6] <= 98) {
                            if (features[8] <= 98) {
                                if (features[7] <= 92) {
                                    if (features[2] <= 95) {
                                        result[1] = 0.030303030303030304;

                                        result[2] = 0.9696969696969697;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[5] <= 18) {
                                    return 2;
                                } else {
                                    if (features[7] <= 96) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 67) {
                                if (features[8] <= 90) {
                                    return 1;
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[4] <= 73) {
                                    return 0;
                                } else {
                                    if (features[7] <= 95) {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 97) {
                            if (features[1] <= 91) {
                                if (features[2] <= 81) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[1] <= 58) {
                                return 4;
                            } else {
                                if (features[2] <= 85) {
                                    return 2;
                                } else {
                                    if (features[8] <= 98) {
                                        result[1] = 0.8333333333333334;

                                        result[4] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[2] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[5] <= 6) {
                if (features[6] <= 60) {
                    return 2;
                } else {
                    if (features[1] <= 93) {
                        return 2;
                    } else {
                        if (features[3] <= 92) {
                            if (features[4] <= 92) {
                                return 2;
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[2] <= 89) {
                                if (features[3] <= 99) {
                                    return 3;
                                } else {
                                    return 2;

                                }
                            } else {
                                return 3;

                            }

                        }

                    }

                }
            } else {
                if (features[7] <= 92) {
                    if (features[0] <= 90) {
                        if (features[8] <= 92) {
                            if (features[1] <= 87) {
                                if (features[0] <= 88) {
                                    if (features[5] <= 87) {
                                        result[1] = 0.1111111111111111;

                                        result[2] = 0.8611111111111112;

                                        result[3] = 0.027777777777777776;

                                        return 255;
                                    } else {
                                        result[0] = 0.29411764705882354;

                                        result[1] = 0.17647058823529413;

                                        result[2] = 0.4117647058823529;

                                        result[4] = 0.11764705882352941;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 77) {
                                        result[0] = 0.2;

                                        result[1] = 0.2;

                                        result[2] = 0.6;

                                        return 255;
                                    } else {
                                        result[1] = 0.875;

                                        result[2] = 0.125;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 88) {
                                    if (features[4] <= 88) {
                                        result[1] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.8181818181818182;

                                        result[1] = 0.18181818181818182;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 89) {
                                        result[0] = 0.05555555555555555;

                                        result[1] = 0.42592592592592593;

                                        result[2] = 0.14814814814814814;

                                        result[3] = 0.12962962962962962;

                                        result[4] = 0.24074074074074073;

                                        return 255;
                                    } else {
                                        result[0] = 0.13636363636363635;

                                        result[1] = 0.18181818181818182;

                                        result[2] = 0.09090909090909091;

                                        result[4] = 0.5909090909090909;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 90) {
                                if (features[1] <= 93) {
                                    if (features[1] <= 91) {
                                        result[0] = 0.921875;

                                        result[1] = 0.015625;

                                        result[2] = 0.015625;

                                        result[4] = 0.046875;

                                        return 255;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.125;

                                        result[4] = 0.625;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 96) {
                                        return 4;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.25;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 91) {
                                    if (features[4] <= 93) {
                                        result[0] = 0.875;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 92) {
                                        result[0] = 0.5294117647058824;

                                        result[1] = 0.17647058823529413;

                                        result[2] = 0.058823529411764705;

                                        result[4] = 0.23529411764705882;

                                        return 255;
                                    } else {
                                        result[0] = 0.20833333333333334;

                                        result[1] = 0.020833333333333332;

                                        result[2] = 0.5833333333333334;

                                        result[4] = 0.1875;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[8] <= 87) {
                            if (features[6] <= 89) {
                                if (features[7] <= 92) {
                                    if (features[5] <= 100) {
                                        result[0] = 0.08333333333333333;

                                        result[3] = 0.08333333333333333;

                                        result[4] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[2] = 0.5;

                                        result[3] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[8] <= 83) {
                                    if (features[6] <= 92) {
                                        result[1] = 0.7;

                                        result[4] = 0.3;

                                        return 255;
                                    } else {
                                        result[0] = 0.6875;

                                        result[1] = 0.25;

                                        result[4] = 0.0625;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 84) {
                                        result[0] = 0.06;

                                        result[1] = 0.88;

                                        result[3] = 0.02;

                                        result[4] = 0.04;

                                        return 255;
                                    } else {
                                        result[0] = 0.11363636363636363;

                                        result[1] = 0.5909090909090909;

                                        result[2] = 0.022727272727272728;

                                        result[3] = 0.045454545454545456;

                                        result[4] = 0.22727272727272727;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 90) {
                                if (features[7] <= 89) {
                                    if (features[1] <= 91) {
                                        result[0] = 0.15384615384615385;

                                        result[1] = 0.5384615384615384;

                                        result[3] = 0.07692307692307693;

                                        result[4] = 0.23076923076923078;

                                        return 255;
                                    } else {
                                        result[0] = 0.01098901098901099;

                                        result[1] = 0.03296703296703297;

                                        result[2] = 0.02197802197802198;

                                        result[3] = 0.5714285714285714;

                                        result[4] = 0.3626373626373626;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 90) {
                                        result[0] = 0.02127659574468085;

                                        result[1] = 0.40425531914893614;

                                        result[2] = 0.02127659574468085;

                                        result[3] = 0.10638297872340426;

                                        result[4] = 0.44680851063829785;

                                        return 255;
                                    } else {
                                        result[0] = 0.034482758620689655;

                                        result[1] = 0.20689655172413793;

                                        result[2] = 0.20689655172413793;

                                        result[3] = 0.29310344827586204;

                                        result[4] = 0.25862068965517243;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 86) {
                                    if (features[5] <= 46) {
                                        return 0;
                                    } else {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 90) {
                                        result[0] = 0.11594202898550725;

                                        result[1] = 0.014492753623188406;

                                        result[3] = 0.11594202898550725;

                                        result[4] = 0.7536231884057971;

                                        return 255;
                                    } else {
                                        result[0] = 0.06;

                                        result[1] = 0.16;

                                        result[2] = 0.013333333333333334;

                                        result[3] = 0.2;

                                        result[4] = 0.5666666666666667;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= 92) {
                        if (features[1] <= 93) {
                            if (features[1] <= 85) {
                                if (features[5] <= 99) {
                                    return 2;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[1] <= 91) {
                                    if (features[7] <= 100) {
                                        result[0] = 0.021739130434782608;

                                        result[2] = 0.8478260869565217;

                                        result[4] = 0.13043478260869565;

                                        return 255;
                                    } else {
                                        result[1] = 0.4;

                                        result[2] = 0.4;

                                        result[3] = 0.1;

                                        result[4] = 0.1;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 93) {
                                        result[0] = 0.2727272727272727;

                                        result[1] = 0.06060606060606061;

                                        result[2] = 0.2727272727272727;

                                        result[3] = 0.06060606060606061;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.07692307692307693;

                                        result[2] = 0.7692307692307693;

                                        result[4] = 0.15384615384615385;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 94) {
                                if (features[4] <= 95) {
                                    if (features[1] <= 95) {
                                        return 0;
                                    } else {
                                        result[0] = 0.26666666666666666;

                                        result[1] = 0.13333333333333333;

                                        result[4] = 0.6;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 95) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[1] <= 96) {
                                    if (features[2] <= 98) {
                                        result[0] = 0.07142857142857142;

                                        result[1] = 0.07142857142857142;

                                        result[2] = 0.21428571428571427;

                                        result[4] = 0.6428571428571429;

                                        return 255;
                                    } else {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 94) {
                                        result[0] = 0.1;

                                        result[2] = 0.8;

                                        result[3] = 0.1;

                                        return 255;
                                    } else {
                                        result[0] = 0.5555555555555556;

                                        result[2] = 0.3333333333333333;

                                        result[3] = 0.1111111111111111;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 98) {
                            if (features[6] <= 94) {
                                if (features[5] <= 97) {
                                    if (features[5] <= 87) {
                                        result[0] = 0.2;

                                        result[1] = 0.4;

                                        result[2] = 0.2;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        result[1] = 0.03571428571428571;

                                        result[2] = 0.03571428571428571;

                                        result[3] = 0.32142857142857145;

                                        result[4] = 0.6071428571428571;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 100) {
                                        result[0] = 0.45454545454545453;

                                        result[1] = 0.030303030303030304;

                                        result[3] = 0.24242424242424243;

                                        result[4] = 0.2727272727272727;

                                        return 255;
                                    } else {
                                        result[0] = 0.04;

                                        result[1] = 0.04;

                                        result[3] = 0.04;

                                        result[4] = 0.88;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 97) {
                                    if (features[6] <= 95) {
                                        result[1] = 0.1111111111111111;

                                        result[3] = 0.6666666666666666;

                                        result[4] = 0.2222222222222222;

                                        return 255;
                                    } else {
                                        result[0] = 0.014705882352941176;

                                        result[1] = 0.08823529411764706;

                                        result[2] = 0.07352941176470588;

                                        result[3] = 0.11764705882352941;

                                        result[4] = 0.7058823529411765;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 96) {
                                        result[0] = 0.15492957746478872;

                                        result[1] = 0.38028169014084506;

                                        result[2] = 0.04225352112676056;

                                        result[3] = 0.1267605633802817;

                                        result[4] = 0.29577464788732394;

                                        return 255;
                                    } else {
                                        result[0] = 0.046153846153846156;

                                        result[1] = 0.2;

                                        result[2] = 0.07692307692307693;

                                        result[3] = 0.07692307692307693;

                                        result[4] = 0.6;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 99) {
                                if (features[4] <= 35) {
                                    if (features[2] <= 96) {
                                        return 2;
                                    } else {
                                        result[2] = 0.25;

                                        result[3] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 99) {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.08888888888888889;

                                        result[2] = 0.4444444444444444;

                                        result[3] = 0.1111111111111111;

                                        result[4] = 0.24444444444444444;

                                        return 255;
                                    } else {
                                        result[0] = 0.08;

                                        result[1] = 0.22;

                                        result[2] = 0.13;

                                        result[3] = 0.14;

                                        result[4] = 0.43;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 98) {
                                    if (features[4] <= 97) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.3333333333333333;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.21428571428571427;

                                        result[3] = 0.21428571428571427;

                                        result[4] = 0.5714285714285714;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 93) {
                                        return 0;
                                    } else {
                                        result[0] = 0.09090909090909091;

                                        result[1] = 0.2159090909090909;

                                        result[2] = 0.3181818181818182;

                                        result[3] = 0.29545454545454547;

                                        result[4] = 0.07954545454545454;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree2(unsigned char* features, float* result){
    if (features[8] <= 89) {
        if (features[1] <= 92) {
            if (features[3] <= 61) {
                if (features[3] <= 36) {
                    if (features[7] <= 73) {
                        if (features[2] <= 59) {
                            return 2;
                        } else {
                            return 3;

                        }
                    } else {
                        return 2;

                    }
                } else {
                    if (features[8] <= 73) {
                        if (features[7] <= 59) {
                            if (features[6] <= 62) {
                                if (features[0] <= 55) {
                                    if (features[6] <= 52) {
                                        return 3;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[4] <= 66) {
                            if (features[7] <= 75) {
                                if (features[0] <= 54) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[1] <= 85) {
                                if (features[0] <= 52) {
                                    if (features[1] <= 67) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                return 3;

                            }

                        }

                    }

                }
            } else {
                if (features[2] <= 69) {
                    if (features[1] <= 66) {
                        if (features[0] <= 67) {
                            if (features[5] <= 30) {
                                return 3;
                            } else {
                                if (features[4] <= 62) {
                                    if (features[4] <= 30) {
                                        return 2;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[5] <= 64) {
                                        result[1] = 0.2222222222222222;

                                        result[2] = 0.7777777777777778;

                                        return 255;
                                    } else {
                                        result[0] = 0.014705882352941176;

                                        result[2] = 0.9852941176470589;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 84) {
                                if (features[1] <= 51) {
                                    return 2;
                                } else {
                                    if (features[1] <= 58) {
                                        return 1;
                                    } else {
                                        result[1] = 0.9230769230769231;

                                        result[2] = 0.07692307692307693;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 81) {
                                    return 2;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 73) {
                            if (features[5] <= 67) {
                                if (features[6] <= 76) {
                                    if (features[3] <= 75) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[1] <= 68) {
                                    if (features[4] <= 73) {
                                        result[1] = 0.8333333333333334;

                                        result[2] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[7] <= 78) {
                                        result[0] = 0.59375;

                                        result[1] = 0.3125;

                                        result[2] = 0.0625;

                                        result[3] = 0.03125;

                                        return 255;
                                    } else {
                                        result[0] = 0.1;

                                        result[1] = 0.8;

                                        result[2] = 0.1;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 79) {
                                if (features[8] <= 69) {
                                    return 1;
                                } else {
                                    if (features[2] <= 59) {
                                        return 0;
                                    } else {
                                        result[1] = 0.18181818181818182;

                                        result[2] = 0.8181818181818182;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 73) {
                                    return 3;
                                } else {
                                    if (features[0] <= 87) {
                                        return 2;
                                    } else {
                                        result[0] = 0.7142857142857143;

                                        result[1] = 0.2857142857142857;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[6] <= 78) {
                        if (features[8] <= 74) {
                            if (features[2] <= 80) {
                                if (features[2] <= 76) {
                                    if (features[1] <= 71) {
                                        result[0] = 0.2;

                                        result[1] = 0.4;

                                        result[2] = 0.4;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.21428571428571427;

                                        result[3] = 0.2857142857142857;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[8] <= 8) {
                                    if (features[6] <= 64) {
                                        return 2;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[3] <= 81) {
                                        result[1] = 0.1440677966101695;

                                        result[2] = 0.00847457627118644;

                                        result[3] = 0.847457627118644;

                                        return 255;
                                    } else {
                                        result[3] = 0.96;

                                        result[4] = 0.04;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 70) {
                                if (features[3] <= 68) {
                                    return 0;
                                } else {
                                    if (features[8] <= 78) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[0] <= 74) {
                                    if (features[3] <= 72) {
                                        result[0] = 0.9230769230769231;

                                        result[1] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        result[0] = 0.34375;

                                        result[1] = 0.53125;

                                        result[2] = 0.09375;

                                        result[4] = 0.03125;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 79) {
                                        result[0] = 0.1590909090909091;

                                        result[1] = 0.4090909090909091;

                                        result[2] = 0.1590909090909091;

                                        result[3] = 0.22727272727272727;

                                        result[4] = 0.045454545454545456;

                                        return 255;
                                    } else {
                                        result[0] = 0.07207207207207207;

                                        result[1] = 0.16216216216216217;

                                        result[2] = 0.009009009009009009;

                                        result[3] = 0.5135135135135135;

                                        result[4] = 0.24324324324324326;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 89) {
                            if (features[5] <= 80) {
                                if (features[0] <= 80) {
                                    if (features[2] <= 83) {
                                        result[0] = 0.18811881188118812;

                                        result[1] = 0.1782178217821782;

                                        result[2] = 0.6039603960396039;

                                        result[3] = 0.0297029702970297;

                                        return 255;
                                    } else {
                                        result[1] = 0.8333333333333334;

                                        result[2] = 0.08333333333333333;

                                        result[3] = 0.08333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 82) {
                                        result[0] = 0.2391304347826087;

                                        result[2] = 0.08695652173913043;

                                        result[3] = 0.4782608695652174;

                                        result[4] = 0.1956521739130435;

                                        return 255;
                                    } else {
                                        result[0] = 0.39552238805970147;

                                        result[1] = 0.3283582089552239;

                                        result[2] = 0.22388059701492538;

                                        result[3] = 0.014925373134328358;

                                        result[4] = 0.03731343283582089;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 84) {
                                    if (features[2] <= 86) {
                                        result[0] = 0.16666666666666666;

                                        result[1] = 0.2857142857142857;

                                        result[2] = 0.40476190476190477;

                                        result[3] = 0.11904761904761904;

                                        result[4] = 0.023809523809523808;

                                        return 255;
                                    } else {
                                        result[0] = 0.5846153846153846;

                                        result[1] = 0.36923076923076925;

                                        result[4] = 0.046153846153846156;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 86) {
                                        result[0] = 0.011834319526627219;

                                        result[1] = 0.15384615384615385;

                                        result[2] = 0.029585798816568046;

                                        result[3] = 0.514792899408284;

                                        result[4] = 0.28994082840236685;

                                        return 255;
                                    } else {
                                        result[0] = 0.11320754716981132;

                                        result[1] = 0.39622641509433965;

                                        result[2] = 0.018867924528301886;

                                        result[3] = 0.16981132075471697;

                                        result[4] = 0.3018867924528302;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 89) {
                                if (features[2] <= 77) {
                                    if (features[0] <= 92) {
                                        result[0] = 0.18;

                                        result[1] = 0.42;

                                        result[2] = 0.4;

                                        return 255;
                                    } else {
                                        result[0] = 0.6428571428571429;

                                        result[1] = 0.2857142857142857;

                                        result[4] = 0.07142857142857142;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 84) {
                                        result[0] = 0.3888888888888889;

                                        result[2] = 0.4444444444444444;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.11330049261083744;

                                        result[1] = 0.6600985221674877;

                                        result[2] = 0.09852216748768473;

                                        result[3] = 0.019704433497536946;

                                        result[4] = 0.10837438423645321;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 85) {
                                    if (features[5] <= 99) {
                                        return 0;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 86) {
                                        result[0] = 0.5;

                                        result[2] = 0.3333333333333333;

                                        result[4] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.037037037037037035;

                                        result[1] = 0.2222222222222222;

                                        result[2] = 0.037037037037037035;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.37037037037037035;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[4] <= 77) {
                if (features[7] <= 74) {
                    return 3;
                } else {
                    if (features[0] <= 90) {
                        return 1;
                    } else {
                        return 3;

                    }

                }
            } else {
                if (features[4] <= 93) {
                    if (features[0] <= 80) {
                        if (features[2] <= 86) {
                            return 2;
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[6] <= 80) {
                            if (features[8] <= 84) {
                                if (features[8] <= 73) {
                                    return 3;
                                } else {
                                    if (features[4] <= 82) {
                                        result[3] = 0.2;

                                        result[4] = 0.8;

                                        return 255;
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[8] <= 87) {
                                    if (features[6] <= 77) {
                                        return 3;
                                    } else {
                                        result[3] = 0.4;

                                        result[4] = 0.6;

                                        return 255;

                                    }
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[2] <= 75) {
                                if (features[3] <= 89) {
                                    return 2;
                                } else {
                                    if (features[0] <= 98) {
                                        result[0] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[2] <= 88) {
                                    if (features[2] <= 77) {
                                        result[0] = 0.5714285714285714;

                                        result[2] = 0.42857142857142855;

                                        return 255;
                                    } else {
                                        result[0] = 0.08695652173913043;

                                        result[1] = 0.6086956521739131;

                                        result[2] = 0.08695652173913043;

                                        result[3] = 0.08695652173913043;

                                        result[4] = 0.13043478260869565;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 84) {
                                        result[1] = 0.05;

                                        result[3] = 0.65;

                                        result[4] = 0.3;

                                        return 255;
                                    } else {
                                        result[0] = 0.01818181818181818;

                                        result[1] = 0.12727272727272726;

                                        result[2] = 0.012121212121212121;

                                        result[3] = 0.41818181818181815;

                                        result[4] = 0.42424242424242425;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 41) {
                        if (features[5] <= 67) {
                            return 4;
                        } else {
                            if (features[5] <= 93) {
                                return 2;
                            } else {
                                if (features[6] <= 69) {
                                    return 2;
                                } else {
                                    return 3;

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 94) {
                            if (features[8] <= 69) {
                                return 1;
                            } else {
                                if (features[5] <= 91) {
                                    if (features[5] <= 86) {
                                        result[1] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[2] <= 93) {
                                        result[1] = 0.14285714285714285;

                                        result[4] = 0.8571428571428571;

                                        return 255;
                                    } else {
                                        result[1] = 0.29411764705882354;

                                        result[3] = 0.23529411764705882;

                                        result[4] = 0.47058823529411764;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 66) {
                                return 3;
                            } else {
                                if (features[0] <= 69) {
                                    return 2;
                                } else {
                                    if (features[7] <= 96) {
                                        result[1] = 0.875;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[0] <= 84) {
            if (features[6] <= 83) {
                if (features[1] <= 59) {
                    return 2;
                } else {
                    if (features[4] <= 38) {
                        return 3;
                    } else {
                        if (features[1] <= 85) {
                            if (features[3] <= 71) {
                                return 0;
                            } else {
                                if (features[8] <= 94) {
                                    if (features[2] <= 86) {
                                        return 0;
                                    } else {
                                        result[0] = 0.7647058823529411;

                                        result[1] = 0.17647058823529413;

                                        result[3] = 0.058823529411764705;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[7] <= 86) {
                                if (features[4] <= 93) {
                                    if (features[2] <= 92) {
                                        result[0] = 0.5;

                                        result[3] = 0.5;

                                        return 255;
                                    } else {
                                        result[1] = 0.25;

                                        result[4] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                return 0;

                            }

                        }

                    }

                }
            } else {
                if (features[2] <= 86) {
                    if (features[4] <= 61) {
                        return 0;
                    } else {
                        if (features[3] <= 89) {
                            if (features[7] <= 86) {
                                if (features[0] <= 70) {
                                    return 2;
                                } else {
                                    if (features[1] <= 79) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[6] <= 85) {
                                    if (features[5] <= 87) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[4] <= 85) {
                                        result[1] = 0.01098901098901099;

                                        result[2] = 0.989010989010989;

                                        return 255;
                                    } else {
                                        result[0] = 0.047619047619047616;

                                        result[2] = 0.9523809523809523;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 87) {
                                if (features[2] <= 81) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[5] <= 99) {
                                    return 4;
                                } else {
                                    if (features[3] <= 97) {
                                        return 2;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 29) {
                        if (features[3] <= 89) {
                            return 2;
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[1] <= 81) {
                            if (features[4] <= 82) {
                                return 0;
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[4] <= 97) {
                                if (features[1] <= 82) {
                                    return 3;
                                } else {
                                    if (features[5] <= 58) {
                                        return 2;
                                    } else {
                                        result[0] = 0.7586206896551724;

                                        result[1] = 0.20689655172413793;

                                        result[4] = 0.034482758620689655;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 99) {
                                    return 1;
                                } else {
                                    if (features[7] <= 95) {
                                        return 4;
                                    } else {
                                        return 2;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[0] <= 98) {
                if (features[0] <= 96) {
                    if (features[1] <= 95) {
                        if (features[0] <= 94) {
                            if (features[0] <= 94) {
                                if (features[0] <= 89) {
                                    if (features[1] <= 87) {
                                        result[0] = 0.10344827586206896;

                                        result[1] = 0.08045977011494253;

                                        result[2] = 0.7701149425287356;

                                        result[4] = 0.04597701149425287;

                                        return 255;
                                    } else {
                                        result[0] = 0.5022222222222222;

                                        result[1] = 0.07111111111111111;

                                        result[2] = 0.2088888888888889;

                                        result[3] = 0.008888888888888889;

                                        result[4] = 0.2088888888888889;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 91) {
                                        result[0] = 0.034482758620689655;

                                        result[1] = 0.12643678160919541;

                                        result[2] = 0.14942528735632185;

                                        result[3] = 0.16091954022988506;

                                        result[4] = 0.5287356321839081;

                                        return 255;
                                    } else {
                                        result[0] = 0.1875;

                                        result[1] = 0.09722222222222222;

                                        result[2] = 0.3125;

                                        result[3] = 0.04861111111111111;

                                        result[4] = 0.3541666666666667;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 95) {
                                    if (features[2] <= 94) {
                                        result[1] = 0.21428571428571427;

                                        result[4] = 0.7857142857142857;

                                        return 255;
                                    } else {
                                        result[1] = 0.02857142857142857;

                                        result[3] = 0.6;

                                        result[4] = 0.37142857142857144;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 94) {
                                        result[1] = 0.041666666666666664;

                                        result[2] = 0.041666666666666664;

                                        result[4] = 0.9166666666666666;

                                        return 255;
                                    } else {
                                        result[2] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 93) {
                                if (features[4] <= 88) {
                                    if (features[2] <= 79) {
                                        return 0;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[6] <= 100) {
                                        result[2] = 0.8;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 93) {
                                    if (features[8] <= 94) {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[7] <= 94) {
                                        result[2] = 0.3333333333333333;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[2] = 0.25;

                                        result[3] = 0.75;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 96) {
                            if (features[8] <= 95) {
                                if (features[3] <= 87) {
                                    return 0;
                                } else {
                                    if (features[0] <= 84) {
                                        return 1;
                                    } else {
                                        result[0] = 0.06818181818181818;

                                        result[1] = 0.022727272727272728;

                                        result[2] = 0.045454545454545456;

                                        result[3] = 0.13636363636363635;

                                        result[4] = 0.7272727272727273;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 95) {
                                    if (features[1] <= 99) {
                                        result[0] = 0.16666666666666666;

                                        result[3] = 0.05555555555555555;

                                        result[4] = 0.7777777777777778;

                                        return 255;
                                    } else {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.14285714285714285;

                                        result[2] = 0.14285714285714285;

                                        result[3] = 0.14285714285714285;

                                        result[4] = 0.14285714285714285;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 95) {
                                        result[0] = 0.75;

                                        result[3] = 0.05;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 91) {
                                return 3;
                            } else {
                                if (features[1] <= 97) {
                                    if (features[2] <= 96) {
                                        result[1] = 0.2;

                                        result[2] = 0.4;

                                        result[4] = 0.4;

                                        return 255;
                                    } else {
                                        result[0] = 0.6;

                                        result[4] = 0.4;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 95) {
                                        result[0] = 0.16666666666666666;

                                        result[2] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[0] = 0.4666666666666667;

                                        result[1] = 0.06666666666666667;

                                        result[2] = 0.4666666666666667;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[2] <= 92) {
                        if (features[0] <= 97) {
                            if (features[3] <= 89) {
                                if (features[6] <= 77) {
                                    if (features[7] <= 81) {
                                        return 3;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[7] <= 91) {
                                        return 4;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[3] <= 95) {
                                    if (features[3] <= 93) {
                                        result[2] = 0.3333333333333333;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 97) {
                                        result[1] = 0.875;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 99) {
                                return 1;
                            } else {
                                if (features[4] <= 97) {
                                    return 2;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 99) {
                            if (features[2] <= 97) {
                                if (features[7] <= 91) {
                                    if (features[5] <= 91) {
                                        return 1;
                                    } else {
                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 92) {
                                        result[3] = 0.05;

                                        result[4] = 0.95;

                                        return 255;
                                    } else {
                                        result[1] = 0.08;

                                        result[2] = 0.05333333333333334;

                                        result[3] = 0.13333333333333333;

                                        result[4] = 0.7333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 97) {
                                    if (features[8] <= 94) {
                                        result[1] = 0.07692307692307693;

                                        result[3] = 0.6538461538461539;

                                        result[4] = 0.2692307692307692;

                                        return 255;
                                    } else {
                                        result[0] = 0.043478260869565216;

                                        result[1] = 0.043478260869565216;

                                        result[3] = 0.30434782608695654;

                                        result[4] = 0.6086956521739131;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 95) {
                                        result[0] = 0.8333333333333334;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.2;

                                        result[2] = 0.06666666666666667;

                                        result[3] = 0.06666666666666667;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 95) {
                                if (features[5] <= 96) {
                                    if (features[3] <= 100) {
                                        return 4;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[1] <= 96) {
                                    if (features[6] <= 99) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[1] <= 99) {
                                        result[1] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.1;

                                        result[1] = 0.3;

                                        result[2] = 0.3;

                                        result[3] = 0.1;

                                        result[4] = 0.2;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[8] <= 95) {
                    if (features[7] <= 63) {
                        return 2;
                    } else {
                        if (features[5] <= 86) {
                            if (features[1] <= 83) {
                                if (features[4] <= 46) {
                                    return 3;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[6] <= 80) {
                                    return 0;
                                } else {
                                    if (features[5] <= 38) {
                                        return 2;
                                    } else {
                                        result[1] = 0.8333333333333334;

                                        result[2] = 0.16666666666666666;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 99) {
                                if (features[6] <= 96) {
                                    return 3;
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[7] <= 91) {
                                    if (features[5] <= 98) {
                                        result[2] = 0.047619047619047616;

                                        result[3] = 0.047619047619047616;

                                        result[4] = 0.9047619047619048;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 98) {
                                        result[1] = 0.5882352941176471;

                                        result[2] = 0.058823529411764705;

                                        result[4] = 0.35294117647058826;

                                        return 255;
                                    } else {
                                        result[1] = 0.17647058823529413;

                                        result[2] = 0.058823529411764705;

                                        result[3] = 0.058823529411764705;

                                        result[4] = 0.7058823529411765;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[2] <= 98) {
                        if (features[8] <= 99) {
                            if (features[7] <= 95) {
                                if (features[5] <= 91) {
                                    return 1;
                                } else {
                                    if (features[1] <= 97) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[1] <= 93) {
                                    return 0;
                                } else {
                                    if (features[8] <= 98) {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.2222222222222222;

                                        result[2] = 0.2222222222222222;

                                        result[3] = 0.1111111111111111;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[1] = 0.14285714285714285;

                                        result[2] = 0.8571428571428571;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 16) {
                                if (features[1] <= 83) {
                                    return 0;
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[4] <= 91) {
                                    if (features[6] <= 98) {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 34) {
                                        return 2;
                                    } else {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.37037037037037035;

                                        result[2] = 0.4444444444444444;

                                        result[3] = 0.07407407407407407;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 100) {
                            if (features[2] <= 99) {
                                return 1;
                            } else {
                                if (features[1] <= 100) {
                                    if (features[3] <= 98) {
                                        result[0] = 0.3333333333333333;

                                        result[3] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.4;

                                        result[1] = 0.6;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 97) {
                                        return 0;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[3] = 0.8333333333333334;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 99) {
                                if (features[7] <= 97) {
                                    if (features[8] <= 95) {
                                        result[3] = 0.5555555555555556;

                                        result[4] = 0.4444444444444444;

                                        return 255;
                                    } else {
                                        result[0] = 0.07692307692307693;

                                        result[1] = 0.07692307692307693;

                                        result[2] = 0.15384615384615385;

                                        result[3] = 0.15384615384615385;

                                        result[4] = 0.5384615384615384;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 97) {
                                        result[0] = 0.25;

                                        result[2] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.13043478260869565;

                                        result[1] = 0.17391304347826086;

                                        result[2] = 0.21739130434782608;

                                        result[3] = 0.30434782608695654;

                                        result[4] = 0.17391304347826086;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 90) {
                                    return 0;
                                } else {
                                    if (features[3] <= 98) {
                                        result[0] = 0.2;

                                        result[2] = 0.13333333333333333;

                                        result[3] = 0.2;

                                        result[4] = 0.4666666666666667;

                                        return 255;
                                    } else {
                                        result[0] = 0.06451612903225806;

                                        result[1] = 0.04838709677419355;

                                        result[2] = 0.2903225806451613;

                                        result[3] = 0.4838709677419355;

                                        result[4] = 0.11290322580645161;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree3(unsigned char* features, float* result){
    if (features[7] <= 80) {
        if (features[8] <= 67) {
            if (features[7] <= 75) {
                if (features[3] <= 79) {
                    if (features[7] <= 72) {
                        if (features[5] <= 64) {
                            if (features[1] <= 73) {
                                if (features[6] <= 58) {
                                    if (features[2] <= 51) {
                                        result[2] = 0.3333333333333333;

                                        result[3] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[0] <= 75) {
                                        return 1;
                                    } else {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[2] <= 83) {
                                if (features[2] <= 71) {
                                    if (features[6] <= 76) {
                                        result[0] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[6] <= 13) {
                                        return 0;
                                    } else {
                                        result[1] = 0.03571428571428571;

                                        result[2] = 0.03571428571428571;

                                        result[3] = 0.9285714285714286;

                                        return 255;

                                    }

                                }
                            } else {
                                return 3;

                            }

                        }
                    } else {
                        if (features[2] <= 72) {
                            if (features[6] <= 77) {
                                return 0;
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[2] <= 73) {
                                return 0;
                            } else {
                                return 3;

                            }

                        }

                    }
                } else {
                    if (features[1] <= 79) {
                        if (features[3] <= 83) {
                            if (features[2] <= 70) {
                                return 1;
                            } else {
                                return 0;

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[4] <= 97) {
                            return 3;
                        } else {
                            return 2;

                        }

                    }

                }
            } else {
                if (features[1] <= 84) {
                    if (features[8] <= 59) {
                        return 2;
                    } else {
                        if (features[3] <= 92) {
                            if (features[2] <= 72) {
                                return 1;
                            } else {
                                if (features[6] <= 81) {
                                    if (features[0] <= 88) {
                                        return 1;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[3] <= 98) {
                                return 1;
                            } else {
                                return 3;

                            }

                        }

                    }
                } else {
                    return 4;

                }

            }
        } else {
            if (features[0] <= 79) {
                if (features[1] <= 76) {
                    if (features[8] <= 83) {
                        if (features[1] <= 67) {
                            if (features[6] <= 74) {
                                if (features[1] <= 57) {
                                    if (features[6] <= 72) {
                                        return 2;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[6] <= 72) {
                                        result[0] = 0.9230769230769231;

                                        result[2] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[8] <= 76) {
                                    if (features[7] <= 78) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[4] <= 73) {
                                        return 2;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 65) {
                                if (features[7] <= 67) {
                                    if (features[4] <= 72) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[6] <= 65) {
                                    if (features[1] <= 75) {
                                        return 1;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[6] <= 84) {
                                        result[0] = 0.32941176470588235;

                                        result[1] = 0.4470588235294118;

                                        result[2] = 0.2;

                                        result[3] = 0.023529411764705882;

                                        return 255;
                                    } else {
                                        result[1] = 0.8421052631578947;

                                        result[2] = 0.15789473684210525;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[4] <= 69) {
                            if (features[7] <= 72) {
                                return 2;
                            } else {
                                if (features[7] <= 76) {
                                    return 2;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[6] <= 70) {
                                return 0;
                            } else {
                                if (features[1] <= 59) {
                                    return 2;
                                } else {
                                    if (features[6] <= 74) {
                                        return 0;
                                    } else {
                                        result[0] = 0.5714285714285714;

                                        result[1] = 0.42857142857142855;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[2] <= 84) {
                        if (features[1] <= 80) {
                            if (features[6] <= 81) {
                                if (features[0] <= 74) {
                                    if (features[3] <= 70) {
                                        return 0;
                                    } else {
                                        result[0] = 0.18181818181818182;

                                        result[1] = 0.8181818181818182;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 75) {
                                        result[0] = 0.125;

                                        result[2] = 0.125;

                                        result[3] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.3157894736842105;

                                        result[1] = 0.10526315789473684;

                                        result[2] = 0.5526315789473685;

                                        result[3] = 0.02631578947368421;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 78) {
                                    return 0;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[8] <= 79) {
                                if (features[5] <= 79) {
                                    if (features[7] <= 63) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[8] <= 89) {
                                    return 1;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 70) {
                            if (features[8] <= 85) {
                                if (features[0] <= 71) {
                                    if (features[2] <= 90) {
                                        return 0;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[7] <= 10) {
                                return 3;
                            } else {
                                if (features[0] <= 76) {
                                    if (features[4] <= 75) {
                                        result[1] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.5925925925925926;

                                        result[1] = 0.37037037037037035;

                                        result[4] = 0.037037037037037035;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 80) {
                                        result[1] = 0.6111111111111112;

                                        result[3] = 0.1388888888888889;

                                        result[4] = 0.25;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[8] <= 85) {
                    if (features[2] <= 83) {
                        if (features[8] <= 79) {
                            if (features[1] <= 72) {
                                if (features[7] <= 71) {
                                    if (features[1] <= 69) {
                                        result[2] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[3] <= 83) {
                                    if (features[7] <= 71) {
                                        result[0] = 0.2;

                                        result[3] = 0.8;

                                        return 255;
                                    } else {
                                        result[0] = 0.24074074074074073;

                                        result[1] = 0.07407407407407407;

                                        result[2] = 0.18518518518518517;

                                        result[3] = 0.46296296296296297;

                                        result[4] = 0.037037037037037035;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 77) {
                                        result[0] = 0.6101694915254238;

                                        result[1] = 0.3050847457627119;

                                        result[2] = 0.01694915254237288;

                                        result[3] = 0.05084745762711865;

                                        result[4] = 0.01694915254237288;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.03125;

                                        result[2] = 0.0625;

                                        result[3] = 0.34375;

                                        result[4] = 0.0625;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 85) {
                                if (features[0] <= 84) {
                                    if (features[6] <= 60) {
                                        return 3;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.7857142857142857;

                                        result[2] = 0.07142857142857142;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 83) {
                                        result[0] = 0.8;

                                        result[2] = 0.2;

                                        return 255;
                                    } else {
                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.16666666666666666;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 80) {
                                    return 2;
                                } else {
                                    if (features[8] <= 81) {
                                        result[0] = 0.4117647058823529;

                                        result[1] = 0.23529411764705882;

                                        result[2] = 0.35294117647058826;

                                        return 255;
                                    } else {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 93) {
                            if (features[8] <= 74) {
                                return 3;
                            } else {
                                if (features[0] <= 88) {
                                    if (features[2] <= 85) {
                                        result[1] = 0.18181818181818182;

                                        result[3] = 0.8181818181818182;

                                        return 255;
                                    } else {
                                        result[1] = 0.07017543859649122;

                                        result[2] = 0.03508771929824561;

                                        result[3] = 0.5789473684210527;

                                        result[4] = 0.3157894736842105;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 90) {
                                        result[0] = 0.07142857142857142;

                                        result[1] = 0.07142857142857142;

                                        result[2] = 0.07142857142857142;

                                        result[3] = 0.35714285714285715;

                                        result[4] = 0.42857142857142855;

                                        return 255;
                                    } else {
                                        result[3] = 0.9090909090909091;

                                        result[4] = 0.09090909090909091;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 80) {
                                if (features[3] <= 82) {
                                    return 3;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[6] <= 94) {
                                    return 3;
                                } else {
                                    if (features[2] <= 91) {
                                        return 4;
                                    } else {
                                        return 3;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 25) {
                        if (features[3] <= 89) {
                            if (features[1] <= 99) {
                                return 3;
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[8] <= 86) {
                                return 1;
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[8] <= 86) {
                            if (features[5] <= 88) {
                                if (features[5] <= 84) {
                                    return 2;
                                } else {
                                    if (features[6] <= 78) {
                                        return 4;
                                    } else {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 79) {
                                    return 4;
                                } else {
                                    if (features[0] <= 91) {
                                        result[1] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 97) {
                                if (features[3] <= 82) {
                                    if (features[8] <= 100) {
                                        result[0] = 0.5454545454545454;

                                        result[3] = 0.45454545454545453;

                                        return 255;
                                    } else {
                                        result[3] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 54) {
                                        return 3;
                                    } else {
                                        result[0] = 0.21052631578947367;

                                        result[1] = 0.15789473684210525;

                                        result[2] = 0.15789473684210525;

                                        result[3] = 0.10526315789473684;

                                        result[4] = 0.3684210526315789;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 84) {
                                    if (features[8] <= 100) {
                                        return 2;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 3;

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[1] <= 81) {
            if (features[6] <= 77) {
                if (features[8] <= 88) {
                    if (features[1] <= 73) {
                        return 2;
                    } else {
                        if (features[4] <= 77) {
                            if (features[0] <= 76) {
                                return 0;
                            } else {
                                if (features[7] <= 82) {
                                    return 1;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            return 1;

                        }

                    }
                } else {
                    if (features[3] <= 74) {
                        return 0;
                    } else {
                        if (features[8] <= 89) {
                            if (features[3] <= 77) {
                                return 0;
                            } else {
                                return 1;

                            }
                        } else {
                            return 0;

                        }

                    }

                }
            } else {
                if (features[1] <= 67) {
                    if (features[4] <= 91) {
                        if (features[5] <= 59) {
                            return 1;
                        } else {
                            if (features[6] <= 99) {
                                if (features[4] <= 66) {
                                    return 0;
                                } else {
                                    if (features[0] <= 57) {
                                        result[0] = 0.05555555555555555;

                                        result[2] = 0.9444444444444444;

                                        return 255;
                                    } else {
                                        result[1] = 0.024096385542168676;

                                        result[2] = 0.9759036144578314;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 78) {
                                    if (features[8] <= 95) {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[2] <= 59) {
                            return 4;
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[7] <= 87) {
                        if (features[8] <= 71) {
                            if (features[0] <= 79) {
                                return 0;
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[4] <= 73) {
                                if (features[3] <= 79) {
                                    if (features[4] <= 73) {
                                        return 1;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[1] <= 80) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[5] <= 84) {
                                    if (features[6] <= 87) {
                                        result[0] = 0.06451612903225806;

                                        result[1] = 0.1935483870967742;

                                        result[2] = 0.7419354838709677;

                                        return 255;
                                    } else {
                                        result[0] = 0.11764705882352941;

                                        result[1] = 0.5294117647058824;

                                        result[2] = 0.35294117647058826;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 87) {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.1111111111111111;

                                        result[2] = 0.2222222222222222;

                                        return 255;
                                    } else {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 82) {
                            if (features[1] <= 75) {
                                return 2;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[3] <= 97) {
                                if (features[2] <= 64) {
                                    return 1;
                                } else {
                                    if (features[8] <= 82) {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.0449438202247191;

                                        result[2] = 0.9550561797752809;

                                        return 255;

                                    }

                                }
                            } else {
                                return 1;

                            }

                        }

                    }

                }

            }
        } else {
            if (features[2] <= 88) {
                if (features[2] <= 81) {
                    if (features[3] <= 81) {
                        return 3;
                    } else {
                        if (features[3] <= 87) {
                            if (features[5] <= 79) {
                                if (features[7] <= 88) {
                                    if (features[5] <= 73) {
                                        return 1;
                                    } else {
                                        result[0] = 0.6;

                                        result[1] = 0.2;

                                        result[2] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[7] <= 85) {
                                    if (features[3] <= 82) {
                                        return 2;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[7] <= 90) {
                                if (features[5] <= 76) {
                                    if (features[3] <= 94) {
                                        result[0] = 0.45454545454545453;

                                        result[1] = 0.45454545454545453;

                                        result[2] = 0.045454545454545456;

                                        result[4] = 0.045454545454545456;

                                        return 255;
                                    } else {
                                        result[0] = 0.8125;

                                        result[1] = 0.125;

                                        result[2] = 0.0625;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 86) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.5555555555555556;

                                        result[2] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        result[0] = 0.13333333333333333;

                                        result[1] = 0.13333333333333333;

                                        result[2] = 0.7333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 78) {
                                    if (features[7] <= 99) {
                                        result[0] = 0.875;

                                        result[2] = 0.125;

                                        return 255;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.5;

                                        result[4] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 93) {
                                        result[0] = 0.05405405405405406;

                                        result[1] = 0.13513513513513514;

                                        result[2] = 0.6756756756756757;

                                        result[4] = 0.13513513513513514;

                                        return 255;
                                    } else {
                                        result[0] = 0.23529411764705882;

                                        result[1] = 0.47058823529411764;

                                        result[2] = 0.17647058823529413;

                                        result[4] = 0.11764705882352941;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= 91) {
                        if (features[0] <= 85) {
                            if (features[8] <= 91) {
                                if (features[6] <= 88) {
                                    if (features[3] <= 81) {
                                        result[0] = 0.625;

                                        result[1] = 0.375;

                                        return 255;
                                    } else {
                                        result[0] = 0.1;

                                        result[1] = 0.25;

                                        result[2] = 0.45;

                                        result[3] = 0.15;

                                        result[4] = 0.05;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 92) {
                                        result[1] = 0.1724137931034483;

                                        result[2] = 0.7931034482758621;

                                        result[4] = 0.034482758620689655;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[8] <= 93) {
                                    if (features[7] <= 90) {
                                        result[0] = 0.8;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[4] <= 45) {
                                        return 0;
                                    } else {
                                        result[2] = 0.9642857142857143;

                                        result[4] = 0.03571428571428571;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 92) {
                                if (features[8] <= 79) {
                                    if (features[5] <= 92) {
                                        result[0] = 0.16666666666666666;

                                        result[2] = 0.16666666666666666;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[8] <= 89) {
                                        result[0] = 0.1694915254237288;

                                        result[1] = 0.5084745762711864;

                                        result[2] = 0.1016949152542373;

                                        result[3] = 0.05084745762711865;

                                        result[4] = 0.1694915254237288;

                                        return 255;
                                    } else {
                                        result[0] = 0.07142857142857142;

                                        result[1] = 0.2857142857142857;

                                        result[2] = 0.5;

                                        result[4] = 0.14285714285714285;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 87) {
                                    return 0;
                                } else {
                                    return 2;

                                }

                            }

                        }
                    } else {
                        if (features[8] <= 74) {
                            if (features[1] <= 89) {
                                return 0;
                            } else {
                                if (features[1] <= 99) {
                                    return 3;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[8] <= 91) {
                                if (features[6] <= 88) {
                                    if (features[6] <= 88) {
                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.125;

                                        result[1] = 0.5;

                                        result[4] = 0.375;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 82) {
                                        result[0] = 0.5555555555555556;

                                        result[1] = 0.3333333333333333;

                                        result[4] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        result[0] = 0.018867924528301886;

                                        result[1] = 0.9056603773584906;

                                        result[2] = 0.018867924528301886;

                                        result[4] = 0.05660377358490566;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 98) {
                                    if (features[4] <= 98) {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[4] <= 87) {
                                        return 4;
                                    } else {
                                        result[2] = 0.5;

                                        result[3] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 91) {
                    if (features[6] <= 92) {
                        if (features[1] <= 93) {
                            if (features[0] <= 83) {
                                if (features[1] <= 86) {
                                    if (features[5] <= 70) {
                                        return 3;
                                    } else {
                                        result[0] = 0.6842105263157895;

                                        result[1] = 0.2894736842105263;

                                        result[3] = 0.013157894736842105;

                                        result[4] = 0.013157894736842105;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 94) {
                                        result[0] = 0.36363636363636365;

                                        result[1] = 0.2727272727272727;

                                        result[4] = 0.36363636363636365;

                                        return 255;
                                    } else {
                                        result[0] = 0.09090909090909091;

                                        result[1] = 0.6818181818181818;

                                        result[4] = 0.22727272727272727;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 90) {
                                    if (features[1] <= 91) {
                                        result[0] = 0.5257731958762887;

                                        result[1] = 0.10824742268041238;

                                        result[2] = 0.030927835051546393;

                                        result[3] = 0.1134020618556701;

                                        result[4] = 0.22164948453608246;

                                        return 255;
                                    } else {
                                        result[0] = 0.14634146341463414;

                                        result[1] = 0.07317073170731707;

                                        result[3] = 0.04878048780487805;

                                        result[4] = 0.7317073170731707;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 90) {
                                        result[0] = 0.03636363636363636;

                                        result[1] = 0.10909090909090909;

                                        result[2] = 0.01818181818181818;

                                        result[3] = 0.5818181818181818;

                                        result[4] = 0.2545454545454545;

                                        return 255;
                                    } else {
                                        result[0] = 0.17647058823529413;

                                        result[1] = 0.058823529411764705;

                                        result[3] = 0.11764705882352941;

                                        result[4] = 0.6470588235294118;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 79) {
                                if (features[8] <= 88) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[4] <= 90) {
                                    if (features[7] <= 88) {
                                        result[1] = 0.125;

                                        result[3] = 0.75;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[0] = 0.0625;

                                        result[1] = 0.125;

                                        result[3] = 0.1875;

                                        result[4] = 0.625;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 91) {
                                        result[0] = 0.0975609756097561;

                                        result[1] = 0.024390243902439025;

                                        result[3] = 0.04878048780487805;

                                        result[4] = 0.8292682926829268;

                                        return 255;
                                    } else {
                                        result[0] = 0.4666666666666667;

                                        result[1] = 0.06666666666666667;

                                        result[4] = 0.4666666666666667;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[2] <= 91) {
                            if (features[7] <= 89) {
                                if (features[4] <= 90) {
                                    return 1;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[0] <= 68) {
                                    return 0;
                                } else {
                                    if (features[0] <= 85) {
                                        return 2;
                                    } else {
                                        result[0] = 0.01639344262295082;

                                        result[1] = 0.09836065573770492;

                                        result[2] = 0.6885245901639344;

                                        result[4] = 0.19672131147540983;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 93) {
                                if (features[2] <= 94) {
                                    if (features[2] <= 92) {
                                        result[0] = 0.21428571428571427;

                                        result[1] = 0.17857142857142858;

                                        result[2] = 0.35714285714285715;

                                        result[3] = 0.03571428571428571;

                                        result[4] = 0.21428571428571427;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[5] <= 91) {
                                        result[1] = 0.45454545454545453;

                                        result[2] = 0.36363636363636365;

                                        result[3] = 0.18181818181818182;

                                        return 255;
                                    } else {
                                        result[0] = 0.56;

                                        result[1] = 0.24;

                                        result[2] = 0.04;

                                        result[4] = 0.16;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 94) {
                                    if (features[3] <= 95) {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.07142857142857142;

                                        result[2] = 0.42857142857142855;

                                        result[4] = 0.35714285714285715;

                                        return 255;
                                    } else {
                                        result[1] = 0.25;

                                        result[4] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 94) {
                                        result[1] = 0.125;

                                        result[2] = 0.875;

                                        return 255;
                                    } else {
                                        result[0] = 0.36363636363636365;

                                        result[2] = 0.45454545454545453;

                                        result[4] = 0.18181818181818182;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 97) {
                        if (features[6] <= 91) {
                            if (features[3] <= 88) {
                                if (features[4] <= 93) {
                                    if (features[6] <= 82) {
                                        result[0] = 0.3333333333333333;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.125;

                                        result[4] = 0.875;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[2] <= 93) {
                                    if (features[2] <= 91) {
                                        result[0] = 0.02702702702702703;

                                        result[1] = 0.13513513513513514;

                                        result[2] = 0.05405405405405406;

                                        result[3] = 0.2972972972972973;

                                        result[4] = 0.4864864864864865;

                                        return 255;
                                    } else {
                                        result[0] = 0.03278688524590164;

                                        result[1] = 0.03278688524590164;

                                        result[3] = 0.7213114754098361;

                                        result[4] = 0.21311475409836064;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 93) {
                                        result[1] = 0.022988505747126436;

                                        result[3] = 0.5172413793103449;

                                        result[4] = 0.45977011494252873;

                                        return 255;
                                    } else {
                                        result[0] = 0.12121212121212122;

                                        result[1] = 0.030303030303030304;

                                        result[3] = 0.12121212121212122;

                                        result[4] = 0.7272727272727273;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[2] <= 88) {
                                if (features[7] <= 89) {
                                    if (features[1] <= 91) {
                                        result[1] = 0.7058823529411765;

                                        result[4] = 0.29411764705882354;

                                        return 255;
                                    } else {
                                        result[0] = 0.09090909090909091;

                                        result[1] = 0.18181818181818182;

                                        result[4] = 0.7272727272727273;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 91) {
                                        result[1] = 0.8333333333333334;

                                        result[2] = 0.041666666666666664;

                                        result[4] = 0.125;

                                        return 255;
                                    } else {
                                        result[1] = 0.6428571428571429;

                                        result[3] = 0.07142857142857142;

                                        result[4] = 0.2857142857142857;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[2] <= 93) {
                                    if (features[0] <= 95) {
                                        result[1] = 0.13793103448275862;

                                        result[2] = 0.10344827586206896;

                                        result[3] = 0.08620689655172414;

                                        result[4] = 0.6724137931034483;

                                        return 255;
                                    } else {
                                        result[1] = 0.6176470588235294;

                                        result[2] = 0.11764705882352941;

                                        result[3] = 0.029411764705882353;

                                        result[4] = 0.23529411764705882;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 89) {
                                        result[0] = 0.125;

                                        result[1] = 0.5833333333333334;

                                        result[2] = 0.041666666666666664;

                                        result[3] = 0.20833333333333334;

                                        result[4] = 0.041666666666666664;

                                        return 255;
                                    } else {
                                        result[0] = 0.10526315789473684;

                                        result[1] = 0.06811145510835913;

                                        result[2] = 0.02786377708978328;

                                        result[3] = 0.23839009287925697;

                                        result[4] = 0.5603715170278638;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 98) {
                            if (features[7] <= 98) {
                                if (features[4] <= 92) {
                                    if (features[3] <= 96) {
                                        result[1] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[1] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 93) {
                                        return 1;
                                    } else {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.08333333333333333;

                                        result[2] = 0.027777777777777776;

                                        result[3] = 0.05555555555555555;

                                        result[4] = 0.7222222222222222;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 92) {
                                    if (features[2] <= 93) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[2] <= 99) {
                                        result[0] = 0.06896551724137931;

                                        result[1] = 0.10344827586206896;

                                        result[2] = 0.2413793103448276;

                                        result[3] = 0.10344827586206896;

                                        result[4] = 0.4827586206896552;

                                        return 255;
                                    } else {
                                        result[0] = 0.4444444444444444;

                                        result[3] = 0.2777777777777778;

                                        result[4] = 0.2777777777777778;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 100) {
                                if (features[5] <= 98) {
                                    if (features[8] <= 98) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        result[2] = 0.8947368421052632;

                                        result[3] = 0.05263157894736842;

                                        result[4] = 0.05263157894736842;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 97) {
                                        return 2;
                                    } else {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.1111111111111111;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.1111111111111111;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 98) {
                                    if (features[1] <= 96) {
                                        result[0] = 0.08333333333333333;

                                        result[1] = 0.25;

                                        result[2] = 0.25;

                                        result[3] = 0.20833333333333334;

                                        result[4] = 0.20833333333333334;

                                        return 255;
                                    } else {
                                        result[0] = 0.06557377049180328;

                                        result[1] = 0.13114754098360656;

                                        result[2] = 0.13114754098360656;

                                        result[3] = 0.09836065573770492;

                                        result[4] = 0.5737704918032787;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 100) {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.37037037037037035;

                                        result[2] = 0.2962962962962963;

                                        result[3] = 0.14814814814814814;

                                        result[4] = 0.07407407407407407;

                                        return 255;
                                    } else {
                                        result[0] = 0.04285714285714286;

                                        result[1] = 0.14285714285714285;

                                        result[2] = 0.2857142857142857;

                                        result[3] = 0.42857142857142855;

                                        result[4] = 0.1;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree4(unsigned char* features, float* result){
    if (features[5] <= 79) {
        if (features[6] <= 79) {
            if (features[5] <= 55) {
                if (features[1] <= 86) {
                    if (features[7] <= 24) {
                        if (features[4] <= 55) {
                            return 1;
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[2] <= 50) {
                            if (features[0] <= 46) {
                                return 3;
                            } else {
                                return 2;

                            }
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[6] <= 72) {
                        return 2;
                    } else {
                        if (features[0] <= 90) {
                            return 1;
                        } else {
                            return 3;

                        }

                    }

                }
            } else {
                if (features[1] <= 59) {
                    if (features[7] <= 44) {
                        return 3;
                    } else {
                        if (features[8] <= 71) {
                            if (features[6] <= 77) {
                                return 3;
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[8] <= 85) {
                                return 2;
                            } else {
                                if (features[5] <= 73) {
                                    return 0;
                                } else {
                                    return 2;

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 84) {
                        if (features[3] <= 1) {
                            return 3;
                        } else {
                            if (features[0] <= 64) {
                                if (features[5] <= 70) {
                                    if (features[1] <= 72) {
                                        result[0] = 0.16666666666666666;

                                        result[2] = 0.6666666666666666;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 79) {
                                        result[0] = 0.8518518518518519;

                                        result[1] = 0.037037037037037035;

                                        result[2] = 0.1111111111111111;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[0] <= 76) {
                                    if (features[0] <= 65) {
                                        return 0;
                                    } else {
                                        result[0] = 0.18571428571428572;

                                        result[1] = 0.6;

                                        result[2] = 0.08571428571428572;

                                        result[3] = 0.12857142857142856;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 74) {
                                        result[0] = 0.6567164179104478;

                                        result[1] = 0.19402985074626866;

                                        result[2] = 0.11940298507462686;

                                        result[3] = 0.029850746268656716;

                                        return 255;
                                    } else {
                                        result[0] = 0.15625;

                                        result[1] = 0.09375;

                                        result[2] = 0.2109375;

                                        result[3] = 0.53125;

                                        result[4] = 0.0078125;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 73) {
                            if (features[7] <= 78) {
                                if (features[5] <= 77) {
                                    return 3;
                                } else {
                                    if (features[0] <= 83) {
                                        result[1] = 0.125;

                                        result[3] = 0.875;

                                        return 255;
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[8] <= 22) {
                                    return 4;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[2] <= 77) {
                                if (features[5] <= 77) {
                                    if (features[4] <= 80) {
                                        result[0] = 0.6;

                                        result[3] = 0.4;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[0] <= 80) {
                                    if (features[2] <= 86) {
                                        return 1;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[1] <= 86) {
                                        result[0] = 0.05;

                                        result[2] = 0.15;

                                        result[3] = 0.6;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        return 3;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[7] <= 83) {
                if (features[8] <= 70) {
                    if (features[1] <= 84) {
                        if (features[3] <= 53) {
                            return 2;
                        } else {
                            if (features[1] <= 65) {
                                if (features[7] <= 61) {
                                    return 2;
                                } else {
                                    return 1;

                                }
                            } else {
                                return 1;

                            }

                        }
                    } else {
                        return 3;

                    }
                } else {
                    if (features[0] <= 77) {
                        if (features[8] <= 78) {
                            if (features[6] <= 86) {
                                if (features[6] <= 82) {
                                    if (features[3] <= 75) {
                                        result[1] = 0.4;

                                        result[2] = 0.6;

                                        return 255;
                                    } else {
                                        result[1] = 0.75;

                                        result[2] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[0] <= 84) {
                            if (features[8] <= 73) {
                                if (features[5] <= 58) {
                                    return 3;
                                } else {
                                    if (features[5] <= 66) {
                                        return 1;
                                    } else {
                                        result[0] = 0.10526315789473684;

                                        result[1] = 0.6842105263157895;

                                        result[2] = 0.15789473684210525;

                                        result[3] = 0.05263157894736842;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 80) {
                                    return 2;
                                } else {
                                    if (features[8] <= 76) {
                                        result[0] = 0.391304347826087;

                                        result[1] = 0.2608695652173913;

                                        result[2] = 0.34782608695652173;

                                        return 255;
                                    } else {
                                        result[1] = 0.25;

                                        result[2] = 0.75;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 29) {
                                return 3;
                            } else {
                                if (features[6] <= 89) {
                                    if (features[6] <= 86) {
                                        result[0] = 0.7692307692307693;

                                        result[1] = 0.07692307692307693;

                                        result[3] = 0.038461538461538464;

                                        result[4] = 0.11538461538461539;

                                        return 255;
                                    } else {
                                        result[0] = 0.5102040816326531;

                                        result[1] = 0.30612244897959184;

                                        result[2] = 0.16326530612244897;

                                        result[4] = 0.02040816326530612;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 89) {
                                        result[0] = 0.1;

                                        result[1] = 0.9;

                                        return 255;
                                    } else {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.2857142857142857;

                                        result[2] = 0.21428571428571427;

                                        result[4] = 0.07142857142857142;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 80) {
                    if (features[5] <= 66) {
                        if (features[6] <= 99) {
                            return 2;
                        } else {
                            if (features[1] <= 57) {
                                return 2;
                            } else {
                                return 1;

                            }

                        }
                    } else {
                        if (features[6] <= 98) {
                            if (features[3] <= 80) {
                                if (features[1] <= 76) {
                                    return 2;
                                } else {
                                    if (features[8] <= 83) {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[3] <= 91) {
                                    if (features[1] <= 65) {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[4] <= 80) {
                                return 1;
                            } else {
                                return 2;

                            }

                        }

                    }
                } else {
                    if (features[0] <= 92) {
                        if (features[3] <= 94) {
                            if (features[5] <= 53) {
                                return 0;
                            } else {
                                if (features[2] <= 56) {
                                    return 1;
                                } else {
                                    if (features[0] <= 84) {
                                        return 2;
                                    } else {
                                        result[0] = 0.06060606060606061;

                                        result[1] = 0.3939393939393939;

                                        result[2] = 0.5454545454545454;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 93) {
                                if (features[2] <= 72) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[5] <= 52) {
                            if (features[8] <= 91) {
                                return 4;
                            } else {
                                if (features[1] <= 71) {
                                    return 2;
                                } else {
                                    if (features[7] <= 98) {
                                        return 3;
                                    } else {
                                        result[2] = 0.5;

                                        result[3] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 81) {
                                return 3;
                            } else {
                                if (features[3] <= 98) {
                                    if (features[3] <= 88) {
                                        return 0;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.6875;

                                        result[2] = 0.0625;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 91) {
                                        return 1;
                                    } else {
                                        result[0] = 0.75;

                                        result[1] = 0.1875;

                                        result[4] = 0.0625;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[0] <= 85) {
            if (features[0] <= 74) {
                if (features[3] <= 77) {
                    if (features[6] <= 70) {
                        if (features[1] <= 81) {
                            return 0;
                        } else {
                            if (features[7] <= 91) {
                                return 3;
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[0] <= 66) {
                            if (features[6] <= 89) {
                                if (features[1] <= 68) {
                                    if (features[3] <= 67) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[8] <= 80) {
                                if (features[8] <= 74) {
                                    return 1;
                                } else {
                                    if (features[1] <= 75) {
                                        result[0] = 0.8571428571428571;

                                        result[2] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        result[0] = 0.2;

                                        result[1] = 0.8;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 68) {
                                    return 2;
                                } else {
                                    if (features[8] <= 88) {
                                        result[0] = 0.5555555555555556;

                                        result[1] = 0.4444444444444444;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[6] <= 82) {
                        if (features[0] <= 17) {
                            return 4;
                        } else {
                            if (features[0] <= 70) {
                                return 0;
                            } else {
                                if (features[7] <= 79) {
                                    if (features[6] <= 75) {
                                        return 1;
                                    } else {
                                        result[0] = 0.2857142857142857;

                                        result[1] = 0.7142857142857143;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 84) {
                            if (features[1] <= 90) {
                                if (features[0] <= 72) {
                                    return 0;
                                } else {
                                    if (features[6] <= 97) {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[3] <= 87) {
                                if (features[2] <= 77) {
                                    return 2;
                                } else {
                                    if (features[3] <= 81) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[8] <= 92) {
                                    if (features[4] <= 93) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 4;

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 83) {
                    if (features[8] <= 89) {
                        if (features[8] <= 84) {
                            if (features[8] <= 76) {
                                if (features[0] <= 78) {
                                    return 1;
                                } else {
                                    if (features[7] <= 72) {
                                        return 3;
                                    } else {
                                        result[1] = 0.17391304347826086;

                                        result[2] = 0.043478260869565216;

                                        result[3] = 0.7391304347826086;

                                        result[4] = 0.043478260869565216;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 80) {
                                    if (features[6] <= 74) {
                                        result[0] = 0.125;

                                        result[1] = 0.375;

                                        result[3] = 0.1875;

                                        result[4] = 0.3125;

                                        return 255;
                                    } else {
                                        result[0] = 0.05128205128205128;

                                        result[1] = 0.6923076923076923;

                                        result[4] = 0.2564102564102564;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 86) {
                                        result[0] = 0.045454545454545456;

                                        result[1] = 0.36363636363636365;

                                        result[2] = 0.3181818181818182;

                                        result[3] = 0.09090909090909091;

                                        result[4] = 0.18181818181818182;

                                        return 255;
                                    } else {
                                        result[1] = 0.2857142857142857;

                                        result[3] = 0.21428571428571427;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 85) {
                                if (features[8] <= 88) {
                                    if (features[6] <= 76) {
                                        return 4;
                                    } else {
                                        result[0] = 0.5454545454545454;

                                        result[1] = 0.36363636363636365;

                                        result[3] = 0.09090909090909091;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 80) {
                                        result[0] = 0.9230769230769231;

                                        result[1] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        result[0] = 0.6363636363636364;

                                        result[1] = 0.36363636363636365;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 86) {
                                    if (features[0] <= 82) {
                                        result[0] = 0.1111111111111111;

                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.2222222222222222;

                                        return 255;
                                    } else {
                                        result[1] = 0.23076923076923078;

                                        result[3] = 0.07692307692307693;

                                        result[4] = 0.6923076923076923;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 82) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[2] <= 93) {
                            if (features[0] <= 84) {
                                if (features[3] <= 71) {
                                    return 3;
                                } else {
                                    if (features[4] <= 37) {
                                        return 3;
                                    } else {
                                        result[0] = 0.85;

                                        result[1] = 0.1;

                                        result[3] = 0.025;

                                        result[4] = 0.025;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 96) {
                                    return 4;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[8] <= 92) {
                                if (features[1] <= 89) {
                                    if (features[8] <= 92) {
                                        return 0;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[1] <= 89) {
                                    if (features[1] <= 86) {
                                        return 0;
                                    } else {
                                        result[0] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 93) {
                                        result[0] = 0.25;

                                        result[1] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= 89) {
                        if (features[2] <= 88) {
                            if (features[0] <= 80) {
                                if (features[4] <= 55) {
                                    return 0;
                                } else {
                                    if (features[3] <= 75) {
                                        return 0;
                                    } else {
                                        result[0] = 0.058823529411764705;

                                        result[2] = 0.9411764705882353;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 90) {
                                    if (features[4] <= 88) {
                                        result[1] = 0.4878048780487805;

                                        result[2] = 0.4878048780487805;

                                        result[3] = 0.024390243902439025;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[3] <= 86) {
                                        result[2] = 0.7777777777777778;

                                        result[4] = 0.2222222222222222;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 85) {
                                if (features[6] <= 85) {
                                    return 4;
                                } else {
                                    if (features[3] <= 85) {
                                        return 1;
                                    } else {
                                        result[1] = 0.14285714285714285;

                                        result[3] = 0.8571428571428571;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 83) {
                                    if (features[6] <= 89) {
                                        return 1;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[8] <= 93) {
                                        result[0] = 0.6818181818181818;

                                        result[1] = 0.045454545454545456;

                                        result[2] = 0.2727272727272727;

                                        return 255;
                                    } else {
                                        result[2] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 87) {
                            if (features[3] <= 88) {
                                if (features[6] <= 86) {
                                    if (features[8] <= 90) {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.8961038961038961;

                                        result[1] = 0.05194805194805195;

                                        result[4] = 0.05194805194805195;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[2] <= 88) {
                                    if (features[0] <= 80) {
                                        return 2;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[5] <= 99) {
                                if (features[2] <= 92) {
                                    if (features[5] <= 94) {
                                        result[0] = 0.08333333333333333;

                                        result[2] = 0.8888888888888888;

                                        result[4] = 0.027777777777777776;

                                        return 255;
                                    } else {
                                        result[0] = 0.25;

                                        result[2] = 0.25;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 88) {
                                        return 1;
                                    } else {
                                        result[0] = 0.6875;

                                        result[1] = 0.125;

                                        result[2] = 0.125;

                                        result[4] = 0.0625;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 98) {
                                    if (features[8] <= 96) {
                                        result[1] = 0.8333333333333334;

                                        result[4] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 99) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[5] <= 90) {
                if (features[6] <= 84) {
                    if (features[7] <= 81) {
                        if (features[0] <= 90) {
                            if (features[0] <= 87) {
                                if (features[4] <= 83) {
                                    if (features[1] <= 93) {
                                        return 1;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[6] <= 77) {
                                        return 3;
                                    } else {
                                        result[3] = 0.6;

                                        result[4] = 0.4;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 73) {
                                    return 3;
                                } else {
                                    if (features[1] <= 84) {
                                        return 3;
                                    } else {
                                        result[3] = 0.8301886792452831;

                                        result[4] = 0.16981132075471697;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 92) {
                                if (features[8] <= 76) {
                                    if (features[4] <= 85) {
                                        return 3;
                                    } else {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 3;

                            }

                        }
                    } else {
                        if (features[7] <= 84) {
                            if (features[2] <= 84) {
                                return 0;
                            } else {
                                if (features[7] <= 83) {
                                    if (features[3] <= 88) {
                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[3] = 0.7;

                                        result[4] = 0.3;

                                        return 255;

                                    }
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[5] <= 86) {
                                if (features[0] <= 87) {
                                    if (features[2] <= 86) {
                                        result[0] = 0.5;

                                        result[3] = 0.5;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 1;

                            }

                        }

                    }
                } else {
                    if (features[6] <= 94) {
                        if (features[6] <= 89) {
                            if (features[5] <= 84) {
                                if (features[6] <= 87) {
                                    if (features[5] <= 84) {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.5714285714285714;

                                        result[4] = 0.2857142857142857;

                                        return 255;
                                    } else {
                                        result[3] = 0.8888888888888888;

                                        result[4] = 0.1111111111111111;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 84) {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.2857142857142857;

                                        result[2] = 0.14285714285714285;

                                        result[4] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        result[0] = 0.09090909090909091;

                                        result[1] = 0.6363636363636364;

                                        result[4] = 0.2727272727272727;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 86) {
                                    if (features[3] <= 85) {
                                        result[3] = 0.5833333333333334;

                                        result[4] = 0.4166666666666667;

                                        return 255;
                                    } else {
                                        result[0] = 0.03125;

                                        result[3] = 0.78125;

                                        result[4] = 0.1875;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 89) {
                                        result[0] = 0.0196078431372549;

                                        result[1] = 0.058823529411764705;

                                        result[2] = 0.0196078431372549;

                                        result[3] = 0.5098039215686274;

                                        result[4] = 0.39215686274509803;

                                        return 255;
                                    } else {
                                        result[1] = 0.1;

                                        result[4] = 0.9;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 87) {
                                if (features[2] <= 72) {
                                    if (features[6] <= 90) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[5] <= 85) {
                                        result[0] = 0.07228915662650602;

                                        result[1] = 0.8313253012048193;

                                        result[2] = 0.03614457831325301;

                                        result[3] = 0.024096385542168676;

                                        result[4] = 0.03614457831325301;

                                        return 255;
                                    } else {
                                        result[0] = 0.2;

                                        result[1] = 0.45;

                                        result[2] = 0.1;

                                        result[3] = 0.05;

                                        result[4] = 0.2;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 92) {
                                    return 4;
                                } else {
                                    if (features[0] <= 90) {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.37037037037037035;

                                        result[4] = 0.2962962962962963;

                                        return 255;
                                    } else {
                                        result[0] = 0.05263157894736842;

                                        result[1] = 0.39473684210526316;

                                        result[2] = 0.07894736842105263;

                                        result[3] = 0.05263157894736842;

                                        result[4] = 0.42105263157894735;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[4] <= 88) {
                            if (features[8] <= 82) {
                                if (features[2] <= 95) {
                                    if (features[6] <= 96) {
                                        result[0] = 0.2857142857142857;

                                        result[1] = 0.5714285714285714;

                                        result[4] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[0] <= 95) {
                                    if (features[1] <= 93) {
                                        result[0] = 0.03125;

                                        result[1] = 0.1875;

                                        result[2] = 0.46875;

                                        result[3] = 0.03125;

                                        result[4] = 0.28125;

                                        return 255;
                                    } else {
                                        result[1] = 0.5;

                                        result[3] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 99) {
                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.16666666666666666;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 90) {
                                if (features[1] <= 87) {
                                    return 2;
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[7] <= 83) {
                                    return 2;
                                } else {
                                    if (features[2] <= 89) {
                                        result[0] = 0.017543859649122806;

                                        result[1] = 0.8421052631578947;

                                        result[2] = 0.10526315789473684;

                                        result[4] = 0.03508771929824561;

                                        return 255;
                                    } else {
                                        result[0] = 0.037037037037037035;

                                        result[1] = 0.5555555555555556;

                                        result[2] = 0.037037037037037035;

                                        result[3] = 0.037037037037037035;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 88) {
                    if (features[1] <= 89) {
                        if (features[6] <= 90) {
                            if (features[7] <= 89) {
                                if (features[8] <= 91) {
                                    if (features[5] <= 93) {
                                        return 4;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[7] <= 87) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[8] <= 91) {
                                    return 2;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[3] <= 90) {
                                if (features[7] <= 98) {
                                    if (features[4] <= 92) {
                                        return 2;
                                    } else {
                                        result[0] = 0.8333333333333334;

                                        result[2] = 0.16666666666666666;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[8] <= 89) {
                                    if (features[2] <= 82) {
                                        return 2;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[7] <= 92) {
                                        result[2] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 92) {
                            if (features[6] <= 88) {
                                if (features[7] <= 100) {
                                    if (features[6] <= 86) {
                                        result[0] = 0.13793103448275862;

                                        result[1] = 0.034482758620689655;

                                        result[3] = 0.034482758620689655;

                                        result[4] = 0.7931034482758621;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[4] <= 89) {
                                    if (features[7] <= 99) {
                                        result[1] = 0.2;

                                        result[4] = 0.8;

                                        return 255;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 96) {
                                        result[0] = 0.75;

                                        result[2] = 0.15;

                                        result[4] = 0.1;

                                        return 255;
                                    } else {
                                        result[0] = 0.5555555555555556;

                                        result[4] = 0.4444444444444444;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 95) {
                                if (features[8] <= 87) {
                                    return 3;
                                } else {
                                    if (features[1] <= 94) {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[1] <= 91) {
                                    return 2;
                                } else {
                                    if (features[4] <= 94) {
                                        return 0;
                                    } else {
                                        result[0] = 0.42857142857142855;

                                        result[2] = 0.14285714285714285;

                                        result[4] = 0.42857142857142855;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= 93) {
                        if (features[0] <= 91) {
                            if (features[5] <= 90) {
                                if (features[1] <= 87) {
                                    if (features[4] <= 92) {
                                        return 2;
                                    } else {
                                        result[2] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 89) {
                                        result[1] = 0.13333333333333333;

                                        result[3] = 0.6666666666666666;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        result[1] = 0.21428571428571427;

                                        result[2] = 0.07142857142857142;

                                        result[3] = 0.42857142857142855;

                                        result[4] = 0.2857142857142857;

                                        return 255;

                                    }

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[6] <= 88) {
                                if (features[1] <= 83) {
                                    if (features[8] <= 80) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[7] <= 61) {
                                        return 3;
                                    } else {
                                        result[0] = 0.019801980198019802;

                                        result[1] = 0.009900990099009901;

                                        result[3] = 0.5643564356435643;

                                        result[4] = 0.40594059405940597;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 92) {
                                    if (features[6] <= 95) {
                                        result[0] = 0.020833333333333332;

                                        result[1] = 0.09375;

                                        result[2] = 0.08333333333333333;

                                        result[3] = 0.13541666666666666;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.04;

                                        result[1] = 0.4;

                                        result[2] = 0.08;

                                        result[3] = 0.12;

                                        result[4] = 0.36;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 95) {
                                        result[0] = 0.025;

                                        result[1] = 0.325;

                                        result[2] = 0.05;

                                        result[3] = 0.075;

                                        result[4] = 0.525;

                                        return 255;
                                    } else {
                                        result[1] = 0.7333333333333333;

                                        result[2] = 0.06666666666666667;

                                        result[4] = 0.2;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 97) {
                            if (features[8] <= 64) {
                                return 3;
                            } else {
                                if (features[1] <= 93) {
                                    if (features[6] <= 89) {
                                        result[0] = 0.08333333333333333;

                                        result[3] = 0.25;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.19607843137254902;

                                        result[1] = 0.09803921568627451;

                                        result[2] = 0.47058823529411764;

                                        result[4] = 0.23529411764705882;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 97) {
                                        result[0] = 0.015625;

                                        result[1] = 0.026041666666666668;

                                        result[2] = 0.07291666666666667;

                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.71875;

                                        return 255;
                                    } else {
                                        result[0] = 0.07964601769911504;

                                        result[1] = 0.061946902654867256;

                                        result[2] = 0.035398230088495575;

                                        result[3] = 0.3274336283185841;

                                        result[4] = 0.49557522123893805;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 98) {
                                if (features[5] <= 97) {
                                    if (features[7] <= 95) {
                                        result[0] = 0.1;

                                        result[1] = 0.13333333333333333;

                                        result[3] = 0.03333333333333333;

                                        result[4] = 0.7333333333333333;

                                        return 255;
                                    } else {
                                        result[1] = 0.11764705882352941;

                                        result[2] = 0.5882352941176471;

                                        result[4] = 0.29411764705882354;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 98) {
                                        result[0] = 0.5454545454545454;

                                        result[1] = 0.09090909090909091;

                                        result[2] = 0.06818181818181818;

                                        result[3] = 0.06818181818181818;

                                        result[4] = 0.22727272727272727;

                                        return 255;
                                    } else {
                                        result[0] = 0.18811881188118812;

                                        result[1] = 0.18811881188118812;

                                        result[2] = 0.12871287128712872;

                                        result[3] = 0.1782178217821782;

                                        result[4] = 0.31683168316831684;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 98) {
                                    if (features[0] <= 94) {
                                        result[0] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.07692307692307693;

                                        result[1] = 0.07692307692307693;

                                        result[2] = 0.07692307692307693;

                                        result[3] = 0.1794871794871795;

                                        result[4] = 0.5897435897435898;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 90) {
                                        result[1] = 0.25;

                                        result[2] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.12582781456953643;

                                        result[1] = 0.08609271523178808;

                                        result[2] = 0.2119205298013245;

                                        result[3] = 0.3443708609271523;

                                        result[4] = 0.23178807947019867;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree5(unsigned char* features, float* result){
    if (features[5] <= 82) {
        if (features[2] <= 92) {
            if (features[2] <= 77) {
                if (features[8] <= 68) {
                    if (features[6] <= 87) {
                        if (features[6] <= 63) {
                            if (features[7] <= 35) {
                                if (features[3] <= 48) {
                                    return 3;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[8] <= 51) {
                                    return 3;
                                } else {
                                    if (features[3] <= 62) {
                                        result[2] = 0.2;

                                        result[3] = 0.8;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 79) {
                                if (features[6] <= 70) {
                                    if (features[2] <= 74) {
                                        return 2;
                                    } else {
                                        result[1] = 0.125;

                                        result[3] = 0.875;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 72) {
                                        result[1] = 0.9230769230769231;

                                        result[2] = 0.07692307692307693;

                                        return 255;
                                    } else {
                                        result[0] = 0.8484848484848485;

                                        result[1] = 0.09090909090909091;

                                        result[3] = 0.06060606060606061;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 57) {
                                    return 2;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 99) {
                            if (features[4] <= 69) {
                                return 2;
                            } else {
                                if (features[8] <= 46) {
                                    return 0;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[0] <= 98) {
                                return 0;
                            } else {
                                return 4;

                            }

                        }

                    }
                } else {
                    if (features[1] <= 75) {
                        if (features[8] <= 75) {
                            if (features[7] <= 79) {
                                if (features[2] <= 8) {
                                    return 3;
                                } else {
                                    if (features[5] <= 67) {
                                        return 1;
                                    } else {
                                        result[0] = 0.32;

                                        result[1] = 0.36;

                                        result[2] = 0.24;

                                        result[3] = 0.08;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 80) {
                                    if (features[7] <= 81) {
                                        return 1;
                                    } else {
                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[6] <= 61) {
                                if (features[7] <= 66) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[6] <= 70) {
                                    if (features[0] <= 52) {
                                        return 2;
                                    } else {
                                        result[0] = 0.7777777777777778;

                                        result[1] = 0.1111111111111111;

                                        result[2] = 0.1111111111111111;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 98) {
                                        result[0] = 0.02857142857142857;

                                        result[1] = 0.06285714285714286;

                                        result[2] = 0.9028571428571428;

                                        result[4] = 0.005714285714285714;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 85) {
                            if (features[5] <= 78) {
                                if (features[7] <= 88) {
                                    if (features[6] <= 70) {
                                        result[0] = 0.4375;

                                        result[1] = 0.375;

                                        result[3] = 0.1875;

                                        return 255;
                                    } else {
                                        result[0] = 0.3375;

                                        result[1] = 0.2375;

                                        result[2] = 0.3875;

                                        result[3] = 0.0375;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[8] <= 75) {
                                    return 0;
                                } else {
                                    if (features[2] <= 53) {
                                        return 0;
                                    } else {
                                        result[0] = 0.045454545454545456;

                                        result[1] = 0.045454545454545456;

                                        result[2] = 0.9090909090909091;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 95) {
                                if (features[7] <= 90) {
                                    if (features[1] <= 86) {
                                        result[0] = 0.43023255813953487;

                                        result[1] = 0.4069767441860465;

                                        result[2] = 0.1511627906976744;

                                        result[4] = 0.011627906976744186;

                                        return 255;
                                    } else {
                                        result[0] = 0.5882352941176471;

                                        result[1] = 0.058823529411764705;

                                        result[2] = 0.23529411764705882;

                                        result[3] = 0.11764705882352941;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 91) {
                                        result[0] = 0.125;

                                        result[2] = 0.875;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[3] <= 98) {
                                    if (features[5] <= 53) {
                                        return 3;
                                    } else {
                                        result[0] = 0.875;

                                        result[1] = 0.08333333333333333;

                                        result[2] = 0.041666666666666664;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 90) {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.5714285714285714;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 76) {
                    if (features[3] <= 75) {
                        if (features[3] <= 64) {
                            if (features[6] <= 47) {
                                return 3;
                            } else {
                                if (features[0] <= 75) {
                                    if (features[5] <= 72) {
                                        result[0] = 0.25;

                                        result[3] = 0.75;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[1] <= 84) {
                                if (features[7] <= 75) {
                                    if (features[7] <= 69) {
                                        result[0] = 0.1;

                                        result[3] = 0.9;

                                        return 255;
                                    } else {
                                        result[0] = 0.16279069767441862;

                                        result[1] = 0.5348837209302325;

                                        result[2] = 0.023255813953488372;

                                        result[3] = 0.27906976744186046;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 81) {
                                        result[0] = 0.6842105263157895;

                                        result[1] = 0.3157894736842105;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[0] <= 81) {
                                    if (features[6] <= 71) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 3;

                                }

                            }

                        }
                    } else {
                        if (features[8] <= 52) {
                            return 4;
                        } else {
                            if (features[0] <= 74) {
                                if (features[5] <= 73) {
                                    return 2;
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[7] <= 80) {
                                    if (features[8] <= 83) {
                                        result[0] = 0.014925373134328358;

                                        result[1] = 0.014925373134328358;

                                        result[2] = 0.014925373134328358;

                                        result[3] = 0.9253731343283582;

                                        result[4] = 0.029850746268656716;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[3] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 90) {
                                        result[1] = 0.5;

                                        result[3] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= 87) {
                        if (features[2] <= 82) {
                            if (features[7] <= 78) {
                                if (features[5] <= 75) {
                                    if (features[4] <= 78) {
                                        return 3;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[5] <= 74) {
                                    if (features[7] <= 80) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[7] <= 84) {
                                        result[0] = 0.25925925925925924;

                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.5185185185185185;

                                        result[3] = 0.018518518518518517;

                                        result[4] = 0.037037037037037035;

                                        return 255;
                                    } else {
                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.8333333333333334;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 81) {
                                if (features[0] <= 82) {
                                    if (features[8] <= 74) {
                                        result[1] = 0.25;

                                        result[3] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.034482758620689655;

                                        result[1] = 0.7241379310344828;

                                        result[3] = 0.20689655172413793;

                                        result[4] = 0.034482758620689655;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 80) {
                                        result[2] = 0.08333333333333333;

                                        result[3] = 0.8333333333333334;

                                        result[4] = 0.08333333333333333;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[1] <= 80) {
                                    if (features[8] <= 76) {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[6] <= 100) {
                                        result[0] = 0.034482758620689655;

                                        result[1] = 0.3103448275862069;

                                        result[2] = 0.4827586206896552;

                                        result[3] = 0.13793103448275862;

                                        result[4] = 0.034482758620689655;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 80) {
                            if (features[1] <= 92) {
                                if (features[6] <= 78) {
                                    if (features[1] <= 83) {
                                        result[3] = 0.8571428571428571;

                                        result[4] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[6] <= 77) {
                                    return 4;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[3] <= 87) {
                                if (features[8] <= 80) {
                                    if (features[1] <= 85) {
                                        result[1] = 0.2857142857142857;

                                        result[3] = 0.2857142857142857;

                                        result[4] = 0.42857142857142855;

                                        return 255;
                                    } else {
                                        result[2] = 0.0625;

                                        result[3] = 0.75;

                                        result[4] = 0.1875;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 84) {
                                        result[0] = 0.5;

                                        result[3] = 0.5;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[1] <= 88) {
                                    if (features[5] <= 77) {
                                        result[0] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.2;

                                        result[1] = 0.7142857142857143;

                                        result[2] = 0.02857142857142857;

                                        result[3] = 0.02857142857142857;

                                        result[4] = 0.02857142857142857;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 82) {
                                        result[0] = 0.7142857142857143;

                                        result[3] = 0.2857142857142857;

                                        return 255;
                                    } else {
                                        result[0] = 0.22972972972972974;

                                        result[1] = 0.3108108108108108;

                                        result[2] = 0.17567567567567569;

                                        result[3] = 0.10810810810810811;

                                        result[4] = 0.17567567567567569;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[6] <= 81) {
                if (features[4] <= 90) {
                    if (features[7] <= 72) {
                        return 3;
                    } else {
                        if (features[6] <= 67) {
                            return 0;
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[1] <= 93) {
                        return 1;
                    } else {
                        return 2;

                    }

                }
            } else {
                if (features[7] <= 92) {
                    if (features[5] <= 59) {
                        return 3;
                    } else {
                        if (features[1] <= 81) {
                            return 2;
                        } else {
                            if (features[4] <= 97) {
                                return 1;
                            } else {
                                if (features[8] <= 96) {
                                    return 1;
                                } else {
                                    return 2;

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 97) {
                        if (features[3] <= 96) {
                            return 4;
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[0] <= 84) {
                            return 2;
                        } else {
                            if (features[1] <= 91) {
                                if (features[5] <= 55) {
                                    return 2;
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[3] <= 94) {
                                    if (features[8] <= 98) {
                                        return 2;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 3;

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[0] <= 85) {
            if (features[6] <= 89) {
                if (features[1] <= 85) {
                    if (features[3] <= 75) {
                        if (features[8] <= 83) {
                            if (features[2] <= 84) {
                                return 1;
                            } else {
                                if (features[7] <= 76) {
                                    return 0;
                                } else {
                                    if (features[4] <= 74) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 71) {
                                return 0;
                            } else {
                                if (features[3] <= 65) {
                                    return 2;
                                } else {
                                    if (features[4] <= 77) {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.9230769230769231;

                                        result[1] = 0.07692307692307693;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[2] <= 81) {
                            if (features[7] <= 86) {
                                if (features[4] <= 75) {
                                    return 1;
                                } else {
                                    if (features[3] <= 78) {
                                        return 0;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.5714285714285714;

                                        result[2] = 0.2857142857142857;

                                        return 255;

                                    }

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[8] <= 82) {
                                if (features[0] <= 76) {
                                    if (features[7] <= 79) {
                                        return 1;
                                    } else {
                                        result[0] = 0.7692307692307693;

                                        result[1] = 0.23076923076923078;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 81) {
                                        result[1] = 0.7142857142857143;

                                        result[3] = 0.2857142857142857;

                                        return 255;
                                    } else {
                                        result[1] = 0.14285714285714285;

                                        result[3] = 0.8571428571428571;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[8] <= 89) {
                                    if (features[8] <= 85) {
                                        result[0] = 0.125;

                                        result[1] = 0.5;

                                        result[3] = 0.125;

                                        result[4] = 0.25;

                                        return 255;
                                    } else {
                                        result[0] = 0.717948717948718;

                                        result[1] = 0.20512820512820512;

                                        result[2] = 0.05128205128205128;

                                        result[4] = 0.02564102564102564;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= 88) {
                                        result[0] = 0.8695652173913043;

                                        result[2] = 0.13043478260869565;

                                        return 255;
                                    } else {
                                        return 3;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 88) {
                        if (features[4] <= 83) {
                            if (features[1] <= 85) {
                                return 4;
                            } else {
                                if (features[0] <= 79) {
                                    if (features[5] <= 86) {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[8] <= 78) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 87) {
                                if (features[7] <= 85) {
                                    if (features[1] <= 86) {
                                        result[0] = 0.375;

                                        result[4] = 0.625;

                                        return 255;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 81) {
                                        result[0] = 0.8421052631578947;

                                        result[1] = 0.15789473684210525;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[1] <= 92) {
                                    if (features[4] <= 85) {
                                        result[0] = 0.2;

                                        result[3] = 0.6;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        result[0] = 0.08695652173913043;

                                        result[1] = 0.43478260869565216;

                                        result[3] = 0.043478260869565216;

                                        result[4] = 0.43478260869565216;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 86) {
                                        return 1;
                                    } else {
                                        result[0] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 83) {
                            if (features[8] <= 89) {
                                return 1;
                            } else {
                                if (features[6] <= 85) {
                                    if (features[8] <= 92) {
                                        result[0] = 0.5555555555555556;

                                        result[1] = 0.4444444444444444;

                                        return 255;
                                    } else {
                                        result[0] = 0.9375;

                                        result[1] = 0.0625;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[4] <= 86) {
                                return 1;
                            } else {
                                if (features[5] <= 93) {
                                    if (features[7] <= 89) {
                                        result[0] = 0.9545454545454546;

                                        result[1] = 0.022727272727272728;

                                        result[4] = 0.022727272727272728;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 89) {
                                        result[0] = 0.2;

                                        result[1] = 0.4;

                                        result[4] = 0.4;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[1] <= 86) {
                    if (features[8] <= 79) {
                        return 0;
                    } else {
                        if (features[3] <= 88) {
                            if (features[7] <= 89) {
                                if (features[6] <= 94) {
                                    if (features[0] <= 81) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[1] <= 77) {
                                        return 0;
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[5] <= 95) {
                                if (features[7] <= 95) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 4;

                            }

                        }

                    }
                } else {
                    if (features[7] <= 8) {
                        return 3;
                    } else {
                        if (features[7] <= 90) {
                            if (features[3] <= 91) {
                                if (features[8] <= 89) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[1] <= 94) {
                                if (features[2] <= 89) {
                                    return 2;
                                } else {
                                    if (features[1] <= 89) {
                                        result[1] = 0.8;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        result[2] = 0.25;

                                        result[4] = 0.75;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 95) {
                                    return 2;
                                } else {
                                    if (features[3] <= 93) {
                                        return 0;
                                    } else {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[6] <= 88) {
                if (features[7] <= 75) {
                    if (features[3] <= 100) {
                        return 3;
                    } else {
                        return 2;

                    }
                } else {
                    if (features[8] <= 87) {
                        if (features[3] <= 83) {
                            if (features[6] <= 78) {
                                if (features[6] <= 74) {
                                    if (features[6] <= 71) {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[7] <= 79) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[5] <= 95) {
                                    if (features[8] <= 62) {
                                        return 1;
                                    } else {
                                        result[1] = 0.07142857142857142;

                                        result[3] = 0.07142857142857142;

                                        result[4] = 0.8571428571428571;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 81) {
                                        return 3;
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[2] <= 85) {
                                if (features[7] <= 85) {
                                    if (features[7] <= 83) {
                                        result[3] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[1] = 0.625;

                                        result[4] = 0.375;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 67) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        result[1] = 0.25;

                                        result[2] = 0.75;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 84) {
                                    if (features[4] <= 93) {
                                        result[1] = 0.009708737864077669;

                                        result[3] = 0.8737864077669902;

                                        result[4] = 0.11650485436893204;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[1] <= 87) {
                                        result[1] = 0.25;

                                        result[2] = 0.25;

                                        result[3] = 0.4166666666666667;

                                        result[4] = 0.08333333333333333;

                                        return 255;
                                    } else {
                                        result[1] = 0.05357142857142857;

                                        result[3] = 0.6339285714285714;

                                        result[4] = 0.3125;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 91) {
                            if (features[8] <= 90) {
                                if (features[0] <= 92) {
                                    if (features[4] <= 90) {
                                        result[0] = 0.058823529411764705;

                                        result[1] = 0.23529411764705882;

                                        result[3] = 0.35294117647058826;

                                        result[4] = 0.35294117647058826;

                                        return 255;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[3] <= 85) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[3] = 0.7096774193548387;

                                        result[4] = 0.2903225806451613;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 90) {
                                    if (features[4] <= 91) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[1] <= 94) {
                                        result[0] = 0.14814814814814814;

                                        result[1] = 0.18518518518518517;

                                        result[3] = 0.1111111111111111;

                                        result[4] = 0.5555555555555556;

                                        return 255;
                                    } else {
                                        result[0] = 0.2;

                                        result[3] = 0.6;

                                        result[4] = 0.2;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 89) {
                                if (features[6] <= 84) {
                                    if (features[0] <= 90) {
                                        result[1] = 0.06666666666666667;

                                        result[4] = 0.9333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.14285714285714285;

                                        result[3] = 0.2857142857142857;

                                        result[4] = 0.42857142857142855;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 89) {
                                        result[1] = 0.2;

                                        result[4] = 0.8;

                                        return 255;
                                    } else {
                                        result[1] = 0.025;

                                        result[3] = 0.675;

                                        result[4] = 0.3;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 97) {
                                    if (features[0] <= 93) {
                                        result[0] = 0.43902439024390244;

                                        result[1] = 0.024390243902439025;

                                        result[2] = 0.008130081300813009;

                                        result[3] = 0.024390243902439025;

                                        result[4] = 0.5040650406504065;

                                        return 255;
                                    } else {
                                        result[0] = 0.0967741935483871;

                                        result[3] = 0.1935483870967742;

                                        result[4] = 0.7096774193548387;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 98) {
                                        result[0] = 0.09523809523809523;

                                        result[3] = 0.23809523809523808;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[1] = 0.5;

                                        result[3] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[5] <= 85) {
                    if (features[0] <= 86) {
                        if (features[4] <= 90) {
                            if (features[8] <= 86) {
                                if (features[3] <= 88) {
                                    if (features[1] <= 99) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[1] <= 87) {
                                    return 2;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[7] <= 87) {
                            if (features[7] <= 76) {
                                return 3;
                            } else {
                                if (features[2] <= 86) {
                                    if (features[6] <= 96) {
                                        result[0] = 0.6428571428571429;

                                        result[1] = 0.21428571428571427;

                                        result[2] = 0.07142857142857142;

                                        result[4] = 0.07142857142857142;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[4] <= 85) {
                                        result[0] = 0.3333333333333333;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 87) {
                                if (features[8] <= 87) {
                                    if (features[1] <= 86) {
                                        return 1;
                                    } else {
                                        result[1] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 94) {
                                        return 2;
                                    } else {
                                        result[2] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 91) {
                                    if (features[1] <= 86) {
                                        return 1;
                                    } else {
                                        result[0] = 0.35714285714285715;

                                        result[1] = 0.21428571428571427;

                                        result[2] = 0.07142857142857142;

                                        result[4] = 0.35714285714285715;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 82) {
                                        result[0] = 0.2857142857142857;

                                        result[1] = 0.42857142857142855;

                                        result[4] = 0.2857142857142857;

                                        return 255;
                                    } else {
                                        result[0] = 0.014492753623188406;

                                        result[1] = 0.8985507246376812;

                                        result[2] = 0.057971014492753624;

                                        result[4] = 0.028985507246376812;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= 90) {
                        if (features[0] <= 88) {
                            if (features[6] <= 93) {
                                if (features[1] <= 89) {
                                    if (features[7] <= 88) {
                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.10869565217391304;

                                        result[1] = 0.13043478260869565;

                                        result[2] = 0.5434782608695652;

                                        result[4] = 0.21739130434782608;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 85) {
                                        result[0] = 0.25;

                                        result[1] = 0.5;

                                        result[4] = 0.25;

                                        return 255;
                                    } else {
                                        result[0] = 0.6956521739130435;

                                        result[1] = 0.08695652173913043;

                                        result[2] = 0.043478260869565216;

                                        result[4] = 0.17391304347826086;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[5] <= 97) {
                                    if (features[3] <= 88) {
                                        result[0] = 0.15384615384615385;

                                        result[1] = 0.46153846153846156;

                                        result[2] = 0.23076923076923078;

                                        result[3] = 0.15384615384615385;

                                        return 255;
                                    } else {
                                        result[0] = 0.05555555555555555;

                                        result[2] = 0.8888888888888888;

                                        result[4] = 0.05555555555555555;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 91) {
                                        return 1;
                                    } else {
                                        result[0] = 0.4;

                                        result[1] = 0.2;

                                        result[4] = 0.4;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 90) {
                                if (features[5] <= 95) {
                                    if (features[2] <= 87) {
                                        return 2;
                                    } else {
                                        result[0] = 0.05;

                                        result[1] = 0.2;

                                        result[2] = 0.1;

                                        result[3] = 0.55;

                                        result[4] = 0.1;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 91) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[7] <= 77) {
                                    return 3;
                                } else {
                                    if (features[5] <= 99) {
                                        result[1] = 0.08333333333333333;

                                        result[2] = 0.8333333333333334;

                                        result[4] = 0.08333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.25;

                                        result[2] = 0.25;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 97) {
                            if (features[1] <= 93) {
                                if (features[2] <= 89) {
                                    if (features[6] <= 97) {
                                        result[0] = 0.05172413793103448;

                                        result[1] = 0.4482758620689655;

                                        result[2] = 0.06896551724137931;

                                        result[3] = 0.017241379310344827;

                                        result[4] = 0.41379310344827586;

                                        return 255;
                                    } else {
                                        result[0] = 0.08695652173913043;

                                        result[1] = 0.7391304347826086;

                                        result[2] = 0.13043478260869565;

                                        result[4] = 0.043478260869565216;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 60) {
                                        return 3;
                                    } else {
                                        result[0] = 0.07142857142857142;

                                        result[1] = 0.15873015873015872;

                                        result[2] = 0.23015873015873015;

                                        result[3] = 0.05555555555555555;

                                        result[4] = 0.48412698412698413;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[3] <= 96) {
                                    if (features[0] <= 97) {
                                        result[0] = 0.029850746268656716;

                                        result[1] = 0.024875621890547265;

                                        result[2] = 0.03980099502487562;

                                        result[3] = 0.263681592039801;

                                        result[4] = 0.6417910447761194;

                                        return 255;
                                    } else {
                                        result[0] = 0.017241379310344827;

                                        result[1] = 0.1724137931034483;

                                        result[2] = 0.10344827586206896;

                                        result[3] = 0.1896551724137931;

                                        result[4] = 0.5172413793103449;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 97) {
                                        result[0] = 0.038461538461538464;

                                        result[1] = 0.11538461538461539;

                                        result[2] = 0.038461538461538464;

                                        result[4] = 0.8076923076923077;

                                        return 255;
                                    } else {
                                        result[0] = 0.03333333333333333;

                                        result[1] = 0.35555555555555557;

                                        result[2] = 0.07777777777777778;

                                        result[3] = 0.14444444444444443;

                                        result[4] = 0.3888888888888889;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 99) {
                                if (features[0] <= 95) {
                                    if (features[6] <= 96) {
                                        result[0] = 0.6363636363636364;

                                        result[1] = 0.030303030303030304;

                                        result[3] = 0.09090909090909091;

                                        result[4] = 0.24242424242424243;

                                        return 255;
                                    } else {
                                        result[0] = 0.3181818181818182;

                                        result[1] = 0.045454545454545456;

                                        result[2] = 0.2727272727272727;

                                        result[3] = 0.13636363636363635;

                                        result[4] = 0.22727272727272727;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 98) {
                                        result[0] = 0.05263157894736842;

                                        result[1] = 0.15789473684210525;

                                        result[2] = 0.18421052631578946;

                                        result[3] = 0.05263157894736842;

                                        result[4] = 0.5526315789473685;

                                        return 255;
                                    } else {
                                        result[0] = 0.19767441860465115;

                                        result[1] = 0.11627906976744186;

                                        result[2] = 0.16279069767441862;

                                        result[3] = 0.19767441860465115;

                                        result[4] = 0.32558139534883723;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 95) {
                                    if (features[4] <= 95) {
                                        result[1] = 0.3333333333333333;

                                        result[3] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[1] = 0.23076923076923078;

                                        result[2] = 0.15384615384615385;

                                        result[4] = 0.6153846153846154;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 97) {
                                        result[0] = 0.14893617021276595;

                                        result[1] = 0.10638297872340426;

                                        result[2] = 0.0851063829787234;

                                        result[3] = 0.19148936170212766;

                                        result[4] = 0.46808510638297873;

                                        return 255;
                                    } else {
                                        result[0] = 0.08695652173913043;

                                        result[1] = 0.17391304347826086;

                                        result[2] = 0.2826086956521739;

                                        result[3] = 0.358695652173913;

                                        result[4] = 0.09782608695652174;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char evaluate_forest(float* args) {
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
float total_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char return_res = 0;
unsigned char result_map[5] = { 1,2,3,4, 9 };
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree0(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree1(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree2(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree3(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree4(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree5(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
unsigned char max_index = 0;
float max_value = 0;
for (unsigned char i = 0; i < 5; ++i) {
if (max_value < total_res[i]) {
max_value = total_res[i];
max_index = i;
}
}
return result_map[max_index];
}
