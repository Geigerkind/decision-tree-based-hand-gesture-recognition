unsigned char tree0(float* features, float* result){
    if (features[4] <= 0.024164925) {
        if (features[5] <= 0.045717433) {
            if (features[1] <= 0.050517669) {
                if (features[8] <= 0.062063593) {
                    if (features[8] <= -0.094048839) {
                        if (features[0] <= -0.041048642) {
                            result[1] = 0.6666666666666666;

                            result[2] = 0.3333333333333333;

                            return 255;
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[9] <= 0.020604981) {
                            if (features[0] <= -0.007664587) {
                                if (features[3] <= 0.016672696) {
                                    if (features[1] <= -0.010597654) {
                                        if (features[4] <= -0.015870254) {
                                            result[0] = 0.8;

                                            result[2] = 0.2;

                                            return 255;
                                        } else {
                                            result[0] = 0.03636363636363636;

                                            result[1] = 0.9090909090909091;

                                            result[3] = 0.05454545454545454;

                                            return 255;

                                        }
                                    } else {
                                        if (features[2] <= -0.005988914) {
                                            result[0] = 0.85;

                                            result[1] = 0.15;

                                            return 255;
                                        } else {
                                            result[2] = 0.4444444444444444;

                                            result[3] = 0.5555555555555556;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[6] <= 0.075197335) {
                                        if (features[4] <= 0.019907501) {
                                            result[1] = 0.9736842105263158;

                                            result[2] = 0.02631578947368421;

                                            return 255;
                                        } else {
                                            result[0] = 0.3333333333333333;

                                            result[1] = 0.4444444444444444;

                                            result[4] = 0.2222222222222222;

                                            return 255;

                                        }
                                    } else {
                                        if (features[2] <= 0.262860514) {
                                            result[0] = 0.9876543209876543;

                                            result[3] = 0.012345679012345678;

                                            return 255;
                                        } else {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 0.016749129) {
                                    if (features[9] <= -0.016728833) {
                                        if (features[5] <= -0.031308477) {
                                            result[0] = 0.5454545454545454;

                                            result[3] = 0.45454545454545453;

                                            return 255;
                                        } else {
                                            result[0] = 0.03125;

                                            result[1] = 0.09375;

                                            result[2] = 0.875;

                                            return 255;

                                        }
                                    } else {
                                        if (features[4] <= -0.005716963) {
                                            result[0] = 0.8723404255319149;

                                            result[1] = 0.10638297872340426;

                                            result[3] = 0.02127659574468085;

                                            return 255;
                                        } else {
                                            result[0] = 0.022556390977443608;

                                            result[1] = 0.21804511278195488;

                                            result[2] = 0.11278195488721804;

                                            result[3] = 0.6466165413533834;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[1] <= -0.041825261) {
                                        return 1;
                                    } else {
                                        if (features[6] <= -0.000202455) {
                                            result[0] = 0.018518518518518517;

                                            result[2] = 0.9444444444444444;

                                            result[3] = 0.037037037037037035;

                                            return 255;
                                        } else {
                                            result[0] = 0.0784313725490196;

                                            result[1] = 0.21568627450980393;

                                            result[2] = 0.11764705882352941;

                                            result[3] = 0.5686274509803921;

                                            result[4] = 0.0196078431372549;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 0.018174807) {
                                if (features[4] <= -0.056831887) {
                                    if (features[2] <= -0.087563045) {
                                        return 2;
                                    } else {
                                        if (features[8] <= 0.039741058) {
                                            result[0] = 0.9166666666666666;

                                            result[2] = 0.08333333333333333;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }
                                } else {
                                    if (features[1] <= -0.009391429) {
                                        return 2;
                                    } else {
                                        if (features[2] <= 0.000383128) {
                                            result[2] = 0.625;

                                            result[3] = 0.25;

                                            result[4] = 0.125;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= -0.026531790) {
                                    if (features[1] <= -0.003369656) {
                                        if (features[8] <= 0.017956722) {
                                            return 3;
                                        } else {
                                            result[2] = 0.5;

                                            result[3] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        result[0] = 0.7;

                                        result[2] = 0.3;

                                        return 255;

                                    }
                                } else {
                                    if (features[4] <= -0.008816013) {
                                        if (features[0] <= -0.017097679) {
                                            result[2] = 0.75;

                                            result[3] = 0.25;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[9] <= 0.029298748) {
                                            result[1] = 0.09375;

                                            result[2] = 0.90625;

                                            return 255;
                                        } else {
                                            result[2] = 0.5454545454545454;

                                            result[3] = 0.45454545454545453;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= -0.116564266) {
                        if (features[9] <= 0.021024383) {
                            if (features[6] <= 0.090436500) {
                                if (features[8] <= 0.366572410) {
                                    return 1;
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[7] <= 0.195135787) {
                                    return 0;
                                } else {
                                    result[0] = 0.5;

                                    result[1] = 0.5;

                                    return 255;

                                }

                            }
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[6] <= -0.041429766) {
                            if (features[9] <= 0.000818599) {
                                if (features[0] <= -0.007233668) {
                                    result[1] = 0.5;

                                    result[2] = 0.5;

                                    return 255;
                                } else {
                                    if (features[3] <= 0.093488593) {
                                        return 2;
                                    } else {
                                        result[1] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[8] <= 0.184110187) {
                                return 2;
                            } else {
                                if (features[3] <= -0.161694407) {
                                    return 0;
                                } else {
                                    return 2;

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 0.038988175) {
                    if (features[3] <= 0.000904223) {
                        if (features[4] <= -0.014397371) {
                            if (features[5] <= 0.012203766) {
                                if (features[7] <= -0.045515642) {
                                    result[0] = 0.3333333333333333;

                                    result[2] = 0.6666666666666666;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[9] <= -0.003464718) {
                                    return 3;
                                } else {
                                    if (features[4] <= -0.038026080) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= -0.104606859) {
                                if (features[1] <= 0.139050841) {
                                    return 3;
                                } else {
                                    result[0] = 0.3333333333333333;

                                    result[3] = 0.6666666666666666;

                                    return 255;

                                }
                            } else {
                                if (features[7] <= -0.362604991) {
                                    result[0] = 0.5;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    if (features[1] <= 0.098276068) {
                                        if (features[6] <= -0.077878201) {
                                            return 2;
                                        } else {
                                            result[0] = 0.8333333333333334;

                                            result[4] = 0.16666666666666666;

                                            return 255;

                                        }
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 0.013530674) {
                            if (features[8] <= 0.017470570) {
                                return 3;
                            } else {
                                return 2;

                            }
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[4] <= -0.067076534) {
                        if (features[2] <= 0.408494115) {
                            if (features[7] <= -0.105603654) {
                                if (features[6] <= -0.097288888) {
                                    return 0;
                                } else {
                                    return 4;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[2] <= 0.055646602) {
                            if (features[3] <= -0.054102084) {
                                if (features[8] <= -0.022255779) {
                                    if (features[1] <= 0.574202091) {
                                        if (features[6] <= -0.130668689) {
                                            result[0] = 0.6666666666666666;

                                            result[4] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[4] <= -0.003424934) {
                                        return 0;
                                    } else {
                                        if (features[8] <= 0.083695840) {
                                            result[0] = 0.5;

                                            result[4] = 0.5;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                if (features[8] <= -0.014388662) {
                                    if (features[9] <= 0.000719527) {
                                        return 4;
                                    } else {
                                        result[2] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    result[2] = 0.5;

                                    result[4] = 0.5;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[8] <= 0.365232944) {
                                if (features[2] <= 0.056554236) {
                                    result[3] = 0.5;

                                    result[4] = 0.5;

                                    return 255;
                                } else {
                                    return 4;

                                }
                            } else {
                                return 2;

                            }

                        }

                    }

                }

            }
        } else {
            if (features[7] <= 0.028748660) {
                if (features[4] <= -0.130257517) {
                    if (features[8] <= -0.026333482) {
                        return 3;
                    } else {
                        return 0;

                    }
                } else {
                    if (features[3] <= 0.039526293) {
                        if (features[9] <= 0.034756897) {
                            if (features[7] <= 0.022777005) {
                                if (features[9] <= -0.040583819) {
                                    return 3;
                                } else {
                                    if (features[1] <= 0.206999622) {
                                        if (features[4] <= -0.003687986) {
                                            return 3;
                                        } else {
                                            result[3] = 0.9285714285714286;

                                            result[4] = 0.07142857142857142;

                                            return 255;

                                        }
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= -0.017201480) {
                                    return 4;
                                } else {
                                    if (features[9] <= -0.039157863) {
                                        return 3;
                                    } else {
                                        if (features[7] <= 0.028003087) {
                                            result[3] = 0.6;

                                            result[4] = 0.4;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= 0.055039026) {
                                if (features[8] <= -0.026410813) {
                                    return 3;
                                } else {
                                    return 4;

                                }
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        if (features[8] <= 0.048091065) {
                            if (features[9] <= 0.002692067) {
                                return 3;
                            } else {
                                return 0;

                            }
                        } else {
                            return 4;

                        }

                    }

                }
            } else {
                if (features[9] <= 0.049013115) {
                    if (features[5] <= 0.081077646) {
                        if (features[8] <= -0.008305565) {
                            if (features[8] <= -0.186496392) {
                                return 3;
                            } else {
                                if (features[3] <= -0.029967242) {
                                    if (features[1] <= -0.006289939) {
                                        return 4;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[4] <= -0.015040844) {
                                if (features[3] <= -0.186669596) {
                                    if (features[3] <= -0.373053581) {
                                        return 0;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[5] <= 0.057062749) {
                                    return 0;
                                } else {
                                    if (features[0] <= -0.039306019) {
                                        if (features[6] <= 0.217889987) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 0.083803922) {
                            return 3;
                        } else {
                            if (features[0] <= 0.023452329) {
                                if (features[6] <= 0.583200395) {
                                    if (features[7] <= 0.105206147) {
                                        if (features[4] <= -0.000837298) {
                                            result[3] = 0.5833333333333334;

                                            result[4] = 0.4166666666666667;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[9] <= -0.064286308) {
                                            result[3] = 0.25;

                                            result[4] = 0.75;

                                            return 255;
                                        } else {
                                            return 4;

                                        }

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[5] <= 0.108370390) {
                                    result[0] = 0.5;

                                    result[3] = 0.25;

                                    result[4] = 0.25;

                                    return 255;
                                } else {
                                    return 3;

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 0.142898619) {
                        if (features[3] <= -0.097950399) {
                            if (features[9] <= 0.074565750) {
                                if (features[5] <= 0.082601845) {
                                    if (features[6] <= 0.260814108) {
                                        return 0;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 0.147863314) {
                                        return 1;
                                    } else {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.3333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[2] <= 0.012363252) {
                                if (features[6] <= 0.080812931) {
                                    if (features[0] <= -0.050808113) {
                                        if (features[5] <= 0.055310119) {
                                            result[1] = 0.8;

                                            result[2] = 0.2;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[4] <= -0.038694460) {
                                            return 0;
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    if (features[0] <= -0.015138477) {
                                        if (features[1] <= -0.314417645) {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;
                                        } else {
                                            result[0] = 0.9642857142857143;

                                            result[3] = 0.03571428571428571;

                                            return 255;

                                        }
                                    } else {
                                        if (features[3] <= -0.064806255) {
                                            result[1] = 0.8;

                                            result[4] = 0.2;

                                            return 255;
                                        } else {
                                            return 4;

                                        }

                                    }

                                }
                            } else {
                                if (features[1] <= -0.039077795) {
                                    if (features[1] <= -0.313818961) {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 4;

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 0.229588099) {
                            if (features[9] <= 0.061851008) {
                                result[0] = 0.5;

                                result[4] = 0.5;

                                return 255;
                            } else {
                                if (features[3] <= -0.346204162) {
                                    result[1] = 0.3333333333333333;

                                    result[4] = 0.6666666666666666;

                                    return 255;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[3] <= 0.373586997) {
                                if (features[1] <= -0.425284997) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[0] <= -0.063689101) {
                                    return 1;
                                } else {
                                    result[1] = 0.3333333333333333;

                                    result[4] = 0.6666666666666666;

                                    return 255;

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[5] <= -0.027370454) {
            if (features[1] <= 0.056757541) {
                if (features[0] <= -0.039530994) {
                    if (features[2] <= -0.077016968) {
                        if (features[1] <= -0.346471563) {
                            return 1;
                        } else {
                            return 4;

                        }
                    } else {
                        return 1;

                    }
                } else {
                    if (features[8] <= -0.135483652) {
                        return 4;
                    } else {
                        if (features[9] <= 0.021201750) {
                            return 1;
                        } else {
                            if (features[1] <= -0.210730307) {
                                result[1] = 0.75;

                                result[2] = 0.25;

                                return 255;
                            } else {
                                if (features[6] <= 0.018772942) {
                                    return 2;
                                } else {
                                    result[1] = 0.3333333333333333;

                                    result[2] = 0.6666666666666666;

                                    return 255;

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 0.097681757) {
                    result[0] = 0.5;

                    result[2] = 0.5;

                    return 255;
                } else {
                    return 4;

                }

            }
        } else {
            if (features[9] <= -0.037086947) {
                if (features[9] <= -0.069610070) {
                    if (features[5] <= 0.000397781) {
                        if (features[0] <= 0.115068309) {
                            result[1] = 0.5;

                            result[3] = 0.5;

                            return 255;
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[1] <= -0.039746298) {
                            result[3] = 0.6666666666666666;

                            result[4] = 0.3333333333333333;

                            return 255;
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[7] <= 0.053376447) {
                        if (features[7] <= -0.040633600) {
                            if (features[5] <= -0.024222498) {
                                result[1] = 0.5;

                                result[4] = 0.5;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[5] <= 0.008616881) {
                                result[1] = 0.5;

                                result[3] = 0.5;

                                return 255;
                            } else {
                                return 3;

                            }

                        }
                    } else {
                        return 4;

                    }

                }
            } else {
                if (features[8] <= -0.028562548) {
                    if (features[0] <= -0.004215911) {
                        if (features[2] <= 0.044494318) {
                            result[1] = 0.75;

                            result[2] = 0.25;

                            return 255;
                        } else {
                            result[1] = 0.75;

                            result[4] = 0.25;

                            return 255;

                        }
                    } else {
                        return 4;

                    }
                } else {
                    if (features[5] <= 0.083114084) {
                        if (features[0] <= 0.065541971) {
                            if (features[5] <= 0.021534062) {
                                if (features[1] <= -0.037907184) {
                                    return 1;
                                } else {
                                    if (features[6] <= 0.009649394) {
                                        if (features[9] <= -0.011713543) {
                                            return 0;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[0] <= 0.001813412) {
                            if (features[3] <= 0.107788078) {
                                result[0] = 0.5;

                                result[3] = 0.5;

                                return 255;
                            } else {
                                return 0;

                            }
                        } else {
                            return 4;

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree1(float* features, float* result){
    if (features[9] <= 0.022054181) {
        if (features[0] <= 0.050198682) {
            if (features[5] <= 0.057116503) {
                if (features[0] <= -0.012716918) {
                    if (features[4] <= 0.031764703) {
                        if (features[7] <= 0.060030501) {
                            if (features[3] <= -0.019825475) {
                                if (features[9] <= 0.013973520) {
                                    if (features[9] <= -0.010388278) {
                                        return 3;
                                    } else {
                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[4] <= 0.017146315) {
                                    if (features[0] <= -0.031916522) {
                                        if (features[6] <= 0.150087412) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[1] <= -0.010399749) {
                                            result[1] = 0.95;

                                            result[3] = 0.05;

                                            return 255;
                                        } else {
                                            result[0] = 0.25;

                                            result[1] = 0.25;

                                            result[3] = 0.5;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= -0.022991903) {
                                        if (features[6] <= 0.017443237) {
                                            return 1;
                                        } else {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        if (features[3] <= 0.045201663) {
                                            return 0;
                                        } else {
                                            result[0] = 0.25;

                                            result[1] = 0.5;

                                            result[4] = 0.25;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= -0.006169345) {
                                result[1] = 0.2;

                                result[3] = 0.8;

                                return 255;
                            } else {
                                if (features[0] <= -0.082573630) {
                                    return 2;
                                } else {
                                    if (features[4] <= 0.017331249) {
                                        return 0;
                                    } else {
                                        if (features[9] <= 0.013422746) {
                                            result[0] = 0.3333333333333333;

                                            result[1] = 0.6666666666666666;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[8] <= -0.158897668) {
                            if (features[2] <= -0.069984207) {
                                return 4;
                            } else {
                                return 1;

                            }
                        } else {
                            return 1;

                        }

                    }
                } else {
                    if (features[6] <= 0.023701362) {
                        if (features[3] <= -0.042234186) {
                            if (features[6] <= -0.205065571) {
                                if (features[4] <= -0.020115159) {
                                    return 0;
                                } else {
                                    if (features[1] <= 0.177511983) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[3] <= -0.047672493) {
                                    return 0;
                                } else {
                                    if (features[5] <= -0.004715389) {
                                        return 0;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= -0.056878714) {
                                if (features[3] <= 0.181862541) {
                                    if (features[6] <= -0.306566611) {
                                        return 2;
                                    } else {
                                        if (features[1] <= -0.113595493) {
                                            return 1;
                                        } else {
                                            result[0] = 0.046875;

                                            result[2] = 0.953125;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[1] <= -0.039981626) {
                                    return 1;
                                } else {
                                    if (features[9] <= 0.007628661) {
                                        if (features[6] <= 0.000187321) {
                                            result[0] = 0.1896551724137931;

                                            result[1] = 0.21551724137931033;

                                            result[2] = 0.11206896551724138;

                                            result[3] = 0.4482758620689655;

                                            result[4] = 0.034482758620689655;

                                            return 255;
                                        } else {
                                            result[0] = 0.075;

                                            result[1] = 0.25;

                                            result[2] = 0.55;

                                            result[3] = 0.1;

                                            result[4] = 0.025;

                                            return 255;

                                        }
                                    } else {
                                        if (features[3] <= -0.008318753) {
                                            result[0] = 0.9523809523809523;

                                            result[3] = 0.047619047619047616;

                                            return 255;
                                        } else {
                                            result[0] = 0.10810810810810811;

                                            result[2] = 0.7297297297297297;

                                            result[3] = 0.16216216216216217;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 0.043448269) {
                            if (features[1] <= 0.193669498) {
                                if (features[8] <= 0.004610728) {
                                    if (features[8] <= -0.058739681) {
                                        return 3;
                                    } else {
                                        if (features[8] <= -0.045374114) {
                                            return 2;
                                        } else {
                                            result[2] = 0.06;

                                            result[3] = 0.82;

                                            result[4] = 0.12;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[4] <= 0.000205207) {
                                        if (features[0] <= 0.009722509) {
                                            result[1] = 0.2;

                                            result[3] = 0.8;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[8] <= 0.016553144) {
                                            return 0;
                                        } else {
                                            result[1] = 0.3333333333333333;

                                            result[2] = 0.6666666666666666;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= -0.299279243) {
                                    if (features[1] <= 0.304169387) {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[7] <= 0.147303544) {
                                if (features[8] <= -0.029985399) {
                                    if (features[8] <= -0.083591979) {
                                        return 3;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[1] = 0.3333333333333333;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 0.085030574) {
                                        if (features[3] <= -0.054244643) {
                                            result[0] = 0.3;

                                            result[1] = 0.7;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[6] <= 0.079690289) {
                                            result[0] = 0.3333333333333333;

                                            result[1] = 0.6666666666666666;

                                            return 255;
                                        } else {
                                            return 1;

                                        }

                                    }

                                }
                            } else {
                                if (features[9] <= 0.004993202) {
                                    if (features[8] <= -0.092102677) {
                                        return 3;
                                    } else {
                                        if (features[8] <= 0.006208145) {
                                            result[0] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[6] <= 0.094623957) {
                                        return 0;
                                    } else {
                                        if (features[3] <= -0.101575924) {
                                            return 1;
                                        } else {
                                            result[1] = 0.4;

                                            result[3] = 0.6;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[5] <= 0.070769433) {
                    if (features[8] <= -0.074853692) {
                        if (features[1] <= -0.022818124) {
                            result[3] = 0.6666666666666666;

                            result[4] = 0.3333333333333333;

                            return 255;
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[1] <= 0.061153615) {
                            if (features[4] <= 0.024034706) {
                                if (features[7] <= -0.007139745) {
                                    return 3;
                                } else {
                                    if (features[6] <= 0.202840410) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                result[1] = 0.6666666666666666;

                                result[3] = 0.3333333333333333;

                                return 255;

                            }
                        } else {
                            if (features[8] <= 0.040594103) {
                                return 1;
                            } else {
                                return 0;

                            }

                        }

                    }
                } else {
                    if (features[4] <= -0.009758678) {
                        if (features[1] <= -0.050774507) {
                            if (features[8] <= 0.031652536) {
                                if (features[2] <= -0.007543729) {
                                    if (features[4] <= -0.056913007) {
                                        if (features[6] <= 0.301363833) {
                                            return 3;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[7] <= 0.099011429) {
                                            result[3] = 0.5;

                                            result[4] = 0.5;

                                            return 255;
                                        } else {
                                            return 4;

                                        }

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[0] <= -0.029414138) {
                                if (features[6] <= 0.258670181) {
                                    return 3;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[7] <= 0.080567885) {
                                    return 3;
                                } else {
                                    if (features[0] <= 0.021157953) {
                                        return 4;
                                    } else {
                                        return 3;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[9] <= -0.033152957) {
                            if (features[7] <= 0.133128926) {
                                return 3;
                            } else {
                                if (features[3] <= 0.163424127) {
                                    return 3;
                                } else {
                                    if (features[7] <= 0.233366117) {
                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 0.028791271) {
                                if (features[5] <= 0.148904003) {
                                    return 3;
                                } else {
                                    if (features[8] <= -0.062822060) {
                                        if (features[4] <= 0.000000000) {
                                            result[3] = 0.3333333333333333;

                                            result[4] = 0.6666666666666666;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[0] <= -0.043310920) {
                                    return 0;
                                } else {
                                    if (features[6] <= 0.406591132) {
                                        return 4;
                                    } else {
                                        if (features[0] <= 0.001816136) {
                                            result[3] = 0.5;

                                            result[4] = 0.5;

                                            return 255;
                                        } else {
                                            return 4;

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[2] <= 0.088573907) {
                if (features[4] <= -0.018100302) {
                    if (features[4] <= -0.105095584) {
                        return 0;
                    } else {
                        if (features[3] <= -0.067082131) {
                            if (features[2] <= -0.082960434) {
                                if (features[8] <= -0.052251272) {
                                    return 4;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[6] <= 0.001409285) {
                                result[0] = 0.3333333333333333;

                                result[4] = 0.6666666666666666;

                                return 255;
                            } else {
                                return 3;

                            }

                        }

                    }
                } else {
                    if (features[3] <= -0.271859854) {
                        if (features[9] <= -0.027349641) {
                            return 4;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[2] <= 0.005546950) {
                            return 4;
                        } else {
                            if (features[9] <= -0.052338611) {
                                return 3;
                            } else {
                                if (features[8] <= 0.006189841) {
                                    return 4;
                                } else {
                                    if (features[4] <= 0.048724003) {
                                        if (features[5] <= -0.017703662) {
                                            return 0;
                                        } else {
                                            result[1] = 0.5;

                                            result[4] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[4] <= -0.109372824) {
                    if (features[8] <= -0.081491387) {
                        return 4;
                    } else {
                        return 0;

                    }
                } else {
                    return 4;

                }

            }

        }
    } else {
        if (features[6] <= 0.050598638) {
            if (features[8] <= 0.051272193) {
                if (features[1] <= 0.070669007) {
                    if (features[4] <= 0.029627992) {
                        if (features[0] <= 0.050955858) {
                            if (features[6] <= 0.019064561) {
                                if (features[9] <= 0.026239423) {
                                    if (features[5] <= -0.001389207) {
                                        return 3;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[1] <= -0.089892715) {
                                        if (features[5] <= -0.012453578) {
                                            return 2;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[3] <= -0.021185084) {
                                            result[2] = 0.4444444444444444;

                                            result[4] = 0.5555555555555556;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= -0.006541167) {
                                    if (features[2] <= -0.016209072) {
                                        if (features[4] <= -0.015841213) {
                                            result[2] = 0.3333333333333333;

                                            result[3] = 0.6666666666666666;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[9] <= 0.031647404) {
                                            result[0] = 0.025;

                                            result[2] = 0.975;

                                            return 255;
                                        } else {
                                            result[2] = 0.5;

                                            result[3] = 0.5;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[8] <= 0.048965951) {
                                        if (features[5] <= 0.021977033) {
                                            result[2] = 0.75;

                                            result[3] = 0.25;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 0.025191276) {
                                return 0;
                            } else {
                                result[0] = 0.5;

                                result[2] = 0.5;

                                return 255;

                            }

                        }
                    } else {
                        if (features[0] <= 0.003459737) {
                            return 1;
                        } else {
                            return 2;

                        }

                    }
                } else {
                    if (features[4] <= -0.027031713) {
                        return 0;
                    } else {
                        return 4;

                    }

                }
            } else {
                if (features[1] <= -0.219747812) {
                    if (features[6] <= -0.230322950) {
                        result[1] = 0.3333333333333333;

                        result[2] = 0.6666666666666666;

                        return 255;
                    } else {
                        if (features[4] <= 0.029816005) {
                            result[1] = 0.5;

                            result[2] = 0.5;

                            return 255;
                        } else {
                            return 1;

                        }

                    }
                } else {
                    if (features[1] <= 0.202052556) {
                        if (features[6] <= -0.012868362) {
                            return 2;
                        } else {
                            if (features[7] <= 0.016732028) {
                                if (features[3] <= 0.022863910) {
                                    if (features[0] <= 0.057841188) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    result[1] = 0.5;

                                    result[2] = 0.25;

                                    result[4] = 0.25;

                                    return 255;

                                }
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[4] <= -0.023018900) {
                            return 0;
                        } else {
                            return 2;

                        }

                    }

                }

            }
        } else {
            if (features[4] <= -0.026912540) {
                if (features[9] <= 0.049037263) {
                    if (features[8] <= 0.065945163) {
                        return 3;
                    } else {
                        if (features[6] <= 0.181264654) {
                            return 0;
                        } else {
                            return 4;

                        }

                    }
                } else {
                    if (features[5] <= 0.179600440) {
                        if (features[4] <= -0.031292425) {
                            if (features[7] <= 0.062780665) {
                                if (features[8] <= 0.051049141) {
                                    result[0] = 0.6666666666666666;

                                    result[3] = 0.3333333333333333;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[2] <= 0.040873673) {
                                    if (features[5] <= 0.076520879) {
                                        if (features[8] <= 0.075783629) {
                                            result[0] = 0.7333333333333333;

                                            result[1] = 0.26666666666666666;

                                            return 255;
                                        } else {
                                            result[0] = 0.13636363636363635;

                                            result[1] = 0.8636363636363636;

                                            return 255;

                                        }
                                    } else {
                                        if (features[4] <= -0.045085637) {
                                            return 1;
                                        } else {
                                            result[1] = 0.6666666666666666;

                                            result[4] = 0.3333333333333333;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[6] <= 0.225425102) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }
                        } else {
                            if (features[2] <= -0.016505956) {
                                result[1] = 0.6666666666666666;

                                result[4] = 0.3333333333333333;

                                return 255;
                            } else {
                                if (features[9] <= 0.061001843) {
                                    result[0] = 0.5;

                                    result[4] = 0.5;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        return 4;

                    }

                }
            } else {
                if (features[1] <= -0.103889886) {
                    if (features[2] <= -0.027254691) {
                        if (features[0] <= -0.035904396) {
                            if (features[5] <= 0.080685209) {
                                return 1;
                            } else {
                                result[0] = 0.5;

                                result[1] = 0.5;

                                return 255;

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[8] <= 0.161019884) {
                            return 0;
                        } else {
                            result[0] = 0.5;

                            result[2] = 0.5;

                            return 255;

                        }

                    }
                } else {
                    if (features[6] <= 0.065534551) {
                        if (features[0] <= -0.003969880) {
                            return 1;
                        } else {
                            return 3;

                        }
                    } else {
                        if (features[8] <= -0.042022796) {
                            if (features[1] <= 0.078292686) {
                                if (features[8] <= -0.264916010) {
                                    result[3] = 0.3333333333333333;

                                    result[4] = 0.6666666666666666;

                                    return 255;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[3] <= 0.039890742) {
                                    return 3;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[3] <= -0.173242621) {
                                result[0] = 0.3333333333333333;

                                result[4] = 0.6666666666666666;

                                return 255;
                            } else {
                                if (features[0] <= -0.052343464) {
                                    result[1] = 0.5;

                                    result[4] = 0.5;

                                    return 255;
                                } else {
                                    return 4;

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree2(float* features, float* result){
    if (features[6] <= 0.042409390) {
        if (features[8] <= 0.051717604) {
            if (features[4] <= 0.017548824) {
                if (features[1] <= 0.053209022) {
                    if (features[9] <= 0.017400337) {
                        if (features[1] <= -0.030766673) {
                            if (features[2] <= -0.003837447) {
                                if (features[4] <= -0.026228707) {
                                    return 3;
                                } else {
                                    if (features[6] <= -0.039853548) {
                                        result[1] = 0.2;

                                        result[2] = 0.8;

                                        return 255;
                                    } else {
                                        if (features[0] <= -0.005098083) {
                                            return 1;
                                        } else {
                                            result[1] = 0.5;

                                            result[3] = 0.5;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[0] <= 0.135873795) {
                                if (features[7] <= 0.004049268) {
                                    if (features[9] <= -0.044874793) {
                                        return 3;
                                    } else {
                                        if (features[7] <= -0.000976865) {
                                            result[0] = 0.2;

                                            result[1] = 0.4;

                                            result[2] = 0.1;

                                            result[3] = 0.3;

                                            return 255;
                                        } else {
                                            result[0] = 0.015151515151515152;

                                            result[1] = 0.015151515151515152;

                                            result[2] = 0.22727272727272727;

                                            result[3] = 0.7424242424242424;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[4] <= -0.008210296) {
                                        if (features[5] <= 0.012530697) {
                                            result[0] = 0.7435897435897436;

                                            result[1] = 0.15384615384615385;

                                            result[2] = 0.10256410256410256;

                                            return 255;
                                        } else {
                                            result[0] = 0.125;

                                            result[1] = 0.625;

                                            result[3] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        if (features[1] <= -0.000279252) {
                                            result[1] = 0.10526315789473684;

                                            result[2] = 0.8157894736842105;

                                            result[3] = 0.07894736842105263;

                                            return 255;
                                        } else {
                                            result[0] = 0.12195121951219512;

                                            result[1] = 0.024390243902439025;

                                            result[2] = 0.21951219512195122;

                                            result[3] = 0.6341463414634146;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[7] <= 0.012763201) {
                            if (features[4] <= -0.060621237) {
                                if (features[0] <= 0.027551512) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[5] <= -0.043999145) {
                                    return 2;
                                } else {
                                    if (features[5] <= 0.004380491) {
                                        if (features[9] <= 0.022391680) {
                                            return 0;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[2] <= -0.010625623) {
                                if (features[6] <= 0.029812237) {
                                    if (features[0] <= -0.021042613) {
                                        if (features[9] <= 0.029188419) {
                                            result[2] = 0.6666666666666666;

                                            result[3] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[3] <= -0.009670205) {
                                            return 0;
                                        } else {
                                            return 2;

                                        }

                                    }
                                } else {
                                    if (features[8] <= 0.026529472) {
                                        return 3;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[4] <= -0.006534274) {
                                    if (features[0] <= -0.011468785) {
                                        return 2;
                                    } else {
                                        if (features[6] <= 0.010796351) {
                                            return 2;
                                        } else {
                                            return 3;

                                        }

                                    }
                                } else {
                                    if (features[8] <= 0.015838693) {
                                        if (features[3] <= -0.000647354) {
                                            return 3;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[7] <= 0.022651578) {
                                            result[2] = 0.9285714285714286;

                                            result[3] = 0.07142857142857142;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= -0.015896747) {
                        if (features[6] <= -0.105900943) {
                            if (features[1] <= 0.386039466) {
                                return 0;
                            } else {
                                if (features[5] <= -0.068657499) {
                                    return 0;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[6] <= -0.017709202) {
                                if (features[5] <= -0.053501088) {
                                    return 0;
                                } else {
                                    if (features[3] <= -0.128082231) {
                                        if (features[8] <= -0.051692447) {
                                            return 4;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[1] <= 0.549161479) {
                                    if (features[8] <= -0.061865849) {
                                        return 4;
                                    } else {
                                        if (features[0] <= 0.076021146) {
                                            result[0] = 0.2;

                                            result[3] = 0.8;

                                            return 255;
                                        } else {
                                            result[0] = 0.6;

                                            result[4] = 0.4;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 0.003566177) {
                            if (features[2] <= 0.022189671) {
                                return 0;
                            } else {
                                if (features[2] <= 0.030063769) {
                                    if (features[5] <= -0.022515465) {
                                        return 0;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            result[2] = 0.3333333333333333;

                            result[4] = 0.6666666666666666;

                            return 255;

                        }

                    }

                }
            } else {
                if (features[3] <= 0.204966307) {
                    if (features[4] <= 0.115376242) {
                        if (features[0] <= 0.074841015) {
                            if (features[2] <= 0.066310221) {
                                if (features[6] <= 0.004059984) {
                                    if (features[1] <= -0.017076969) {
                                        if (features[7] <= 0.013228748) {
                                            return 1;
                                        } else {
                                            result[1] = 0.6666666666666666;

                                            result[3] = 0.3333333333333333;

                                            return 255;

                                        }
                                    } else {
                                        if (features[2] <= -0.027592515) {
                                            result[0] = 0.6;

                                            result[2] = 0.4;

                                            return 255;
                                        } else {
                                            result[0] = 0.05555555555555555;

                                            result[1] = 0.16666666666666666;

                                            result[2] = 0.1111111111111111;

                                            result[3] = 0.6666666666666666;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= -0.019278660) {
                                        result[1] = 0.25;

                                        result[3] = 0.75;

                                        return 255;
                                    } else {
                                        if (features[5] <= 0.016159465) {
                                            result[0] = 0.875;

                                            result[4] = 0.125;

                                            return 255;
                                        } else {
                                            result[3] = 0.5;

                                            result[4] = 0.5;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[9] <= -0.011207245) {
                                    result[0] = 0.5;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[1] <= 0.078275956) {
                            if (features[2] <= -0.131489124) {
                                return 4;
                            } else {
                                if (features[5] <= -0.000502385) {
                                    return 1;
                                } else {
                                    result[1] = 0.5;

                                    result[3] = 0.5;

                                    return 255;

                                }

                            }
                        } else {
                            return 4;

                        }

                    }
                } else {
                    if (features[0] <= 0.026838142) {
                        if (features[3] <= 0.310565144) {
                            if (features[3] <= 0.308307275) {
                                return 1;
                            } else {
                                return 4;

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        return 4;

                    }

                }

            }
        } else {
            if (features[0] <= 0.028994523) {
                if (features[9] <= 0.021538815) {
                    if (features[5] <= 0.003079696) {
                        if (features[1] <= -0.135214999) {
                            return 1;
                        } else {
                            if (features[6] <= -0.198278837) {
                                if (features[5] <= -0.002835156) {
                                    return 2;
                                } else {
                                    if (features[8] <= 0.192195021) {
                                        if (features[3] <= -0.161678597) {
                                            result[0] = 0.75;

                                            result[2] = 0.25;

                                            return 255;
                                        } else {
                                            result[0] = 0.18181818181818182;

                                            result[2] = 0.8181818181818182;

                                            return 255;

                                        }
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[2] <= 0.014177256) {
                                    if (features[3] <= -0.046721656) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[4] <= -0.000729094) {
                                        return 2;
                                    } else {
                                        if (features[2] <= 0.035829531) {
                                            result[1] = 0.3333333333333333;

                                            result[3] = 0.6666666666666666;

                                            return 255;
                                        } else {
                                            result[0] = 0.8571428571428571;

                                            result[1] = 0.14285714285714285;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[4] <= -0.009927218) {
                            result[0] = 0.5;

                            result[2] = 0.5;

                            return 255;
                        } else {
                            return 2;

                        }

                    }
                } else {
                    if (features[1] <= -0.129419796) {
                        if (features[3] <= 0.075291406) {
                            return 2;
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[0] <= -0.139870133) {
                            return 1;
                        } else {
                            return 2;

                        }

                    }

                }
            } else {
                if (features[8] <= 0.220887274) {
                    if (features[8] <= 0.084553644) {
                        if (features[7] <= -0.206396466) {
                            return 4;
                        } else {
                            if (features[4] <= 0.012645287) {
                                return 0;
                            } else {
                                result[0] = 0.5;

                                result[1] = 0.5;

                                return 255;

                            }

                        }
                    } else {
                        return 0;

                    }
                } else {
                    if (features[3] <= -0.158906311) {
                        return 0;
                    } else {
                        if (features[2] <= 0.195914343) {
                            return 2;
                        } else {
                            return 4;

                        }

                    }

                }

            }

        }
    } else {
        if (features[7] <= 0.032606887) {
            if (features[0] <= 0.103616055) {
                if (features[8] <= 0.004041887) {
                    if (features[1] <= 0.216197245) {
                        if (features[5] <= 0.059294289) {
                            if (features[1] <= -0.254477672) {
                                return 0;
                            } else {
                                if (features[5] <= -0.018044394) {
                                    result[1] = 0.5;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    if (features[7] <= -0.003347874) {
                                        return 3;
                                    } else {
                                        if (features[6] <= 0.057330236) {
                                            return 2;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 0.012621310) {
                                if (features[2] <= 0.153179303) {
                                    if (features[2] <= -0.115601614) {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        if (features[7] <= -0.006296425) {
                                            return 3;
                                        } else {
                                            result[3] = 0.9714285714285714;

                                            result[4] = 0.02857142857142857;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[2] <= 0.206271350) {
                                        return 4;
                                    } else {
                                        result[3] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[2] <= 0.027185700) {
                                    if (features[4] <= -0.007998514) {
                                        if (features[0] <= 0.003233993) {
                                            return 3;
                                        } else {
                                            result[3] = 0.6;

                                            result[4] = 0.4;

                                            return 255;

                                        }
                                    } else {
                                        if (features[4] <= 0.000661114) {
                                            return 4;
                                        } else {
                                            result[3] = 0.36363636363636365;

                                            result[4] = 0.6363636363636364;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 3;

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 0.026913044) {
                            if (features[9] <= -0.012334149) {
                                return 3;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[0] <= 0.030300041) {
                                return 1;
                            } else {
                                result[1] = 0.3333333333333333;

                                result[3] = 0.6666666666666666;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[5] <= 0.054088546) {
                        if (features[0] <= 0.025777385) {
                            if (features[7] <= -0.018949381) {
                                return 3;
                            } else {
                                if (features[0] <= -0.053248423) {
                                    return 1;
                                } else {
                                    if (features[9] <= 0.001343144) {
                                        return 0;
                                    } else {
                                        if (features[3] <= -0.019887831) {
                                            return 1;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[8] <= 0.049491314) {
                            if (features[6] <= 0.163100220) {
                                return 4;
                            } else {
                                result[3] = 0.6666666666666666;

                                result[4] = 0.3333333333333333;

                                return 255;

                            }
                        } else {
                            return 4;

                        }

                    }

                }
            } else {
                if (features[6] <= 0.067070019) {
                    if (features[5] <= -0.019668039) {
                        result[0] = 0.5;

                        result[4] = 0.5;

                        return 255;
                    } else {
                        return 4;

                    }
                } else {
                    if (features[4] <= -0.029791445) {
                        if (features[2] <= 0.066668347) {
                            return 0;
                        } else {
                            result[0] = 0.3333333333333333;

                            result[4] = 0.6666666666666666;

                            return 255;

                        }
                    } else {
                        return 4;

                    }

                }

            }
        } else {
            if (features[5] <= 0.113452610) {
                if (features[1] <= -0.098578919) {
                    if (features[1] <= -0.312549636) {
                        if (features[2] <= -0.033267383) {
                            return 1;
                        } else {
                            if (features[1] <= -0.420366272) {
                                return 1;
                            } else {
                                if (features[6] <= 0.145669408) {
                                    return 1;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[2] <= -0.056930402) {
                            if (features[5] <= 0.052888321) {
                                if (features[1] <= -0.188695543) {
                                    if (features[6] <= 0.201908685) {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[8] <= -0.007630549) {
                                        return 3;
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[3] <= -0.000438645) {
                                result[1] = 0.8333333333333334;

                                result[4] = 0.16666666666666666;

                                return 255;
                            } else {
                                if (features[8] <= 0.041080369) {
                                    return 0;
                                } else {
                                    if (features[4] <= -0.037984487) {
                                        return 1;
                                    } else {
                                        if (features[5] <= 0.022954151) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= -0.019433866) {
                        if (features[1] <= 0.246209688) {
                            if (features[5] <= 0.048385959) {
                                if (features[8] <= -0.086144000) {
                                    return 3;
                                } else {
                                    result[3] = 0.8;

                                    result[4] = 0.2;

                                    return 255;

                                }
                            } else {
                                if (features[6] <= 0.134806551) {
                                    return 4;
                                } else {
                                    if (features[3] <= 0.020174575) {
                                        if (features[6] <= 0.221526057) {
                                            result[3] = 0.8461538461538461;

                                            result[4] = 0.15384615384615385;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[1] <= 0.098311055) {
                                            return 4;
                                        } else {
                                            result[3] = 0.6666666666666666;

                                            result[4] = 0.3333333333333333;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= -0.001486700) {
                                if (features[7] <= 0.063109469) {
                                    return 1;
                                } else {
                                    result[0] = 0.5;

                                    result[1] = 0.5;

                                    return 255;

                                }
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        if (features[1] <= 0.048087036) {
                            if (features[0] <= -0.025497835) {
                                if (features[0] <= -0.049356816) {
                                    if (features[8] <= 0.052596284) {
                                        return 3;
                                    } else {
                                        if (features[1] <= -0.083916724) {
                                            result[0] = 0.6;

                                            result[1] = 0.4;

                                            return 255;
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    if (features[6] <= 0.072332524) {
                                        if (features[3] <= -0.040570366) {
                                            return 0;
                                        } else {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        if (features[5] <= 0.074709132) {
                                            return 0;
                                        } else {
                                            result[0] = 0.75;

                                            result[3] = 0.25;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 0.084325634) {
                                    if (features[3] <= -0.062219072) {
                                        return 0;
                                    } else {
                                        if (features[3] <= 0.038198102) {
                                            result[1] = 0.5555555555555556;

                                            result[3] = 0.2777777777777778;

                                            result[4] = 0.16666666666666666;

                                            return 255;
                                        } else {
                                            result[0] = 0.7142857142857143;

                                            result[1] = 0.2857142857142857;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[5] <= 0.047324354) {
                                        return 1;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[3] <= 0.030285729) {
                                if (features[3] <= -0.274466842) {
                                    if (features[1] <= 0.427552968) {
                                        return 0;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 0.085562516) {
                                        return 0;
                                    } else {
                                        if (features[4] <= -0.013591211) {
                                            result[0] = 0.051094890510948905;

                                            result[1] = 0.948905109489051;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                return 4;

                            }

                        }

                    }

                }
            } else {
                if (features[9] <= 0.048794497) {
                    if (features[9] <= -0.193804964) {
                        return 3;
                    } else {
                        if (features[0] <= 0.015950486) {
                            if (features[7] <= 0.110563766) {
                                if (features[2] <= -0.081094131) {
                                    return 3;
                                } else {
                                    if (features[2] <= -0.030140414) {
                                        return 4;
                                    } else {
                                        if (features[4] <= -0.009790345) {
                                            return 3;
                                        } else {
                                            return 4;

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= 0.009417010) {
                                    return 4;
                                } else {
                                    if (features[9] <= -0.053793255) {
                                        result[3] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 0.042663919) {
                                if (features[3] <= 0.053891851) {
                                    return 3;
                                } else {
                                    result[3] = 0.5;

                                    result[4] = 0.5;

                                    return 255;

                                }
                            } else {
                                return 4;

                            }

                        }

                    }
                } else {
                    if (features[1] <= 0.077140331) {
                        if (features[0] <= -0.073614599) {
                            return 0;
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[8] <= 0.159264788) {
                            if (features[8] <= 0.130258009) {
                                return 1;
                            } else {
                                result[0] = 0.5;

                                result[1] = 0.5;

                                return 255;

                            }
                        } else {
                            return 4;

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree3(float* features, float* result){
    if (features[8] <= -0.026776557) {
        if (features[0] <= 0.047936965) {
            if (features[6] <= 0.030603847) {
                if (features[4] <= 0.026467522) {
                    if (features[5] <= 0.040465124) {
                        if (features[6] <= -0.150381580) {
                            if (features[8] <= -0.084620837) {
                                result[1] = 0.6666666666666666;

                                result[2] = 0.3333333333333333;

                                return 255;
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[1] <= 0.022448606) {
                                if (features[5] <= -0.008189990) {
                                    if (features[7] <= -0.009147914) {
                                        if (features[9] <= 0.027931986) {
                                            return 1;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[9] <= -0.009928109) {
                                        return 2;
                                    } else {
                                        if (features[2] <= 0.050323572) {
                                            return 3;
                                        } else {
                                            result[3] = 0.5;

                                            result[4] = 0.5;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= -0.031798848) {
                                    if (features[2] <= 0.013565168) {
                                        return 0;
                                    } else {
                                        result[0] = 0.8;

                                        result[1] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= -0.007983637) {
                                        return 4;
                                    } else {
                                        if (features[4] <= 0.000527426) {
                                            return 0;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= -0.100330982) {
                            return 4;
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[7] <= -0.152598277) {
                        if (features[6] <= -0.165789753) {
                            result[1] = 0.5;

                            result[4] = 0.5;

                            return 255;
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[3] <= 0.071427323) {
                            if (features[4] <= 0.099978138) {
                                result[0] = 0.25;

                                result[3] = 0.75;

                                return 255;
                            } else {
                                return 1;

                            }
                        } else {
                            return 1;

                        }

                    }

                }
            } else {
                if (features[3] <= -0.246645339) {
                    if (features[4] <= -0.034011341) {
                        if (features[3] <= -0.350272700) {
                            result[3] = 0.6666666666666666;

                            result[4] = 0.3333333333333333;

                            return 255;
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[6] <= 0.198012203) {
                            return 0;
                        } else {
                            if (features[9] <= 0.011525942) {
                                result[1] = 0.6666666666666666;

                                result[4] = 0.3333333333333333;

                                return 255;
                            } else {
                                return 1;

                            }

                        }

                    }
                } else {
                    if (features[1] <= -0.020713532) {
                        if (features[9] <= 0.002584416) {
                            if (features[8] <= -0.389471009) {
                                return 3;
                            } else {
                                if (features[8] <= -0.125737432) {
                                    if (features[1] <= -0.070822377) {
                                        if (features[6] <= 0.376547009) {
                                            result[3] = 0.6666666666666666;

                                            result[4] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[3] <= -0.007694847) {
                                            return 3;
                                        } else {
                                            result[3] = 0.3333333333333333;

                                            result[4] = 0.6666666666666666;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[0] <= -0.021467220) {
                                if (features[3] <= -0.001891470) {
                                    return 3;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        if (features[7] <= 0.093684230) {
                            if (features[3] <= 0.016798542) {
                                if (features[4] <= 0.021598700) {
                                    return 3;
                                } else {
                                    if (features[6] <= 0.330752164) {
                                        result[1] = 0.3333333333333333;

                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[2] <= 0.026220491) {
                                    if (features[6] <= 0.243823081) {
                                        if (features[2] <= 0.013279430) {
                                            result[2] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            result[2] = 0.16666666666666666;

                                            result[4] = 0.8333333333333334;

                                            return 255;

                                        }
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[2] <= 0.165467672) {
                                        return 3;
                                    } else {
                                        if (features[8] <= -0.269195780) {
                                            result[3] = 0.5;

                                            result[4] = 0.5;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= -0.066169284) {
                                return 3;
                            } else {
                                if (features[1] <= 0.095290516) {
                                    if (features[4] <= -0.011208422) {
                                        return 4;
                                    } else {
                                        if (features[4] <= -0.002288526) {
                                            return 3;
                                        } else {
                                            result[3] = 0.5263157894736842;

                                            result[4] = 0.47368421052631576;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[9] <= -0.032647232) {
                                        result[3] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[3] <= -0.031215481) {
                if (features[6] <= -0.244107507) {
                    return 0;
                } else {
                    if (features[4] <= -0.107923504) {
                        if (features[7] <= -0.085032783) {
                            result[0] = 0.3333333333333333;

                            result[4] = 0.6666666666666666;

                            return 255;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[2] <= -0.207345404) {
                            if (features[9] <= -0.023405422) {
                                return 4;
                            } else {
                                result[0] = 0.6666666666666666;

                                result[4] = 0.3333333333333333;

                                return 255;

                            }
                        } else {
                            if (features[6] <= 0.080118444) {
                                return 4;
                            } else {
                                result[3] = 0.5;

                                result[4] = 0.5;

                                return 255;

                            }

                        }

                    }

                }
            } else {
                if (features[5] <= 0.073889359) {
                    if (features[5] <= -0.053721014) {
                        if (features[4] <= -0.128059938) {
                            return 0;
                        } else {
                            return 4;

                        }
                    } else {
                        return 4;

                    }
                } else {
                    if (features[7] <= 0.050021843) {
                        return 3;
                    } else {
                        return 4;

                    }

                }

            }

        }
    } else {
        if (features[9] <= 0.095396329) {
            if (features[5] <= 0.046987310) {
                if (features[3] <= -0.026674242) {
                    if (features[3] <= -0.257385164) {
                        if (features[0] <= -0.019439765) {
                            return 2;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[6] <= 0.026857482) {
                            if (features[8] <= 0.220604904) {
                                if (features[0] <= -0.021260382) {
                                    return 2;
                                } else {
                                    if (features[4] <= -0.027172748) {
                                        return 0;
                                    } else {
                                        if (features[2] <= 0.022648375) {
                                            result[0] = 0.9516129032258065;

                                            result[2] = 0.04838709677419355;

                                            return 255;
                                        } else {
                                            result[0] = 0.4;

                                            result[4] = 0.6;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[4] <= -0.013470491) {
                                if (features[5] <= -0.004163117) {
                                    if (features[3] <= -0.208484083) {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[9] <= 0.023380270) {
                                        if (features[5] <= 0.014675373) {
                                            result[0] = 0.1111111111111111;

                                            result[1] = 0.7777777777777778;

                                            result[2] = 0.1111111111111111;

                                            return 255;
                                        } else {
                                            result[1] = 0.984375;

                                            result[3] = 0.015625;

                                            return 255;

                                        }
                                    } else {
                                        if (features[4] <= -0.064858230) {
                                            result[0] = 0.2;

                                            result[2] = 0.2;

                                            result[3] = 0.6;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 0.052016666) {
                                    result[1] = 0.2;

                                    result[3] = 0.6;

                                    result[4] = 0.2;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= 0.053588752) {
                        if (features[9] <= 0.021881380) {
                            if (features[6] <= -0.053861244) {
                                if (features[4] <= 0.013929263) {
                                    if (features[3] <= 0.179604627) {
                                        if (features[8] <= 0.131082982) {
                                            result[0] = 0.043478260869565216;

                                            result[1] = 0.3695652173913043;

                                            result[2] = 0.5869565217391305;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[6] <= -0.266056284) {
                                        if (features[7] <= -0.038425228) {
                                            return 1;
                                        } else {
                                            result[1] = 0.5;

                                            result[2] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[1] <= -0.024666714) {
                                    if (features[0] <= -0.003680652) {
                                        if (features[6] <= 0.067719489) {
                                            result[0] = 0.056179775280898875;

                                            result[1] = 0.9213483146067416;

                                            result[2] = 0.02247191011235955;

                                            return 255;
                                        } else {
                                            result[0] = 0.8421052631578947;

                                            result[1] = 0.14736842105263157;

                                            result[3] = 0.010526315789473684;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= -0.011500000) {
                                            return 3;
                                        } else {
                                            result[1] = 0.8888888888888888;

                                            result[2] = 0.1111111111111111;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[3] <= -0.009229937) {
                                        if (features[8] <= 0.022191798) {
                                            result[0] = 0.46835443037974683;

                                            result[1] = 0.3670886075949367;

                                            result[2] = 0.05063291139240506;

                                            result[3] = 0.11392405063291139;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[4] <= 0.018058063) {
                                            result[0] = 0.05853658536585366;

                                            result[1] = 0.12195121951219512;

                                            result[2] = 0.3121951219512195;

                                            result[3] = 0.5024390243902439;

                                            result[4] = 0.004878048780487805;

                                            return 255;
                                        } else {
                                            result[0] = 0.48148148148148145;

                                            result[1] = 0.48148148148148145;

                                            result[3] = 0.037037037037037035;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= -0.036942836) {
                                return 1;
                            } else {
                                if (features[8] <= 0.047870466) {
                                    if (features[0] <= -0.005234127) {
                                        if (features[7] <= -0.014272804) {
                                            return 1;
                                        } else {
                                            result[2] = 0.8133333333333334;

                                            result[3] = 0.18666666666666668;

                                            return 255;

                                        }
                                    } else {
                                        if (features[5] <= 0.018459194) {
                                            result[0] = 0.05555555555555555;

                                            result[2] = 0.6111111111111112;

                                            result[3] = 0.2777777777777778;

                                            result[4] = 0.05555555555555555;

                                            return 255;
                                        } else {
                                            result[2] = 0.02857142857142857;

                                            result[3] = 0.9714285714285714;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[7] <= -0.181401260) {
                                        if (features[3] <= 0.298006758) {
                                            return 2;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[6] <= 0.016938105) {
                                            result[1] = 0.004672897196261682;

                                            result[2] = 0.9953271028037384;

                                            return 255;
                                        } else {
                                            result[0] = 0.5;

                                            result[2] = 0.5;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[2] <= 0.070801999) {
                            if (features[5] <= -0.015660886) {
                                if (features[2] <= -0.035653301) {
                                    result[0] = 0.2;

                                    result[4] = 0.8;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[0] <= 0.152459875) {
                                    return 4;
                                } else {
                                    if (features[4] <= -0.013967969) {
                                        return 0;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= -0.036175785) {
                                if (features[3] <= 0.243938394) {
                                    result[2] = 0.5;

                                    result[4] = 0.5;

                                    return 255;
                                } else {
                                    return 4;

                                }
                            } else {
                                return 4;

                            }

                        }

                    }

                }
            } else {
                if (features[4] <= -0.031925540) {
                    if (features[5] <= 0.160932116) {
                        if (features[9] <= 0.043771219) {
                            if (features[2] <= 0.001456812) {
                                if (features[0] <= 0.022948211) {
                                    if (features[9] <= 0.027404813) {
                                        return 3;
                                    } else {
                                        result[3] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[5] <= 0.089338552) {
                                if (features[4] <= -0.054398568) {
                                    return 0;
                                } else {
                                    if (features[6] <= 0.082680400) {
                                        if (features[8] <= 0.060174810) {
                                            return 0;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[3] <= 0.144756734) {
                                            result[0] = 0.6538461538461539;

                                            result[1] = 0.34615384615384615;

                                            return 255;
                                        } else {
                                            return 1;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 0.004906952) {
                                    if (features[4] <= -0.112322893) {
                                        result[0] = 0.6666666666666666;

                                        result[1] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[7] <= -0.007204380) {
                            return 3;
                        } else {
                            return 4;

                        }

                    }
                } else {
                    if (features[0] <= -0.040116772) {
                        if (features[2] <= -0.034945767) {
                            if (features[0] <= -0.079042796) {
                                if (features[1] <= -0.281577826) {
                                    if (features[7] <= 0.133660458) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[7] <= 0.170210853) {
                                    return 1;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[0] <= -0.042887345) {
                                return 0;
                            } else {
                                result[0] = 0.3333333333333333;

                                result[1] = 0.6666666666666666;

                                return 255;

                            }

                        }
                    } else {
                        if (features[6] <= 0.040362056) {
                            if (features[8] <= 0.026691596) {
                                if (features[4] <= -0.007157981) {
                                    if (features[9] <= -0.036174625) {
                                        return 3;
                                    } else {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[7] <= -0.089056205) {
                                    return 4;
                                } else {
                                    result[1] = 0.5;

                                    result[4] = 0.5;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[8] <= 0.053135836) {
                                if (features[8] <= 0.013054772) {
                                    if (features[9] <= -0.013976783) {
                                        if (features[8] <= 0.008010615) {
                                            result[3] = 0.875;

                                            result[4] = 0.125;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[0] <= 0.004410972) {
                                        return 4;
                                    } else {
                                        if (features[2] <= -0.018687711) {
                                            return 1;
                                        } else {
                                            result[3] = 0.25;

                                            result[4] = 0.75;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= 0.124955576) {
                                    return 4;
                                } else {
                                    result[0] = 0.14285714285714285;

                                    result[4] = 0.8571428571428571;

                                    return 255;

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[8] <= 0.108863994) {
                if (features[5] <= 0.046647211) {
                    if (features[3] <= -0.017081893) {
                        if (features[0] <= 0.128670085) {
                            if (features[5] <= -0.068206782) {
                                return 2;
                            } else {
                                result[0] = 0.3333333333333333;

                                result[2] = 0.6666666666666666;

                                return 255;

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[4] <= 0.058396960) {
                            return 2;
                        } else {
                            return 1;

                        }

                    }
                } else {
                    if (features[9] <= 0.114873402) {
                        if (features[7] <= 0.036153641) {
                            return 4;
                        } else {
                            return 0;

                        }
                    } else {
                        return 4;

                    }

                }
            } else {
                if (features[0] <= 0.039216232) {
                    if (features[5] <= 0.075107166) {
                        return 2;
                    } else {
                        return 4;

                    }
                } else {
                    if (features[6] <= 0.094556084) {
                        return 2;
                    } else {
                        return 4;

                    }

                }

            }

        }

    }
}

unsigned char evaluate_forest(float* args) {
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
float total_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char return_res = 0;
unsigned char result_map[5] = { 1,2,3,4, 9 };
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree0(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree1(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree2(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree3(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
unsigned char max_index = 0;
float max_value = 0;
for (unsigned char i = 0; i < 5; ++i) {
if (max_value < total_res[i]) {
max_value = total_res[i];
max_index = i;
}
}
return result_map[max_index];
}
