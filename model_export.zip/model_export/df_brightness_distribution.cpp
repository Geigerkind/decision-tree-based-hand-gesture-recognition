unsigned char tree0(short* features, float* result){
    if (features[1] <= 5) {
        if (features[4] <= 5) {
            if (features[5] <= 5) {
                if (features[1] <= 2) {
                    if (features[1] <= 0) {
                        if (features[3] <= 5) {
                            if (features[2] <= 1) {
                                if (features[9] <= 6) {
                                    if (features[9] <= 1) {
                                        if (features[3] <= 1) {
                                            if (features[0] <= 2) {
                                                result[3] = 0.3333333333333333;

                                                result[4] = 0.6666666666666666;

                                                return 255;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[4] <= 3) {
                                    if (features[4] <= 2) {
                                        return 4;
                                    } else {
                                        if (features[4] <= 2) {
                                            if (features[0] <= 0) {
                                                result[1] = 0.25;

                                                result[4] = 0.75;

                                                return 255;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            result[0] = 0.25;

                                            result[4] = 0.75;

                                            return 255;

                                        }

                                    }
                                } else {
                                    result[0] = 0.25;

                                    result[1] = 0.5;

                                    result[3] = 0.25;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[9] <= 3) {
                                if (features[11] <= 5) {
                                    result[3] = 0.2857142857142857;

                                    result[4] = 0.7142857142857143;

                                    return 255;
                                } else {
                                    result[0] = 0.4;

                                    result[2] = 0.1;

                                    result[3] = 0.3;

                                    result[4] = 0.2;

                                    return 255;

                                }
                            } else {
                                if (features[6] <= 7) {
                                    result[0] = 0.2;

                                    result[2] = 0.2;

                                    result[4] = 0.6;

                                    return 255;
                                } else {
                                    if (features[7] <= 8) {
                                        result[0] = 0.16666666666666666;

                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 4) {
                            result[1] = 0.8571428571428571;

                            result[4] = 0.14285714285714285;

                            return 255;
                        } else {
                            if (features[5] <= 4) {
                                if (features[9] <= 1) {
                                    return 3;
                                } else {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.14285714285714285;

                                    result[2] = 0.14285714285714285;

                                    result[3] = 0.42857142857142855;

                                    result[4] = 0.14285714285714285;

                                    return 255;

                                }
                            } else {
                                return 2;

                            }

                        }

                    }
                } else {
                    if (features[4] <= 2) {
                        if (features[5] <= 1) {
                            if (features[1] <= 4) {
                                if (features[7] <= 6) {
                                    return 2;
                                } else {
                                    result[2] = 0.5;

                                    result[4] = 0.5;

                                    return 255;

                                }
                            } else {
                                result[0] = 0.5;

                                result[1] = 0.25;

                                result[2] = 0.25;

                                return 255;

                            }
                        } else {
                            if (features[2] <= 3) {
                                if (features[8] <= 6) {
                                    if (features[10] <= 6) {
                                        if (features[4] <= 1) {
                                            result[3] = 0.6;

                                            result[4] = 0.4;

                                            return 255;
                                        } else {
                                            result[0] = 0.2857142857142857;

                                            result[3] = 0.14285714285714285;

                                            result[4] = 0.5714285714285714;

                                            return 255;

                                        }
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[1] <= 3) {
                                        result[1] = 0.2;

                                        result[4] = 0.8;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[3] <= 6) {
                                    if (features[5] <= 3) {
                                        if (features[7] <= 4) {
                                            result[2] = 0.25;

                                            result[3] = 0.75;

                                            return 255;
                                        } else {
                                            result[0] = 0.25;

                                            result[3] = 0.5;

                                            result[4] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        if (features[10] <= 5) {
                                            return 0;
                                        } else {
                                            result[0] = 0.4;

                                            result[2] = 0.2;

                                            result[4] = 0.4;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[7] <= 7) {
                                        if (features[0] <= 1) {
                                            result[0] = 0.2;

                                            result[4] = 0.8;

                                            return 255;
                                        } else {
                                            result[0] = 0.75;

                                            result[1] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[10] <= 5) {
                            if (features[7] <= 0) {
                                if (features[3] <= 3) {
                                    if (features[8] <= 2) {
                                        return 0;
                                    } else {
                                        if (features[0] <= 8) {
                                            result[0] = 0.8;

                                            result[4] = 0.2;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[3] <= 4) {
                                        return 3;
                                    } else {
                                        if (features[6] <= 5) {
                                            return 0;
                                        } else {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 6) {
                                    if (features[10] <= 3) {
                                        if (features[5] <= 2) {
                                            result[0] = 0.2;

                                            result[1] = 0.4;

                                            result[3] = 0.4;

                                            return 255;
                                        } else {
                                            if (features[11] <= 3) {
                                                if (features[9] <= 2) {
                                                    return 1;
                                                } else {
                                                    result[0] = 0.16666666666666666;

                                                    result[1] = 0.8333333333333334;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[8] <= 4) {
                                                    result[1] = 0.8;

                                                    result[3] = 0.2;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.25;

                                                    result[2] = 0.5;

                                                    result[4] = 0.25;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[3] <= 3) {
                                            if (features[11] <= 4) {
                                                result[0] = 0.14285714285714285;

                                                result[1] = 0.7142857142857143;

                                                result[2] = 0.14285714285714285;

                                                return 255;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            if (features[3] <= 4) {
                                                if (features[5] <= 4) {
                                                    result[1] = 0.8;

                                                    result[3] = 0.2;

                                                    return 255;
                                                } else {
                                                    result[0] = 0.42857142857142855;

                                                    result[2] = 0.14285714285714285;

                                                    result[3] = 0.42857142857142855;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[6] <= 5) {
                                                    if (features[4] <= 4) {
                                                        result[0] = 0.4;

                                                        result[1] = 0.4;

                                                        result[3] = 0.2;

                                                        return 255;
                                                    } else {
                                                        result[2] = 0.6;

                                                        result[3] = 0.4;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[10] <= 4) {
                                                        result[0] = 0.25;

                                                        result[2] = 0.75;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.16666666666666666;

                                                        result[2] = 0.8333333333333334;

                                                        return 255;

                                                    }

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[4] <= 3) {
                                        result[1] = 0.2;

                                        result[3] = 0.8;

                                        return 255;
                                    } else {
                                        if (features[8] <= 5) {
                                            result[0] = 0.5;

                                            result[1] = 0.25;

                                            result[3] = 0.25;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 4) {
                                if (features[4] <= 3) {
                                    if (features[8] <= 2) {
                                        result[1] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        if (features[10] <= 7) {
                                            return 3;
                                        } else {
                                            result[0] = 0.125;

                                            result[1] = 0.75;

                                            result[3] = 0.125;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[7] <= 2) {
                                        result[1] = 0.2;

                                        result[3] = 0.6;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        if (features[0] <= 5) {
                                            result[0] = 0.16666666666666666;

                                            result[3] = 0.8333333333333334;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 6) {
                                    if (features[6] <= 5) {
                                        if (features[1] <= 5) {
                                            return 0;
                                        } else {
                                            result[1] = 0.25;

                                            result[3] = 0.75;

                                            return 255;

                                        }
                                    } else {
                                        result[1] = 0.8888888888888888;

                                        result[3] = 0.1111111111111111;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 2) {
                                        if (features[9] <= 4) {
                                            return 4;
                                        } else {
                                            result[0] = 0.25;

                                            result[4] = 0.75;

                                            return 255;

                                        }
                                    } else {
                                        if (features[10] <= 7) {
                                            if (features[11] <= 5) {
                                                result[0] = 0.4;

                                                result[2] = 0.2;

                                                result[3] = 0.4;

                                                return 255;
                                            } else {
                                                if (features[11] <= 6) {
                                                    result[0] = 0.6666666666666666;

                                                    result[1] = 0.16666666666666666;

                                                    result[4] = 0.16666666666666666;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }
                                        } else {
                                            result[1] = 0.16666666666666666;

                                            result[2] = 0.16666666666666666;

                                            result[4] = 0.6666666666666666;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[4] <= 5) {
                    if (features[0] <= 4) {
                        if (features[11] <= 2) {
                            if (features[8] <= 2) {
                                result[0] = 0.14285714285714285;

                                result[4] = 0.8571428571428571;

                                return 255;
                            } else {
                                if (features[0] <= 2) {
                                    if (features[7] <= 5) {
                                        result[3] = 0.8333333333333334;

                                        result[4] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[2] = 0.2;

                                        result[3] = 0.8;

                                        return 255;

                                    }
                                } else {
                                    result[0] = 0.16666666666666666;

                                    result[4] = 0.8333333333333334;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[3] <= 4) {
                                if (features[9] <= 4) {
                                    result[0] = 0.4;

                                    result[4] = 0.6;

                                    return 255;
                                } else {
                                    if (features[4] <= 3) {
                                        result[2] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.2857142857142857;

                                        result[1] = 0.14285714285714285;

                                        result[2] = 0.2857142857142857;

                                        result[3] = 0.2857142857142857;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 2) {
                                    if (features[0] <= 1) {
                                        result[2] = 0.75;

                                        result[3] = 0.25;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[7] <= 5) {
                                        result[0] = 0.25;

                                        result[1] = 0.25;

                                        result[2] = 0.25;

                                        result[3] = 0.25;

                                        return 255;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[2] = 0.8571428571428571;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 7) {
                            if (features[7] <= 5) {
                                if (features[0] <= 6) {
                                    if (features[2] <= 5) {
                                        if (features[3] <= 6) {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;
                                        } else {
                                            result[0] = 0.25;

                                            result[1] = 0.5;

                                            result[2] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        if (features[2] <= 6) {
                                            if (features[3] <= 4) {
                                                result[0] = 0.75;

                                                result[1] = 0.25;

                                                return 255;
                                            } else {
                                                result[0] = 0.75;

                                                result[1] = 0.25;

                                                return 255;

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[1] <= 4) {
                                        if (features[1] <= 4) {
                                            if (features[6] <= 6) {
                                                if (features[9] <= 1) {
                                                    return 0;
                                                } else {
                                                    if (features[6] <= 1) {
                                                        result[0] = 0.5;

                                                        result[1] = 0.16666666666666666;

                                                        result[3] = 0.3333333333333333;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.5;

                                                        result[2] = 0.25;

                                                        result[3] = 0.25;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                result[1] = 0.5;

                                                result[4] = 0.5;

                                                return 255;

                                            }
                                        } else {
                                            if (features[0] <= 7) {
                                                if (features[0] <= 7) {
                                                    result[3] = 0.75;

                                                    result[4] = 0.25;

                                                    return 255;
                                                } else {
                                                    if (features[6] <= 3) {
                                                        result[2] = 0.16666666666666666;

                                                        result[3] = 0.8333333333333334;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.16666666666666666;

                                                        result[1] = 0.5;

                                                        result[2] = 0.3333333333333333;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                result[1] = 0.75;

                                                result[3] = 0.25;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[2] <= 4) {
                                            return 1;
                                        } else {
                                            if (features[6] <= 4) {
                                                return 1;
                                            } else {
                                                result[0] = 0.5;

                                                result[1] = 0.5;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= 4) {
                                    result[0] = 0.125;

                                    result[1] = 0.625;

                                    result[2] = 0.25;

                                    return 255;
                                } else {
                                    if (features[4] <= 4) {
                                        return 1;
                                    } else {
                                        result[1] = 0.25;

                                        result[3] = 0.5;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[10] <= 6) {
                                if (features[7] <= 8) {
                                    result[0] = 0.75;

                                    result[2] = 0.25;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[10] <= 7) {
                                    result[0] = 0.42857142857142855;

                                    result[1] = 0.2857142857142857;

                                    result[2] = 0.14285714285714285;

                                    result[3] = 0.14285714285714285;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 4) {
                        if (features[9] <= 3) {
                            if (features[7] <= 4) {
                                result[0] = 0.8;

                                result[3] = 0.2;

                                return 255;
                            } else {
                                result[0] = 0.8;

                                result[3] = 0.2;

                                return 255;

                            }
                        } else {
                            if (features[2] <= 3) {
                                return 0;
                            } else {
                                if (features[11] <= 5) {
                                    result[0] = 0.7142857142857143;

                                    result[2] = 0.2857142857142857;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 4) {
                            return 3;
                        } else {
                            result[0] = 0.2857142857142857;

                            result[2] = 0.5714285714285714;

                            result[3] = 0.14285714285714285;

                            return 255;

                        }

                    }

                }

            }
        } else {
            if (features[1] <= 5) {
                if (features[4] <= 7) {
                    if (features[4] <= 7) {
                        if (features[3] <= 5) {
                            if (features[1] <= 0) {
                                if (features[11] <= 3) {
                                    if (features[10] <= 1) {
                                        result[2] = 0.6666666666666666;

                                        result[3] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    result[2] = 0.5;

                                    result[4] = 0.5;

                                    return 255;

                                }
                            } else {
                                if (features[0] <= 8) {
                                    if (features[5] <= 5) {
                                        if (features[7] <= 4) {
                                            result[1] = 0.75;

                                            result[4] = 0.25;

                                            return 255;
                                        } else {
                                            result[1] = 0.5;

                                            result[2] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        if (features[5] <= 7) {
                                            if (features[5] <= 7) {
                                                if (features[8] <= 5) {
                                                    return 1;
                                                } else {
                                                    if (features[1] <= 3) {
                                                        result[1] = 0.2;

                                                        result[2] = 0.4;

                                                        result[4] = 0.4;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.25;

                                                        result[2] = 0.75;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                result[0] = 0.2;

                                                result[2] = 0.8;

                                                return 255;

                                            }
                                        } else {
                                            if (features[1] <= 2) {
                                                return 2;
                                            } else {
                                                result[0] = 0.4;

                                                result[2] = 0.6;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[3] <= 4) {
                                        if (features[11] <= 2) {
                                            result[1] = 0.5;

                                            result[2] = 0.25;

                                            result[3] = 0.25;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 3) {
                                if (features[3] <= 6) {
                                    if (features[7] <= 3) {
                                        result[2] = 0.4;

                                        result[3] = 0.6;

                                        return 255;
                                    } else {
                                        result[1] = 0.8333333333333334;

                                        result[2] = 0.16666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 1) {
                                        result[2] = 0.6;

                                        result[3] = 0.4;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[9] <= 3) {
                                    if (features[9] <= 0) {
                                        if (features[11] <= 5) {
                                            if (features[8] <= 5) {
                                                result[2] = 0.8333333333333334;

                                                result[3] = 0.16666666666666666;

                                                return 255;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            result[0] = 0.14285714285714285;

                                            result[2] = 0.7142857142857143;

                                            result[3] = 0.14285714285714285;

                                            return 255;

                                        }
                                    } else {
                                        if (features[9] <= 2) {
                                            if (features[10] <= 1) {
                                                if (features[3] <= 6) {
                                                    result[0] = 0.4;

                                                    result[2] = 0.6;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                if (features[10] <= 3) {
                                                    if (features[5] <= 6) {
                                                        return 2;
                                                    } else {
                                                        result[0] = 0.14285714285714285;

                                                        result[2] = 0.7142857142857143;

                                                        result[3] = 0.14285714285714285;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 2;

                                                }

                                            }
                                        } else {
                                            if (features[8] <= 5) {
                                                if (features[0] <= 6) {
                                                    if (features[8] <= 4) {
                                                        if (features[1] <= 2) {
                                                            return 2;
                                                        } else {
                                                            result[1] = 0.25;

                                                            result[2] = 0.75;

                                                            return 255;

                                                        }
                                                    } else {
                                                        return 2;

                                                    }
                                                } else {
                                                    result[1] = 0.25;

                                                    result[2] = 0.75;

                                                    return 255;

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[2] <= 8) {
                                        if (features[5] <= 5) {
                                            if (features[3] <= 6) {
                                                if (features[0] <= 5) {
                                                    return 2;
                                                } else {
                                                    result[1] = 0.25;

                                                    result[2] = 0.75;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[1] <= 0) {
                                                    result[0] = 0.25;

                                                    result[4] = 0.75;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.42857142857142855;

                                                    result[2] = 0.2857142857142857;

                                                    result[4] = 0.2857142857142857;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[1] <= 1) {
                                                if (features[6] <= 4) {
                                                    result[0] = 0.3333333333333333;

                                                    result[2] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                if (features[10] <= 6) {
                                                    if (features[5] <= 7) {
                                                        return 2;
                                                    } else {
                                                        result[1] = 0.16666666666666666;

                                                        result[2] = 0.8333333333333334;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[1] = 0.5;

                                                    result[2] = 0.25;

                                                    result[3] = 0.25;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        result[1] = 0.75;

                                        result[3] = 0.25;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 3) {
                            if (features[8] <= 3) {
                                if (features[0] <= 8) {
                                    if (features[11] <= 3) {
                                        result[0] = 0.2;

                                        result[3] = 0.8;

                                        return 255;
                                    } else {
                                        result[2] = 0.25;

                                        result[3] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    result[1] = 0.5;

                                    result[2] = 0.5;

                                    return 255;

                                }
                            } else {
                                if (features[3] <= 3) {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.5714285714285714;

                                    result[2] = 0.2857142857142857;

                                    return 255;
                                } else {
                                    if (features[2] <= 6) {
                                        if (features[0] <= 0) {
                                            result[0] = 0.14285714285714285;

                                            result[2] = 0.7142857142857143;

                                            result[3] = 0.14285714285714285;

                                            return 255;
                                        } else {
                                            if (features[8] <= 6) {
                                                if (features[6] <= 6) {
                                                    if (features[11] <= 0) {
                                                        result[2] = 0.75;

                                                        result[3] = 0.25;

                                                        return 255;
                                                    } else {
                                                        return 2;

                                                    }
                                                } else {
                                                    result[1] = 0.25;

                                                    result[2] = 0.5;

                                                    result[3] = 0.25;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[8] <= 8) {
                                                    return 2;
                                                } else {
                                                    result[2] = 0.8333333333333334;

                                                    result[3] = 0.16666666666666666;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[8] <= 6) {
                                            result[0] = 0.2;

                                            result[2] = 0.4;

                                            result[3] = 0.4;

                                            return 255;
                                        } else {
                                            result[0] = 0.14285714285714285;

                                            result[2] = 0.8571428571428571;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 3) {
                                if (features[10] <= 3) {
                                    if (features[0] <= 6) {
                                        result[2] = 0.8333333333333334;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[2] = 0.25;

                                        result[3] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[11] <= 7) {
                                        if (features[0] <= 5) {
                                            if (features[0] <= 0) {
                                                result[0] = 0.25;

                                                result[1] = 0.5;

                                                result[2] = 0.25;

                                                return 255;
                                            } else {
                                                if (features[6] <= 6) {
                                                    result[0] = 0.8571428571428571;

                                                    result[2] = 0.14285714285714285;

                                                    return 255;
                                                } else {
                                                    if (features[2] <= 6) {
                                                        result[0] = 0.5;

                                                        result[2] = 0.5;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.3333333333333333;

                                                        result[2] = 0.6666666666666666;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[10] <= 6) {
                                                if (features[0] <= 7) {
                                                    return 0;
                                                } else {
                                                    result[0] = 0.4;

                                                    result[2] = 0.6;

                                                    return 255;

                                                }
                                            } else {
                                                return 0;

                                            }

                                        }
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[0] <= 5) {
                                    if (features[0] <= 4) {
                                        if (features[0] <= 1) {
                                            if (features[6] <= 7) {
                                                return 2;
                                            } else {
                                                result[0] = 0.25;

                                                result[2] = 0.5;

                                                result[3] = 0.25;

                                                return 255;

                                            }
                                        } else {
                                            if (features[8] <= 3) {
                                                result[0] = 0.5;

                                                result[2] = 0.25;

                                                result[3] = 0.25;

                                                return 255;
                                            } else {
                                                result[0] = 0.8571428571428571;

                                                result[2] = 0.14285714285714285;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        result[0] = 0.125;

                                        result[2] = 0.875;

                                        return 255;

                                    }
                                } else {
                                    if (features[10] <= 4) {
                                        if (features[9] <= 5) {
                                            if (features[0] <= 8) {
                                                result[0] = 0.25;

                                                result[2] = 0.75;

                                                return 255;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            result[0] = 0.2;

                                            result[2] = 0.4;

                                            result[4] = 0.4;

                                            return 255;

                                        }
                                    } else {
                                        if (features[10] <= 6) {
                                            if (features[3] <= 5) {
                                                return 2;
                                            } else {
                                                result[1] = 0.16666666666666666;

                                                result[2] = 0.8333333333333334;

                                                return 255;

                                            }
                                        } else {
                                            result[1] = 0.4;

                                            result[2] = 0.4;

                                            result[3] = 0.2;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 2) {
                        if (features[1] <= 0) {
                            if (features[0] <= 2) {
                                result[0] = 0.5;

                                result[4] = 0.5;

                                return 255;
                            } else {
                                if (features[0] <= 5) {
                                    result[0] = 0.6;

                                    result[3] = 0.4;

                                    return 255;
                                } else {
                                    if (features[11] <= 2) {
                                        return 0;
                                    } else {
                                        if (features[2] <= 5) {
                                            result[0] = 0.6;

                                            result[2] = 0.4;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 3) {
                                if (features[8] <= 5) {
                                    result[0] = 0.25;

                                    result[3] = 0.75;

                                    return 255;
                                } else {
                                    result[2] = 0.8571428571428571;

                                    result[3] = 0.14285714285714285;

                                    return 255;

                                }
                            } else {
                                if (features[3] <= 6) {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.14285714285714285;

                                    result[2] = 0.7142857142857143;

                                    return 255;
                                } else {
                                    if (features[2] <= 8) {
                                        return 2;
                                    } else {
                                        result[1] = 0.2;

                                        result[2] = 0.8;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 3) {
                            if (features[0] <= 3) {
                                if (features[3] <= 5) {
                                    return 0;
                                } else {
                                    if (features[11] <= 4) {
                                        return 0;
                                    } else {
                                        result[0] = 0.8333333333333334;

                                        result[3] = 0.16666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[7] <= 1) {
                                return 0;
                            } else {
                                if (features[0] <= 4) {
                                    if (features[9] <= 6) {
                                        if (features[2] <= 6) {
                                            return 2;
                                        } else {
                                            result[2] = 0.75;

                                            result[3] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        result[0] = 0.2857142857142857;

                                        result[2] = 0.7142857142857143;

                                        return 255;

                                    }
                                } else {
                                    if (features[9] <= 2) {
                                        if (features[6] <= 2) {
                                            return 2;
                                        } else {
                                            if (features[7] <= 5) {
                                                result[0] = 0.6;

                                                result[2] = 0.4;

                                                return 255;
                                            } else {
                                                result[0] = 0.2;

                                                result[2] = 0.8;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[10] <= 6) {
                                            if (features[3] <= 7) {
                                                result[0] = 0.6666666666666666;

                                                result[1] = 0.16666666666666666;

                                                result[2] = 0.16666666666666666;

                                                return 255;
                                            } else {
                                                result[0] = 0.4;

                                                result[2] = 0.6;

                                                return 255;

                                            }
                                        } else {
                                            if (features[3] <= 6) {
                                                result[0] = 0.75;

                                                result[2] = 0.25;

                                                return 255;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[3] <= 4) {
                    if (features[3] <= 3) {
                        result[1] = 0.6;

                        result[4] = 0.4;

                        return 255;
                    } else {
                        if (features[5] <= 8) {
                            if (features[2] <= 5) {
                                if (features[10] <= 5) {
                                    result[1] = 0.8;

                                    result[4] = 0.2;

                                    return 255;
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[5] <= 6) {
                                    result[0] = 0.75;

                                    result[1] = 0.25;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            return 1;

                        }

                    }
                } else {
                    if (features[10] <= 7) {
                        if (features[0] <= 4) {
                            if (features[7] <= 4) {
                                result[0] = 0.2;

                                result[1] = 0.2;

                                result[2] = 0.2;

                                result[3] = 0.4;

                                return 255;
                            } else {
                                if (features[9] <= 5) {
                                    return 2;
                                } else {
                                    result[2] = 0.75;

                                    result[3] = 0.25;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[7] <= 2) {
                                if (features[0] <= 7) {
                                    return 0;
                                } else {
                                    result[0] = 0.5;

                                    result[1] = 0.25;

                                    result[2] = 0.25;

                                    return 255;

                                }
                            } else {
                                if (features[7] <= 4) {
                                    if (features[9] <= 3) {
                                        if (features[10] <= 4) {
                                            result[1] = 0.5;

                                            result[2] = 0.5;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[10] <= 4) {
                                            result[1] = 0.4;

                                            result[2] = 0.4;

                                            result[4] = 0.2;

                                            return 255;
                                        } else {
                                            if (features[8] <= 3) {
                                                return 0;
                                            } else {
                                                result[0] = 0.6;

                                                result[1] = 0.4;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[11] <= 5) {
                                        if (features[2] <= 6) {
                                            if (features[5] <= 6) {
                                                if (features[6] <= 6) {
                                                    result[1] = 0.42857142857142855;

                                                    result[2] = 0.5714285714285714;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[3] <= 7) {
                                                    if (features[0] <= 5) {
                                                        result[1] = 0.2857142857142857;

                                                        result[2] = 0.7142857142857143;

                                                        return 255;
                                                    } else {
                                                        if (features[6] <= 3) {
                                                            result[1] = 0.8;

                                                            result[2] = 0.2;

                                                            return 255;
                                                        } else {
                                                            result[1] = 0.5;

                                                            result[2] = 0.5;

                                                            return 255;

                                                        }

                                                    }
                                                } else {
                                                    result[1] = 0.2;

                                                    result[2] = 0.8;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        result[1] = 0.25;

                                        result[2] = 0.75;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 8) {
                            return 1;
                        } else {
                            if (features[0] <= 6) {
                                return 1;
                            } else {
                                result[1] = 0.25;

                                result[2] = 0.75;

                                return 255;

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[4] <= 5) {
            if (features[4] <= 2) {
                if (features[4] <= 1) {
                    if (features[9] <= 5) {
                        if (features[1] <= 7) {
                            if (features[2] <= 3) {
                                if (features[5] <= 7) {
                                    result[1] = 0.2;

                                    result[2] = 0.4;

                                    result[3] = 0.4;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[5] <= 5) {
                                    if (features[4] <= 1) {
                                        if (features[6] <= 3) {
                                            result[2] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            result[3] = 0.75;

                                            result[4] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        result[3] = 0.8;

                                        result[4] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[4] <= 0) {
                                if (features[11] <= 3) {
                                    return 3;
                                } else {
                                    if (features[1] <= 7) {
                                        result[0] = 0.2;

                                        result[1] = 0.2;

                                        result[2] = 0.4;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        if (features[6] <= 2) {
                                            result[0] = 0.5;

                                            result[1] = 0.16666666666666666;

                                            result[2] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            if (features[10] <= 7) {
                                                if (features[5] <= 4) {
                                                    result[0] = 0.75;

                                                    result[2] = 0.25;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 4) {
                                    if (features[11] <= 7) {
                                        result[1] = 0.16666666666666666;

                                        result[2] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[2] = 0.75;

                                        result[3] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 8) {
                                        result[3] = 0.7142857142857143;

                                        result[4] = 0.2857142857142857;

                                        return 255;
                                    } else {
                                        result[2] = 0.5;

                                        result[3] = 0.25;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 8) {
                            if (features[3] <= 6) {
                                if (features[6] <= 0) {
                                    if (features[2] <= 0) {
                                        if (features[8] <= 1) {
                                            return 2;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[8] <= 5) {
                                            if (features[2] <= 6) {
                                                if (features[11] <= 2) {
                                                    result[2] = 0.25;

                                                    result[3] = 0.75;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                result[2] = 0.25;

                                                result[3] = 0.75;

                                                return 255;

                                            }
                                        } else {
                                            result[2] = 0.14285714285714285;

                                            result[3] = 0.5714285714285714;

                                            result[4] = 0.2857142857142857;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[11] <= 7) {
                                        if (features[0] <= 3) {
                                            result[1] = 0.25;

                                            result[2] = 0.25;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[7] <= 1) {
                                                if (features[5] <= 4) {
                                                    return 3;
                                                } else {
                                                    result[3] = 0.5;

                                                    result[4] = 0.5;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= 1) {
                                                    return 3;
                                                } else {
                                                    if (features[3] <= 3) {
                                                        if (features[5] <= 3) {
                                                            if (features[4] <= 0) {
                                                                result[3] = 0.9629629629629629;

                                                                result[4] = 0.037037037037037035;

                                                                return 255;
                                                            } else {
                                                                result[3] = 0.8571428571428571;

                                                                result[4] = 0.14285714285714285;

                                                                return 255;

                                                            }
                                                        } else {
                                                            if (features[3] <= 2) {
                                                                return 3;
                                                            } else {
                                                                result[3] = 0.6666666666666666;

                                                                result[4] = 0.3333333333333333;

                                                                return 255;

                                                            }

                                                        }
                                                    } else {
                                                        if (features[8] <= 5) {
                                                            if (features[3] <= 5) {
                                                                return 3;
                                                            } else {
                                                                result[1] = 0.1111111111111111;

                                                                result[3] = 0.8888888888888888;

                                                                return 255;

                                                            }
                                                        } else {
                                                            result[2] = 0.25;

                                                            result[3] = 0.75;

                                                            return 255;

                                                        }

                                                    }

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 0) {
                                            if (features[1] <= 6) {
                                                if (features[10] <= 6) {
                                                    result[3] = 0.6;

                                                    result[4] = 0.4;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                if (features[0] <= 6) {
                                                    result[3] = 0.75;

                                                    result[4] = 0.25;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= 7) {
                                    if (features[6] <= 3) {
                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[0] = 0.09090909090909091;

                                        result[3] = 0.5454545454545454;

                                        result[4] = 0.36363636363636365;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 4) {
                                        return 3;
                                    } else {
                                        result[2] = 0.14285714285714285;

                                        result[3] = 0.8571428571428571;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 5) {
                                if (features[7] <= 1) {
                                    if (features[6] <= 2) {
                                        return 4;
                                    } else {
                                        if (features[0] <= 8) {
                                            result[2] = 0.5;

                                            result[3] = 0.25;

                                            result[4] = 0.25;

                                            return 255;
                                        } else {
                                            result[1] = 0.25;

                                            result[4] = 0.75;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[7] <= 1) {
                                    result[1] = 0.2;

                                    result[3] = 0.8;

                                    return 255;
                                } else {
                                    if (features[6] <= 6) {
                                        return 0;
                                    } else {
                                        result[0] = 0.8;

                                        result[1] = 0.2;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 6) {
                        if (features[6] <= 4) {
                            if (features[5] <= 3) {
                                if (features[6] <= 3) {
                                    return 3;
                                } else {
                                    if (features[5] <= 2) {
                                        return 3;
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.5;

                                        result[3] = 0.25;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 7) {
                                    if (features[8] <= 3) {
                                        return 1;
                                    } else {
                                        result[1] = 0.75;

                                        result[3] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    result[0] = 0.6;

                                    result[3] = 0.4;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[7] <= 5) {
                                if (features[3] <= 6) {
                                    if (features[9] <= 6) {
                                        result[0] = 0.4;

                                        result[1] = 0.6;

                                        return 255;
                                    } else {
                                        result[1] = 0.42857142857142855;

                                        result[3] = 0.5714285714285714;

                                        return 255;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[7] <= 7) {
                                    if (features[8] <= 3) {
                                        return 1;
                                    } else {
                                        result[1] = 0.75;

                                        result[3] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 6) {
                                        result[0] = 0.25;

                                        result[1] = 0.75;

                                        return 255;
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 7) {
                            if (features[2] <= 7) {
                                if (features[3] <= 3) {
                                    if (features[2] <= 4) {
                                        return 3;
                                    } else {
                                        result[2] = 0.25;

                                        result[3] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    if (features[6] <= 5) {
                                        result[3] = 0.8;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        result[3] = 0.75;

                                        result[4] = 0.25;

                                        return 255;

                                    }

                                }
                            } else {
                                result[1] = 0.14285714285714285;

                                result[2] = 0.2857142857142857;

                                result[3] = 0.14285714285714285;

                                result[4] = 0.42857142857142855;

                                return 255;

                            }
                        } else {
                            if (features[5] <= 6) {
                                if (features[3] <= 4) {
                                    result[1] = 0.25;

                                    result[4] = 0.75;

                                    return 255;
                                } else {
                                    if (features[5] <= 5) {
                                        return 4;
                                    } else {
                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;

                                    }

                                }
                            } else {
                                result[1] = 0.125;

                                result[3] = 0.5;

                                result[4] = 0.375;

                                return 255;

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 6) {
                    if (features[4] <= 4) {
                        if (features[4] <= 3) {
                            if (features[1] <= 7) {
                                if (features[11] <= 2) {
                                    result[1] = 0.3333333333333333;

                                    result[3] = 0.6666666666666666;

                                    return 255;
                                } else {
                                    if (features[3] <= 4) {
                                        if (features[5] <= 5) {
                                            if (features[8] <= 3) {
                                                result[3] = 0.2857142857142857;

                                                result[4] = 0.7142857142857143;

                                                return 255;
                                            } else {
                                                if (features[5] <= 2) {
                                                    return 3;
                                                } else {
                                                    if (features[11] <= 6) {
                                                        result[1] = 0.25;

                                                        result[3] = 0.25;

                                                        result[4] = 0.5;

                                                        return 255;
                                                    } else {
                                                        if (features[8] <= 6) {
                                                            result[3] = 0.6666666666666666;

                                                            result[4] = 0.3333333333333333;

                                                            return 255;
                                                        } else {
                                                            result[3] = 0.5;

                                                            result[4] = 0.5;

                                                            return 255;

                                                        }

                                                    }

                                                }

                                            }
                                        } else {
                                            result[2] = 0.2;

                                            result[4] = 0.8;

                                            return 255;

                                        }
                                    } else {
                                        if (features[3] <= 4) {
                                            result[3] = 0.7142857142857143;

                                            result[4] = 0.2857142857142857;

                                            return 255;
                                        } else {
                                            if (features[6] <= 3) {
                                                if (features[10] <= 6) {
                                                    return 4;
                                                } else {
                                                    result[3] = 0.25;

                                                    result[4] = 0.75;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[8] <= 3) {
                                                    if (features[8] <= 1) {
                                                        return 4;
                                                    } else {
                                                        if (features[6] <= 4) {
                                                            result[3] = 0.16666666666666666;

                                                            result[4] = 0.8333333333333334;

                                                            return 255;
                                                        } else {
                                                            result[3] = 0.5;

                                                            result[4] = 0.5;

                                                            return 255;

                                                        }

                                                    }
                                                } else {
                                                    result[3] = 0.4;

                                                    result[4] = 0.6;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[10] <= 6) {
                                    if (features[7] <= 2) {
                                        if (features[6] <= 3) {
                                            result[1] = 0.5;

                                            result[3] = 0.25;

                                            result[4] = 0.25;

                                            return 255;
                                        } else {
                                            result[0] = 0.7142857142857143;

                                            result[1] = 0.14285714285714285;

                                            result[2] = 0.14285714285714285;

                                            return 255;

                                        }
                                    } else {
                                        if (features[7] <= 5) {
                                            if (features[5] <= 4) {
                                                result[0] = 0.25;

                                                result[1] = 0.75;

                                                return 255;
                                            } else {
                                                result[0] = 0.16666666666666666;

                                                result[1] = 0.6666666666666666;

                                                result[3] = 0.16666666666666666;

                                                return 255;

                                            }
                                        } else {
                                            result[1] = 0.8571428571428571;

                                            result[2] = 0.14285714285714285;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 6) {
                                        return 0;
                                    } else {
                                        if (features[10] <= 7) {
                                            return 3;
                                        } else {
                                            if (features[1] <= 8) {
                                                result[1] = 0.3333333333333333;

                                                result[2] = 0.16666666666666666;

                                                result[3] = 0.3333333333333333;

                                                result[4] = 0.16666666666666666;

                                                return 255;
                                            } else {
                                                result[0] = 0.75;

                                                result[1] = 0.25;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= 4) {
                                if (features[2] <= 7) {
                                    if (features[8] <= 2) {
                                        result[0] = 0.2;

                                        result[3] = 0.4;

                                        result[4] = 0.4;

                                        return 255;
                                    } else {
                                        if (features[1] <= 7) {
                                            result[0] = 0.4;

                                            result[1] = 0.2;

                                            result[3] = 0.4;

                                            return 255;
                                        } else {
                                            result[0] = 0.2;

                                            result[3] = 0.8;

                                            return 255;

                                        }

                                    }
                                } else {
                                    result[2] = 0.5;

                                    result[3] = 0.16666666666666666;

                                    result[4] = 0.3333333333333333;

                                    return 255;

                                }
                            } else {
                                if (features[9] <= 8) {
                                    if (features[6] <= 4) {
                                        if (features[1] <= 7) {
                                            if (features[1] <= 6) {
                                                if (features[11] <= 4) {
                                                    if (features[6] <= 3) {
                                                        return 3;
                                                    } else {
                                                        result[1] = 0.42857142857142855;

                                                        result[3] = 0.2857142857142857;

                                                        result[4] = 0.2857142857142857;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            result[2] = 0.16666666666666666;

                                            result[3] = 0.5;

                                            result[4] = 0.3333333333333333;

                                            return 255;

                                        }
                                    } else {
                                        if (features[2] <= 5) {
                                            result[0] = 0.25;

                                            result[3] = 0.75;

                                            return 255;
                                        } else {
                                            result[0] = 0.4;

                                            result[1] = 0.2;

                                            result[3] = 0.4;

                                            return 255;

                                        }

                                    }
                                } else {
                                    result[1] = 0.25;

                                    result[3] = 0.25;

                                    result[4] = 0.5;

                                    return 255;

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 6) {
                            if (features[5] <= 6) {
                                if (features[2] <= 5) {
                                    if (features[2] <= 4) {
                                        return 1;
                                    } else {
                                        if (features[6] <= 4) {
                                            result[1] = 0.25;

                                            result[3] = 0.75;

                                            return 255;
                                        } else {
                                            result[0] = 0.3333333333333333;

                                            result[3] = 0.6666666666666666;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[11] <= 6) {
                                        if (features[7] <= 4) {
                                            return 1;
                                        } else {
                                            if (features[5] <= 3) {
                                                return 1;
                                            } else {
                                                if (features[8] <= 3) {
                                                    result[1] = 0.8333333333333334;

                                                    result[3] = 0.16666666666666666;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.75;

                                                    result[3] = 0.25;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[5] <= 4) {
                                            result[1] = 0.75;

                                            result[3] = 0.25;

                                            return 255;
                                        } else {
                                            result[1] = 0.75;

                                            result[3] = 0.25;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= 6) {
                                    if (features[2] <= 6) {
                                        result[0] = 0.6;

                                        result[1] = 0.2;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        if (features[6] <= 4) {
                                            result[0] = 0.6;

                                            result[1] = 0.4;

                                            return 255;
                                        } else {
                                            if (features[5] <= 8) {
                                                return 1;
                                            } else {
                                                result[1] = 0.8571428571428571;

                                                result[3] = 0.14285714285714285;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[9] <= 4) {
                                        return 0;
                                    } else {
                                        if (features[8] <= 3) {
                                            return 3;
                                        } else {
                                            result[0] = 0.4;

                                            result[3] = 0.6;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 8) {
                                if (features[1] <= 8) {
                                    if (features[2] <= 5) {
                                        if (features[11] <= 7) {
                                            result[0] = 0.125;

                                            result[3] = 0.625;

                                            result[4] = 0.25;

                                            return 255;
                                        } else {
                                            result[0] = 0.75;

                                            result[3] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        result[2] = 0.4;

                                        result[4] = 0.6;

                                        return 255;

                                    }
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[2] <= 3) {
                                    result[0] = 0.5;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    if (features[7] <= 4) {
                                        return 3;
                                    } else {
                                        if (features[9] <= 6) {
                                            result[0] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[6] <= 7) {
                        if (features[7] <= 3) {
                            if (features[1] <= 7) {
                                if (features[3] <= 1) {
                                    result[2] = 0.16666666666666666;

                                    result[3] = 0.8333333333333334;

                                    return 255;
                                } else {
                                    if (features[5] <= 4) {
                                        if (features[3] <= 5) {
                                            result[1] = 0.16666666666666666;

                                            result[3] = 0.5;

                                            result[4] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            if (features[9] <= 5) {
                                                result[0] = 0.25;

                                                result[3] = 0.25;

                                                result[4] = 0.5;

                                                return 255;
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[6] <= 6) {
                                            return 0;
                                        } else {
                                            result[1] = 0.8;

                                            result[3] = 0.2;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[4] <= 4) {
                                    if (features[10] <= 4) {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;
                                    } else {
                                        if (features[5] <= 5) {
                                            return 0;
                                        } else {
                                            if (features[7] <= 1) {
                                                return 0;
                                            } else {
                                                result[0] = 0.8;

                                                result[1] = 0.2;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.42857142857142855;

                                    result[3] = 0.14285714285714285;

                                    result[4] = 0.2857142857142857;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[1] <= 7) {
                                if (features[4] <= 3) {
                                    if (features[10] <= 7) {
                                        result[2] = 0.25;

                                        result[3] = 0.25;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 1) {
                                        result[0] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        if (features[7] <= 7) {
                                            if (features[6] <= 6) {
                                                result[0] = 0.8333333333333334;

                                                result[1] = 0.16666666666666666;

                                                return 255;
                                            } else {
                                                if (features[7] <= 5) {
                                                    result[0] = 0.4;

                                                    result[1] = 0.2;

                                                    result[3] = 0.4;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.5;

                                                    result[3] = 0.5;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[9] <= 3) {
                                                return 0;
                                            } else {
                                                result[0] = 0.75;

                                                result[1] = 0.25;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 5) {
                                    if (features[9] <= 6) {
                                        result[0] = 0.16666666666666666;

                                        result[3] = 0.8333333333333334;

                                        return 255;
                                    } else {
                                        result[1] = 0.2;

                                        result[3] = 0.6;

                                        result[4] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    if (features[11] <= 6) {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;
                                    } else {
                                        if (features[4] <= 4) {
                                            return 1;
                                        } else {
                                            result[1] = 0.5714285714285714;

                                            result[3] = 0.42857142857142855;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[7] <= 7) {
                            if (features[1] <= 7) {
                                if (features[5] <= 4) {
                                    return 1;
                                } else {
                                    if (features[9] <= 2) {
                                        return 1;
                                    } else {
                                        if (features[8] <= 3) {
                                            result[1] = 0.8571428571428571;

                                            result[4] = 0.14285714285714285;

                                            return 255;
                                        } else {
                                            result[0] = 0.2;

                                            result[1] = 0.4;

                                            result[4] = 0.4;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 6) {
                                    if (features[7] <= 4) {
                                        if (features[7] <= 3) {
                                            result[2] = 0.25;

                                            result[3] = 0.5;

                                            result[4] = 0.25;

                                            return 255;
                                        } else {
                                            result[1] = 0.6;

                                            result[3] = 0.2;

                                            result[4] = 0.2;

                                            return 255;

                                        }
                                    } else {
                                        result[1] = 0.8571428571428571;

                                        result[3] = 0.14285714285714285;

                                        return 255;

                                    }
                                } else {
                                    result[0] = 0.14285714285714285;

                                    result[4] = 0.8571428571428571;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[3] <= 5) {
                                result[0] = 0.16666666666666666;

                                result[1] = 0.5;

                                result[3] = 0.16666666666666666;

                                result[4] = 0.16666666666666666;

                                return 255;
                            } else {
                                if (features[9] <= 5) {
                                    result[0] = 0.75;

                                    result[1] = 0.25;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[4] <= 6) {
                if (features[1] <= 6) {
                    if (features[0] <= 5) {
                        result[1] = 0.2;

                        result[2] = 0.6;

                        result[4] = 0.2;

                        return 255;
                    } else {
                        if (features[11] <= 4) {
                            if (features[8] <= 5) {
                                result[1] = 0.3333333333333333;

                                result[2] = 0.5;

                                result[4] = 0.16666666666666666;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[0] <= 7) {
                                if (features[6] <= 5) {
                                    return 4;
                                } else {
                                    if (features[5] <= 6) {
                                        return 4;
                                    } else {
                                        result[0] = 0.4;

                                        result[2] = 0.4;

                                        result[4] = 0.2;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 5) {
                                    return 4;
                                } else {
                                    result[1] = 0.5;

                                    result[3] = 0.3333333333333333;

                                    result[4] = 0.16666666666666666;

                                    return 255;

                                }

                            }

                        }

                    }
                } else {
                    if (features[10] <= 6) {
                        if (features[1] <= 8) {
                            if (features[8] <= 4) {
                                if (features[10] <= 5) {
                                    if (features[6] <= 4) {
                                        result[1] = 0.8;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        result[1] = 0.7142857142857143;

                                        result[2] = 0.2857142857142857;

                                        return 255;

                                    }
                                } else {
                                    result[0] = 0.5;

                                    result[1] = 0.16666666666666666;

                                    result[3] = 0.3333333333333333;

                                    return 255;

                                }
                            } else {
                                if (features[2] <= 7) {
                                    result[2] = 0.4444444444444444;

                                    result[4] = 0.5555555555555556;

                                    return 255;
                                } else {
                                    result[1] = 0.4;

                                    result[3] = 0.4;

                                    result[4] = 0.2;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[7] <= 2) {
                                if (features[9] <= 4) {
                                    result[1] = 0.75;

                                    result[4] = 0.25;

                                    return 255;
                                } else {
                                    result[0] = 0.5;

                                    result[1] = 0.25;

                                    result[4] = 0.25;

                                    return 255;

                                }
                            } else {
                                if (features[11] <= 5) {
                                    return 1;
                                } else {
                                    result[0] = 0.16666666666666666;

                                    result[1] = 0.8333333333333334;

                                    return 255;

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 8) {
                            if (features[0] <= 4) {
                                result[1] = 0.75;

                                result[2] = 0.25;

                                return 255;
                            } else {
                                if (features[8] <= 5) {
                                    if (features[8] <= 4) {
                                        result[0] = 0.25;

                                        result[1] = 0.5;

                                        result[2] = 0.25;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[3] <= 7) {
                                        return 1;
                                    } else {
                                        result[1] = 0.8;

                                        result[3] = 0.2;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 4) {
                                if (features[8] <= 0) {
                                    if (features[7] <= 4) {
                                        result[0] = 0.25;

                                        result[1] = 0.75;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                return 1;

                            }

                        }

                    }

                }
            } else {
                if (features[7] <= 3) {
                    if (features[6] <= 1) {
                        if (features[11] <= 7) {
                            if (features[3] <= 2) {
                                return 3;
                            } else {
                                if (features[3] <= 4) {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.14285714285714285;

                                    result[3] = 0.7142857142857143;

                                    return 255;
                                } else {
                                    if (features[6] <= 0) {
                                        result[0] = 0.2;

                                        result[2] = 0.4;

                                        result[4] = 0.4;

                                        return 255;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.42857142857142855;

                                        result[2] = 0.2857142857142857;

                                        result[3] = 0.14285714285714285;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            result[1] = 0.8571428571428571;

                            result[4] = 0.14285714285714285;

                            return 255;

                        }
                    } else {
                        if (features[0] <= 7) {
                            if (features[0] <= 3) {
                                result[2] = 0.16666666666666666;

                                result[3] = 0.8333333333333334;

                                return 255;
                            } else {
                                if (features[7] <= 0) {
                                    return 4;
                                } else {
                                    if (features[6] <= 3) {
                                        if (features[9] <= 2) {
                                            return 0;
                                        } else {
                                            result[0] = 0.5;

                                            result[1] = 0.25;

                                            result[2] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        if (features[7] <= 2) {
                                            result[0] = 0.2857142857142857;

                                            result[1] = 0.2857142857142857;

                                            result[2] = 0.14285714285714285;

                                            result[3] = 0.14285714285714285;

                                            result[4] = 0.14285714285714285;

                                            return 255;
                                        } else {
                                            if (features[3] <= 8) {
                                                result[0] = 0.25;

                                                result[1] = 0.75;

                                                return 255;
                                            } else {
                                                result[1] = 0.8571428571428571;

                                                result[3] = 0.14285714285714285;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[7] <= 1) {
                                if (features[10] <= 3) {
                                    if (features[6] <= 6) {
                                        return 4;
                                    } else {
                                        result[0] = 0.25;

                                        result[4] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 5) {
                                        result[3] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 2) {
                                    result[0] = 0.4444444444444444;

                                    result[1] = 0.1111111111111111;

                                    result[3] = 0.4444444444444444;

                                    return 255;
                                } else {
                                    if (features[5] <= 5) {
                                        if (features[1] <= 8) {
                                            result[1] = 0.25;

                                            result[2] = 0.25;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[4] <= 8) {
                                                result[3] = 0.25;

                                                result[4] = 0.75;

                                                return 255;
                                            } else {
                                                if (features[0] <= 7) {
                                                    result[3] = 0.2;

                                                    result[4] = 0.8;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[9] <= 3) {
                                            if (features[9] <= 2) {
                                                result[1] = 0.25;

                                                result[4] = 0.75;

                                                return 255;
                                            } else {
                                                if (features[6] <= 5) {
                                                    result[0] = 0.14285714285714285;

                                                    result[2] = 0.14285714285714285;

                                                    result[3] = 0.5714285714285714;

                                                    result[4] = 0.14285714285714285;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.25;

                                                    result[2] = 0.5;

                                                    result[3] = 0.25;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[6] <= 7) {
                                                if (features[0] <= 7) {
                                                    result[1] = 0.25;

                                                    result[4] = 0.75;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.25;

                                                    result[4] = 0.75;

                                                    return 255;

                                                }
                                            } else {
                                                result[1] = 0.8;

                                                result[2] = 0.2;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 7) {
                        if (features[3] <= 4) {
                            if (features[4] <= 7) {
                                result[1] = 0.3333333333333333;

                                result[4] = 0.6666666666666666;

                                return 255;
                            } else {
                                if (features[0] <= 6) {
                                    return 1;
                                } else {
                                    result[0] = 0.5;

                                    result[3] = 0.5;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[3] <= 6) {
                                if (features[5] <= 8) {
                                    if (features[6] <= 6) {
                                        if (features[0] <= 5) {
                                            return 0;
                                        } else {
                                            result[0] = 0.2;

                                            result[1] = 0.6;

                                            result[3] = 0.2;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= 2) {
                                            return 1;
                                        } else {
                                            result[0] = 0.14285714285714285;

                                            result[1] = 0.7142857142857143;

                                            result[2] = 0.14285714285714285;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 7) {
                                        result[0] = 0.8;

                                        result[1] = 0.2;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[4] <= 8) {
                                    if (features[11] <= 5) {
                                        if (features[11] <= 4) {
                                            result[0] = 0.2857142857142857;

                                            result[1] = 0.14285714285714285;

                                            result[2] = 0.42857142857142855;

                                            result[4] = 0.14285714285714285;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[6] <= 5) {
                                            result[0] = 0.3333333333333333;

                                            result[3] = 0.6666666666666666;

                                            return 255;
                                        } else {
                                            if (features[0] <= 3) {
                                                if (features[2] <= 7) {
                                                    result[0] = 0.75;

                                                    result[4] = 0.25;

                                                    return 255;
                                                } else {
                                                    if (features[0] <= 3) {
                                                        result[0] = 0.7142857142857143;

                                                        result[2] = 0.2857142857142857;

                                                        return 255;
                                                    } else {
                                                        return 0;

                                                    }

                                                }
                                            } else {
                                                if (features[1] <= 6) {
                                                    result[0] = 0.75;

                                                    result[2] = 0.25;

                                                    return 255;
                                                } else {
                                                    if (features[10] <= 3) {
                                                        result[0] = 0.6666666666666666;

                                                        result[2] = 0.3333333333333333;

                                                        return 255;
                                                    } else {
                                                        if (features[0] <= 7) {
                                                            if (features[10] <= 6) {
                                                                result[0] = 0.75;

                                                                result[2] = 0.25;

                                                                return 255;
                                                            } else {
                                                                result[0] = 0.14285714285714285;

                                                                result[1] = 0.42857142857142855;

                                                                result[3] = 0.42857142857142855;

                                                                return 255;

                                                            }
                                                        } else {
                                                            result[1] = 0.8333333333333334;

                                                            result[2] = 0.16666666666666666;

                                                            return 255;

                                                        }

                                                    }

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[1] <= 7) {
                                        return 0;
                                    } else {
                                        if (features[6] <= 8) {
                                            if (features[9] <= 6) {
                                                result[0] = 0.6666666666666666;

                                                result[2] = 0.3333333333333333;

                                                return 255;
                                            } else {
                                                result[1] = 0.25;

                                                result[2] = 0.5;

                                                result[4] = 0.25;

                                                return 255;

                                            }
                                        } else {
                                            if (features[10] <= 2) {
                                                result[0] = 0.5;

                                                result[2] = 0.5;

                                                return 255;
                                            } else {
                                                if (features[10] <= 5) {
                                                    result[0] = 0.8;

                                                    result[2] = 0.2;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[4] <= 8) {
                            if (features[8] <= 6) {
                                if (features[7] <= 5) {
                                    result[1] = 0.5;

                                    result[3] = 0.25;

                                    result[4] = 0.25;

                                    return 255;
                                } else {
                                    if (features[5] <= 4) {
                                        result[1] = 0.8;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                result[1] = 0.5;

                                result[3] = 0.3333333333333333;

                                result[4] = 0.16666666666666666;

                                return 255;

                            }
                        } else {
                            if (features[0] <= 7) {
                                if (features[7] <= 5) {
                                    result[0] = 0.16666666666666666;

                                    result[2] = 0.8333333333333334;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[2] <= 3) {
                                    result[0] = 0.8;

                                    result[2] = 0.2;

                                    return 255;
                                } else {
                                    if (features[3] <= 5) {
                                        result[1] = 0.125;

                                        result[3] = 0.875;

                                        return 255;
                                    } else {
                                        if (features[3] <= 6) {
                                            if (features[8] <= 5) {
                                                return 1;
                                            } else {
                                                result[1] = 0.7142857142857143;

                                                result[2] = 0.2857142857142857;

                                                return 255;

                                            }
                                        } else {
                                            if (features[7] <= 7) {
                                                if (features[10] <= 5) {
                                                    result[3] = 0.75;

                                                    result[4] = 0.25;

                                                    return 255;
                                                } else {
                                                    result[0] = 0.16666666666666666;

                                                    result[2] = 0.16666666666666666;

                                                    result[3] = 0.16666666666666666;

                                                    result[4] = 0.5;

                                                    return 255;

                                                }
                                            } else {
                                                result[1] = 0.14285714285714285;

                                                result[2] = 0.2857142857142857;

                                                result[3] = 0.5714285714285714;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char evaluate_forest(short* args) {
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
float total_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char return_res = 0;
unsigned char result_map[5] = { 1,2,3,4, 9 };
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree0(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
unsigned char max_index = 0;
float max_value = 0;
for (unsigned char i = 0; i < 5; ++i) {
if (max_value < total_res[i]) {
max_value = total_res[i];
max_index = i;
}
}
return result_map[max_index];
}
