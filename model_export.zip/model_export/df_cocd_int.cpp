unsigned char tree0(short* features, float* result){
    if (features[0] <= -122) {
        if (features[3] <= -6) {
            if (features[8] <= 407) {
                if (features[8] <= -275) {
                    if (features[8] <= -774) {
                        return 3;
                    } else {
                        result[3] = 0.4166666666666667;

                        result[4] = 0.5833333333333334;

                        return 255;

                    }
                } else {
                    if (features[7] <= 66) {
                        if (features[2] <= -8) {
                            if (features[3] <= -80) {
                                if (features[6] <= 44) {
                                    return 4;
                                } else {
                                    result[1] = 0.09090909090909091;

                                    result[4] = 0.9090909090909091;

                                    return 255;

                                }
                            } else {
                                if (features[1] <= -163) {
                                    return 4;
                                } else {
                                    if (features[5] <= -70) {
                                        return 0;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= -347) {
                                if (features[2] <= 2) {
                                    result[0] = 0.2;

                                    result[4] = 0.8;

                                    return 255;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[5] <= -34) {
                                    result[2] = 0.3333333333333333;

                                    result[3] = 0.3333333333333333;

                                    result[4] = 0.3333333333333333;

                                    return 255;
                                } else {
                                    if (features[2] <= -0) {
                                        if (features[9] <= -20) {
                                            result[3] = 0.75;

                                            result[4] = 0.25;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }
                    } else {
                        result[1] = 0.45454545454545453;

                        result[4] = 0.5454545454545454;

                        return 255;

                    }

                }
            } else {
                if (features[4] <= -187) {
                    result[1] = 0.9090909090909091;

                    result[2] = 0.09090909090909091;

                    return 255;
                } else {
                    return 2;

                }

            }
        } else {
            if (features[8] <= -10) {
                if (features[5] <= -160) {
                    if (features[6] <= -8) {
                        return 0;
                    } else {
                        result[0] = 0.8333333333333334;

                        result[2] = 0.16666666666666666;

                        return 255;

                    }
                } else {
                    if (features[2] <= -18) {
                        return 4;
                    } else {
                        if (features[9] <= -210) {
                            if (features[0] <= -464) {
                                result[0] = 0.2;

                                result[4] = 0.8;

                                return 255;
                            } else {
                                if (features[5] <= 242) {
                                    result[2] = 0.2;

                                    result[3] = 0.8;

                                    return 255;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[7] <= 38) {
                                if (features[8] <= -184) {
                                    result[0] = 0.2;

                                    result[3] = 0.2;

                                    result[4] = 0.6;

                                    return 255;
                                } else {
                                    if (features[4] <= 36) {
                                        return 4;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[4] = 0.8333333333333334;

                                        return 255;

                                    }

                                }
                            } else {
                                return 0;

                            }

                        }

                    }

                }
            } else {
                if (features[5] <= -24) {
                    if (features[0] <= -330) {
                        return 0;
                    } else {
                        if (features[5] <= -316) {
                            result[0] = 0.2857142857142857;

                            result[2] = 0.7142857142857143;

                            return 255;
                        } else {
                            if (features[3] <= 60) {
                                if (features[3] <= 18) {
                                    return 0;
                                } else {
                                    result[0] = 0.25;

                                    result[3] = 0.75;

                                    return 255;

                                }
                            } else {
                                if (features[6] <= -428) {
                                    result[0] = 0.5;

                                    result[2] = 0.5;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }
                } else {
                    if (features[3] <= 82) {
                        if (features[4] <= 40) {
                            if (features[9] <= -2) {
                                result[3] = 0.5;

                                result[4] = 0.5;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            result[0] = 0.4;

                            result[3] = 0.6;

                            return 255;

                        }
                    } else {
                        if (features[6] <= 303) {
                            if (features[6] <= 140) {
                                return 0;
                            } else {
                                if (features[5] <= 116) {
                                    result[0] = 0.5;

                                    result[1] = 0.5;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[3] <= 1362) {
                                if (features[9] <= 103) {
                                    return 1;
                                } else {
                                    result[0] = 0.16666666666666666;

                                    result[1] = 0.8333333333333334;

                                    return 255;

                                }
                            } else {
                                return 0;

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[8] <= 30) {
            if (features[0] <= 280) {
                if (features[5] <= 0) {
                    if (features[1] <= -497) {
                        return 0;
                    } else {
                        if (features[0] <= 12) {
                            if (features[8] <= -413) {
                                return 3;
                            } else {
                                if (features[3] <= -80) {
                                    if (features[0] <= -89) {
                                        return 4;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.8571428571428571;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= -210) {
                                        if (features[9] <= 94) {
                                            result[1] = 0.23076923076923078;

                                            result[2] = 0.07692307692307693;

                                            result[3] = 0.6923076923076923;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[4] <= 42) {
                                            if (features[2] <= -52) {
                                                if (features[1] <= 17) {
                                                    result[0] = 0.125;

                                                    result[1] = 0.25;

                                                    result[2] = 0.375;

                                                    result[3] = 0.25;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.75;

                                                    result[2] = 0.25;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= 101) {
                                                    if (features[1] <= 4) {
                                                        result[0] = 0.15384615384615385;

                                                        result[1] = 0.038461538461538464;

                                                        result[2] = 0.11538461538461539;

                                                        result[3] = 0.6923076923076923;

                                                        return 255;
                                                    } else {
                                                        result[2] = 0.8571428571428571;

                                                        result[3] = 0.14285714285714285;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[2] = 0.8;

                                                    result[3] = 0.2;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[5] <= -100) {
                                                result[0] = 0.42857142857142855;

                                                result[1] = 0.42857142857142855;

                                                result[3] = 0.14285714285714285;

                                                return 255;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= 326) {
                                if (features[2] <= -1) {
                                    if (features[9] <= -90) {
                                        if (features[2] <= -27) {
                                            if (features[6] <= -109) {
                                                return 1;
                                            } else {
                                                result[0] = 0.8571428571428571;

                                                result[3] = 0.14285714285714285;

                                                return 255;

                                            }
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[5] <= -50) {
                                            return 1;
                                        } else {
                                            result[1] = 0.8333333333333334;

                                            result[4] = 0.16666666666666666;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[4] <= -3) {
                                        if (features[7] <= 0) {
                                            return 1;
                                        } else {
                                            result[1] = 0.8571428571428571;

                                            result[2] = 0.14285714285714285;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= -6) {
                                            if (features[6] <= 82) {
                                                if (features[0] <= 105) {
                                                    result[0] = 0.25;

                                                    result[1] = 0.5;

                                                    result[2] = 0.25;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                result[2] = 0.8333333333333334;

                                                result[3] = 0.16666666666666666;

                                                return 255;

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= -4) {
                                    return 2;
                                } else {
                                    result[1] = 0.375;

                                    result[2] = 0.625;

                                    return 255;

                                }

                            }

                        }

                    }
                } else {
                    if (features[7] <= 6) {
                        if (features[2] <= -88) {
                            if (features[6] <= 455) {
                                if (features[5] <= 92) {
                                    return 4;
                                } else {
                                    result[1] = 0.2;

                                    result[4] = 0.8;

                                    return 255;

                                }
                            } else {
                                if (features[6] <= 823) {
                                    return 0;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[5] <= 46) {
                                if (features[0] <= -62) {
                                    result[3] = 0.1;

                                    result[4] = 0.9;

                                    return 255;
                                } else {
                                    if (features[7] <= -104) {
                                        result[2] = 0.42857142857142855;

                                        result[3] = 0.5714285714285714;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[2] = 0.1111111111111111;

                                        result[3] = 0.5555555555555556;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 6) {
                                    if (features[2] <= 152) {
                                        if (features[8] <= 2) {
                                            if (features[3] <= 234) {
                                                if (features[2] <= -77) {
                                                    result[2] = 0.2;

                                                    result[3] = 0.8;

                                                    return 255;
                                                } else {
                                                    if (features[1] <= -18) {
                                                        return 3;
                                                    } else {
                                                        result[3] = 0.967741935483871;

                                                        result[4] = 0.03225806451612903;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                result[3] = 0.5714285714285714;

                                                result[4] = 0.42857142857142855;

                                                return 255;

                                            }
                                        } else {
                                            if (features[4] <= -9) {
                                                result[3] = 0.14285714285714285;

                                                result[4] = 0.8571428571428571;

                                                return 255;
                                            } else {
                                                result[3] = 0.7777777777777778;

                                                result[4] = 0.2222222222222222;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        result[1] = 0.14285714285714285;

                                        result[2] = 0.07142857142857142;

                                        result[3] = 0.7857142857142857;

                                        return 255;

                                    }
                                } else {
                                    if (features[9] <= -182) {
                                        if (features[4] <= -22) {
                                            result[2] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[6] <= 30) {
                                                result[2] = 0.2;

                                                result[3] = 0.8;

                                                return 255;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        if (features[9] <= 46) {
                                            if (features[2] <= 0) {
                                                return 2;
                                            } else {
                                                if (features[5] <= 193) {
                                                    return 3;
                                                } else {
                                                    result[2] = 0.3333333333333333;

                                                    result[3] = 0.16666666666666666;

                                                    result[4] = 0.5;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[2] <= 8) {
                                                result[1] = 0.125;

                                                result[3] = 0.125;

                                                result[4] = 0.75;

                                                return 255;
                                            } else {
                                                return 4;

                                            }

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 100) {
                            if (features[9] <= 31) {
                                if (features[2] <= -122) {
                                    result[0] = 0.375;

                                    result[2] = 0.25;

                                    result[3] = 0.375;

                                    return 255;
                                } else {
                                    if (features[5] <= 112) {
                                        return 3;
                                    } else {
                                        if (features[5] <= 736) {
                                            if (features[4] <= -128) {
                                                return 4;
                                            } else {
                                                if (features[6] <= 388) {
                                                    if (features[8] <= -90) {
                                                        result[3] = 0.5333333333333333;

                                                        result[4] = 0.4666666666666667;

                                                        return 255;
                                                    } else {
                                                        result[3] = 0.12698412698412698;

                                                        result[4] = 0.873015873015873;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[7] <= 139) {
                                                        result[3] = 0.8181818181818182;

                                                        result[4] = 0.18181818181818182;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.08333333333333333;

                                                        result[3] = 0.08333333333333333;

                                                        result[4] = 0.8333333333333334;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= 2) {
                                    if (features[5] <= 180) {
                                        if (features[2] <= -58) {
                                            return 3;
                                        } else {
                                            if (features[7] <= 52) {
                                                return 4;
                                            } else {
                                                result[3] = 0.625;

                                                result[4] = 0.375;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[5] <= 46) {
                                        if (features[4] <= 24) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[1] <= -52) {
                                            return 1;
                                        } else {
                                            if (features[1] <= 70) {
                                                if (features[5] <= 124) {
                                                    if (features[3] <= 62) {
                                                        result[3] = 0.8333333333333334;

                                                        result[4] = 0.16666666666666666;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }
                                                } else {
                                                    result[3] = 0.16666666666666666;

                                                    result[4] = 0.8333333333333334;

                                                    return 255;

                                                }
                                            } else {
                                                return 4;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[2] <= -12) {
                                return 0;
                            } else {
                                if (features[1] <= 244) {
                                    result[2] = 0.3333333333333333;

                                    result[3] = 0.6666666666666666;

                                    return 255;
                                } else {
                                    result[0] = 0.4444444444444444;

                                    result[1] = 0.3333333333333333;

                                    result[3] = 0.2222222222222222;

                                    return 255;

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= 339) {
                    if (features[4] <= -129) {
                        return 1;
                    } else {
                        result[0] = 0.8;

                        result[3] = 0.2;

                        return 255;

                    }
                } else {
                    if (features[2] <= 26) {
                        return 1;
                    } else {
                        result[1] = 0.8;

                        result[4] = 0.2;

                        return 255;

                    }

                }

            }
        } else {
            if (features[3] <= -540) {
                if (features[3] <= -727) {
                    if (features[6] <= 526) {
                        return 1;
                    } else {
                        result[0] = 0.5;

                        result[1] = 0.5;

                        return 255;

                    }
                } else {
                    if (features[6] <= -210) {
                        result[1] = 0.25;

                        result[2] = 0.75;

                        return 255;
                    } else {
                        if (features[7] <= 142) {
                            return 1;
                        } else {
                            result[0] = 0.375;

                            result[1] = 0.625;

                            return 255;

                        }

                    }

                }
            } else {
                if (features[8] <= 340) {
                    if (features[3] <= 83) {
                        if (features[5] <= 78) {
                            if (features[1] <= 178) {
                                if (features[6] <= 45) {
                                    if (features[9] <= -1) {
                                        if (features[6] <= -248) {
                                            result[0] = 0.2;

                                            result[3] = 0.8;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[4] <= 1) {
                                            if (features[3] <= 14) {
                                                if (features[9] <= 48) {
                                                    if (features[5] <= -24) {
                                                        result[1] = 0.625;

                                                        result[3] = 0.375;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.5;

                                                        result[2] = 0.5;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[4] <= -118) {
                                                        result[1] = 0.8888888888888888;

                                                        result[2] = 0.1111111111111111;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.046511627906976744;

                                                        result[2] = 0.9534883720930233;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            if (features[5] <= -40) {
                                                if (features[3] <= 51) {
                                                    if (features[6] <= -51) {
                                                        return 2;
                                                    } else {
                                                        result[0] = 0.4;

                                                        result[2] = 0.6;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[2] = 0.3333333333333333;

                                                    result[3] = 0.6666666666666666;

                                                    return 255;

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[0] <= 34) {
                                        if (features[5] <= 62) {
                                            result[3] = 0.6;

                                            result[4] = 0.4;

                                            return 255;
                                        } else {
                                            if (features[6] <= 60) {
                                                result[2] = 0.6;

                                                result[3] = 0.4;

                                                return 255;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        if (features[8] <= 72) {
                                            result[1] = 0.6666666666666666;

                                            result[2] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            result[0] = 0.3;

                                            result[2] = 0.7;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= -332) {
                                    result[0] = 0.6;

                                    result[1] = 0.4;

                                    return 255;
                                } else {
                                    if (features[4] <= -10) {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 272) {
                                if (features[2] <= -0) {
                                    if (features[0] <= 58) {
                                        if (features[1] <= -14) {
                                            if (features[6] <= 84) {
                                                result[2] = 0.4444444444444444;

                                                result[3] = 0.2222222222222222;

                                                result[4] = 0.3333333333333333;

                                                return 255;
                                            } else {
                                                if (features[9] <= 78) {
                                                    if (features[4] <= -6) {
                                                        result[0] = 0.14285714285714285;

                                                        result[4] = 0.8571428571428571;

                                                        return 255;
                                                    } else {
                                                        return 4;

                                                    }
                                                } else {
                                                    result[3] = 0.2857142857142857;

                                                    result[4] = 0.7142857142857143;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[5] <= 120) {
                                                if (features[3] <= 12) {
                                                    return 2;
                                                } else {
                                                    result[2] = 0.4;

                                                    result[3] = 0.6;

                                                    return 255;

                                                }
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[3] <= -21) {
                                            if (features[8] <= 138) {
                                                if (features[9] <= 58) {
                                                    if (features[0] <= 174) {
                                                        result[0] = 0.8;

                                                        result[1] = 0.2;

                                                        return 255;
                                                    } else {
                                                        return 0;

                                                    }
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[1] <= 409) {
                                                    result[0] = 0.375;

                                                    result[1] = 0.625;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }
                                        } else {
                                            result[1] = 0.8888888888888888;

                                            result[2] = 0.1111111111111111;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 30) {
                                        if (features[6] <= 176) {
                                            if (features[0] <= 3) {
                                                if (features[4] <= 14) {
                                                    return 4;
                                                } else {
                                                    result[3] = 0.25;

                                                    result[4] = 0.75;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= 12) {
                                                    result[2] = 0.7;

                                                    result[3] = 0.1;

                                                    result[4] = 0.2;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[6] <= 21) {
                                            return 2;
                                        } else {
                                            if (features[9] <= 81) {
                                                if (features[7] <= 185) {
                                                    result[0] = 0.16666666666666666;

                                                    result[1] = 0.6666666666666666;

                                                    result[2] = 0.16666666666666666;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[8] <= 100) {
                                                    if (features[3] <= 37) {
                                                        result[1] = 0.9166666666666666;

                                                        result[2] = 0.08333333333333333;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.8;

                                                        result[1] = 0.2;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 1;

                                                }

                                            }

                                        }

                                    }

                                }
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        if (features[5] <= 114) {
                            if (features[9] <= 124) {
                                if (features[3] <= 152) {
                                    if (features[6] <= 110) {
                                        if (features[2] <= 91) {
                                            if (features[0] <= 38) {
                                                result[0] = 0.75;

                                                result[1] = 0.25;

                                                return 255;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            result[0] = 0.16666666666666666;

                                            result[2] = 0.8333333333333334;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= 80) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[2] <= 38) {
                                        return 0;
                                    } else {
                                        if (features[4] <= 123) {
                                            return 0;
                                        } else {
                                            if (features[5] <= 56) {
                                                result[0] = 0.4;

                                                result[1] = 0.6;

                                                return 255;
                                            } else {
                                                result[0] = 0.8181818181818182;

                                                result[1] = 0.18181818181818182;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[1] <= -1) {
                                    result[0] = 0.75;

                                    result[2] = 0.25;

                                    return 255;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[0] <= -2) {
                                if (features[0] <= -16) {
                                    return 1;
                                } else {
                                    if (features[4] <= 92) {
                                        return 1;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 20) {
                                    if (features[4] <= 95) {
                                        return 1;
                                    } else {
                                        if (features[9] <= 122) {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[6] <= 182) {
                                        result[1] = 0.7142857142857143;

                                        result[3] = 0.14285714285714285;

                                        result[4] = 0.14285714285714285;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= -32) {
                        if (features[9] <= 71) {
                            if (features[6] <= -592) {
                                return 2;
                            } else {
                                result[0] = 0.125;

                                result[1] = 0.625;

                                result[3] = 0.25;

                                return 255;

                            }
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[1] <= -444) {
                            if (features[3] <= 462) {
                                result[0] = 0.7142857142857143;

                                result[2] = 0.2857142857142857;

                                return 255;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[6] <= -48) {
                                if (features[1] <= 675) {
                                    return 2;
                                } else {
                                    result[1] = 0.4;

                                    result[2] = 0.6;

                                    return 255;

                                }
                            } else {
                                result[1] = 0.3;

                                result[4] = 0.7;

                                return 255;

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree1(short* features, float* result){
    if (features[9] <= 118) {
        if (features[7] <= 4) {
            if (features[0] <= -114) {
                if (features[4] <= 328) {
                    if (features[6] <= 78) {
                        if (features[3] <= 609) {
                            if (features[5] <= -56) {
                                if (features[9] <= -186) {
                                    if (features[1] <= -172) {
                                        result[0] = 0.625;

                                        result[1] = 0.1875;

                                        result[4] = 0.1875;

                                        return 255;
                                    } else {
                                        result[1] = 0.3;

                                        result[3] = 0.5;

                                        result[4] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    if (features[9] <= -75) {
                                        if (features[3] <= -124) {
                                            result[2] = 0.2857142857142857;

                                            result[4] = 0.7142857142857143;

                                            return 255;
                                        } else {
                                            if (features[5] <= -150) {
                                                result[0] = 0.1111111111111111;

                                                result[4] = 0.8888888888888888;

                                                return 255;
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= -84) {
                                            result[2] = 0.5714285714285714;

                                            result[4] = 0.42857142857142855;

                                            return 255;
                                        } else {
                                            if (features[0] <= -286) {
                                                result[0] = 0.5;

                                                result[4] = 0.5;

                                                return 255;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[5] <= 164) {
                                    if (features[4] <= 8) {
                                        return 4;
                                    } else {
                                        if (features[9] <= -20) {
                                            return 4;
                                        } else {
                                            result[0] = 0.2;

                                            result[2] = 0.2;

                                            result[4] = 0.6;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[7] <= -71) {
                                result[0] = 0.4;

                                result[3] = 0.4;

                                result[4] = 0.2;

                                return 255;
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[1] <= -122) {
                            if (features[4] <= 106) {
                                if (features[5] <= 344) {
                                    result[1] = 0.8333333333333334;

                                    result[3] = 0.16666666666666666;

                                    return 255;
                                } else {
                                    return 3;

                                }
                            } else {
                                result[0] = 0.25;

                                result[3] = 0.75;

                                return 255;

                            }
                        } else {
                            if (features[2] <= 11) {
                                result[2] = 0.25;

                                result[3] = 0.75;

                                return 255;
                            } else {
                                return 3;

                            }

                        }

                    }
                } else {
                    if (features[4] <= 532) {
                        if (features[5] <= -118) {
                            return 0;
                        } else {
                            if (features[6] <= 38) {
                                result[0] = 0.1;

                                result[4] = 0.9;

                                return 255;
                            } else {
                                result[0] = 0.5;

                                result[3] = 0.5;

                                return 255;

                            }

                        }
                    } else {
                        return 0;

                    }

                }
            } else {
                if (features[6] <= 48) {
                    if (features[3] <= -37) {
                        if (features[0] <= -89) {
                            if (features[6] <= -64) {
                                result[1] = 0.3333333333333333;

                                result[2] = 0.16666666666666666;

                                result[4] = 0.5;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[8] <= 1036) {
                                if (features[5] <= 18) {
                                    if (features[8] <= -116) {
                                        if (features[2] <= -26) {
                                            if (features[9] <= -162) {
                                                result[0] = 0.14285714285714285;

                                                result[1] = 0.8571428571428571;

                                                return 255;
                                            } else {
                                                result[0] = 0.5;

                                                result[1] = 0.16666666666666666;

                                                result[4] = 0.3333333333333333;

                                                return 255;

                                            }
                                        } else {
                                            if (features[3] <= -404) {
                                                return 1;
                                            } else {
                                                if (features[4] <= -618) {
                                                    return 1;
                                                } else {
                                                    result[1] = 0.5;

                                                    result[4] = 0.5;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    result[0] = 0.2222222222222222;

                                    result[1] = 0.2222222222222222;

                                    result[2] = 0.3333333333333333;

                                    result[4] = 0.2222222222222222;

                                    return 255;

                                }
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[0] <= 86) {
                            if (features[2] <= 30) {
                                if (features[9] <= 22) {
                                    if (features[1] <= -80) {
                                        if (features[8] <= 118) {
                                            result[0] = 0.375;

                                            result[1] = 0.25;

                                            result[4] = 0.375;

                                            return 255;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[1] <= 14) {
                                            if (features[8] <= -58) {
                                                result[1] = 0.18181818181818182;

                                                result[2] = 0.09090909090909091;

                                                result[3] = 0.5454545454545454;

                                                result[4] = 0.18181818181818182;

                                                return 255;
                                            } else {
                                                if (features[6] <= 22) {
                                                    if (features[8] <= 224) {
                                                        result[0] = 0.03389830508474576;

                                                        result[3] = 0.9661016949152542;

                                                        return 255;
                                                    } else {
                                                        result[2] = 0.3333333333333333;

                                                        result[3] = 0.6666666666666666;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[2] = 0.6;

                                                    result[3] = 0.4;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[5] <= -82) {
                                                result[1] = 0.375;

                                                result[3] = 0.625;

                                                return 255;
                                            } else {
                                                result[1] = 0.14285714285714285;

                                                result[2] = 0.8571428571428571;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[3] <= 29) {
                                        if (features[8] <= 56) {
                                            if (features[5] <= 129) {
                                                result[1] = 0.6;

                                                result[4] = 0.4;

                                                return 255;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            result[2] = 0.4;

                                            result[3] = 0.4;

                                            result[4] = 0.2;

                                            return 255;

                                        }
                                    } else {
                                        result[2] = 0.26666666666666666;

                                        result[3] = 0.5333333333333333;

                                        result[4] = 0.2;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[9] <= -54) {
                                    result[0] = 0.25;

                                    result[1] = 0.25;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    if (features[1] <= -490) {
                                        return 0;
                                    } else {
                                        if (features[6] <= -732) {
                                            return 2;
                                        } else {
                                            if (features[5] <= -75) {
                                                return 0;
                                            } else {
                                                result[0] = 0.25;

                                                result[2] = 0.25;

                                                result[3] = 0.5;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= -6) {
                                if (features[8] <= 7) {
                                    return 1;
                                } else {
                                    result[1] = 0.25;

                                    result[3] = 0.75;

                                    return 255;

                                }
                            } else {
                                if (features[2] <= 6) {
                                    return 3;
                                } else {
                                    result[2] = 0.2;

                                    result[3] = 0.8;

                                    return 255;

                                }

                            }

                        }

                    }
                } else {
                    if (features[3] <= -406) {
                        if (features[2] <= -65) {
                            result[0] = 0.7777777777777778;

                            result[3] = 0.2222222222222222;

                            return 255;
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[1] <= -528) {
                            result[0] = 0.6;

                            result[1] = 0.4;

                            return 255;
                        } else {
                            if (features[9] <= -74) {
                                if (features[5] <= 270) {
                                    if (features[8] <= -355) {
                                        return 3;
                                    } else {
                                        if (features[7] <= -15) {
                                            if (features[3] <= 24) {
                                                return 3;
                                            } else {
                                                result[2] = 0.6;

                                                result[3] = 0.4;

                                                return 255;

                                            }
                                        } else {
                                            if (features[5] <= 146) {
                                                result[0] = 0.16666666666666666;

                                                result[2] = 0.8333333333333334;

                                                return 255;
                                            } else {
                                                result[2] = 0.5714285714285714;

                                                result[3] = 0.42857142857142855;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[4] <= -6) {
                                    result[1] = 0.2222222222222222;

                                    result[2] = 0.1111111111111111;

                                    result[3] = 0.1111111111111111;

                                    result[4] = 0.5555555555555556;

                                    return 255;
                                } else {
                                    if (features[4] <= 58) {
                                        if (features[3] <= -18) {
                                            if (features[1] <= -40) {
                                                return 3;
                                            } else {
                                                result[3] = 0.5;

                                                result[4] = 0.5;

                                                return 255;

                                            }
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        result[0] = 0.25;

                                        result[1] = 0.125;

                                        result[3] = 0.125;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[6] <= -2) {
                if (features[9] <= -0) {
                    if (features[1] <= 6) {
                        if (features[0] <= -328) {
                            if (features[4] <= 214) {
                                if (features[5] <= -96) {
                                    result[0] = 0.3333333333333333;

                                    result[4] = 0.6666666666666666;

                                    return 255;
                                } else {
                                    return 4;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[8] <= 490) {
                                if (features[3] <= 156) {
                                    return 3;
                                } else {
                                    return 0;

                                }
                            } else {
                                result[0] = 0.7;

                                result[2] = 0.3;

                                return 255;

                            }

                        }
                    } else {
                        if (features[7] <= 324) {
                            if (features[3] <= -104) {
                                return 1;
                            } else {
                                result[1] = 0.3333333333333333;

                                result[4] = 0.6666666666666666;

                                return 255;

                            }
                        } else {
                            return 2;

                        }

                    }
                } else {
                    if (features[1] <= 877) {
                        if (features[3] <= 117) {
                            if (features[4] <= -54) {
                                return 1;
                            } else {
                                if (features[8] <= 30) {
                                    if (features[1] <= -19) {
                                        result[0] = 0.7;

                                        result[2] = 0.2;

                                        result[4] = 0.1;

                                        return 255;
                                    } else {
                                        result[1] = 0.25;

                                        result[2] = 0.75;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= -220) {
                                        result[1] = 0.09090909090909091;

                                        result[2] = 0.7272727272727273;

                                        result[3] = 0.18181818181818182;

                                        return 255;
                                    } else {
                                        if (features[2] <= -162) {
                                            result[1] = 0.16666666666666666;

                                            result[2] = 0.8333333333333334;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= -668) {
                                if (features[1] <= -230) {
                                    result[0] = 0.42857142857142855;

                                    result[2] = 0.5714285714285714;

                                    return 255;
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[3] <= 199) {
                                    result[0] = 0.5;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        return 1;

                    }

                }
            } else {
                if (features[3] <= 90) {
                    if (features[0] <= 50) {
                        if (features[1] <= 16) {
                            if (features[0] <= 10) {
                                if (features[2] <= 14) {
                                    if (features[0] <= -128) {
                                        if (features[9] <= -153) {
                                            return 3;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[3] <= -19) {
                                            if (features[5] <= 100) {
                                                if (features[2] <= -55) {
                                                    result[0] = 0.2857142857142857;

                                                    result[3] = 0.2857142857142857;

                                                    result[4] = 0.42857142857142855;

                                                    return 255;
                                                } else {
                                                    result[2] = 0.6666666666666666;

                                                    result[3] = 0.3333333333333333;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[1] <= -120) {
                                                    if (features[6] <= 682) {
                                                        result[3] = 0.21739130434782608;

                                                        result[4] = 0.782608695652174;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            if (features[2] <= -11) {
                                                return 3;
                                            } else {
                                                if (features[5] <= 122) {
                                                    return 3;
                                                } else {
                                                    if (features[5] <= 304) {
                                                        result[3] = 0.1724137931034483;

                                                        result[4] = 0.8275862068965517;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[6] <= 95) {
                                        if (features[0] <= -23) {
                                            result[0] = 0.2727272727272727;

                                            result[1] = 0.2727272727272727;

                                            result[2] = 0.09090909090909091;

                                            result[4] = 0.36363636363636365;

                                            return 255;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[0] <= -25) {
                                            if (features[8] <= -776) {
                                                result[3] = 0.8571428571428571;

                                                result[4] = 0.14285714285714285;

                                                return 255;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            result[3] = 0.8888888888888888;

                                            result[4] = 0.1111111111111111;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= 32) {
                                    if (features[3] <= 4) {
                                        if (features[7] <= 34) {
                                            return 4;
                                        } else {
                                            if (features[8] <= 94) {
                                                if (features[9] <= 86) {
                                                    if (features[6] <= 140) {
                                                        return 2;
                                                    } else {
                                                        result[3] = 0.8;

                                                        result[4] = 0.2;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[5] <= 120) {
                                            return 3;
                                        } else {
                                            result[3] = 0.6;

                                            result[4] = 0.4;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[3] <= 14) {
                                        if (features[9] <= 68) {
                                            result[2] = 0.4444444444444444;

                                            result[3] = 0.2222222222222222;

                                            result[4] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        result[2] = 0.1111111111111111;

                                        result[3] = 0.8888888888888888;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= 40) {
                                if (features[5] <= 118) {
                                    if (features[3] <= -8) {
                                        return 2;
                                    } else {
                                        if (features[4] <= 14) {
                                            result[1] = 0.6666666666666666;

                                            result[4] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            result[2] = 0.3333333333333333;

                                            result[3] = 0.6666666666666666;

                                            return 255;

                                        }

                                    }
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[3] <= -2) {
                                    return 1;
                                } else {
                                    return 4;

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 78) {
                            if (features[1] <= 186) {
                                if (features[8] <= 74) {
                                    if (features[8] <= -215) {
                                        result[2] = 0.75;

                                        result[3] = 0.25;

                                        return 255;
                                    } else {
                                        if (features[3] <= 3) {
                                            return 1;
                                        } else {
                                            result[1] = 0.4;

                                            result[3] = 0.6;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[3] <= 16) {
                                        return 2;
                                    } else {
                                        result[0] = 0.5;

                                        result[2] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[7] <= 128) {
                                    result[0] = 0.5555555555555556;

                                    result[1] = 0.4444444444444444;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[3] <= -40) {
                                if (features[2] <= 32) {
                                    if (features[1] <= 452) {
                                        if (features[5] <= 238) {
                                            return 0;
                                        } else {
                                            result[0] = 0.4;

                                            result[4] = 0.6;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= 59) {
                                            return 0;
                                        } else {
                                            if (features[5] <= 182) {
                                                result[0] = 0.1;

                                                result[1] = 0.9;

                                                return 255;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[0] <= 298) {
                                        if (features[6] <= 223) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[5] <= 211) {
                                            return 1;
                                        } else {
                                            result[0] = 0.2;

                                            result[1] = 0.8;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 62) {
                                    if (features[8] <= -4) {
                                        return 3;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[2] = 0.5;

                                        result[3] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[1] <= 68) {
                                        if (features[2] <= 50) {
                                            result[0] = 0.4;

                                            result[2] = 0.6;

                                            return 255;
                                        } else {
                                            result[0] = 0.75;

                                            result[3] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= 35) {
                                            result[0] = 0.4;

                                            result[4] = 0.6;

                                            return 255;
                                        } else {
                                            if (features[9] <= 73) {
                                                result[1] = 0.75;

                                                result[4] = 0.25;

                                                return 255;
                                            } else {
                                                return 1;

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[3] <= 997) {
                        if (features[1] <= -62) {
                            if (features[9] <= 0) {
                                if (features[0] <= -53) {
                                    result[1] = 0.4;

                                    result[3] = 0.6;

                                    return 255;
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[5] <= 106) {
                                    if (features[8] <= 82) {
                                        if (features[6] <= 106) {
                                            result[0] = 0.5;

                                            result[1] = 0.3333333333333333;

                                            result[4] = 0.16666666666666666;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[6] <= 316) {
                                            return 0;
                                        } else {
                                            result[0] = 0.6666666666666666;

                                            result[1] = 0.3333333333333333;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[4] <= 56) {
                                        result[0] = 0.1;

                                        result[1] = 0.9;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 118) {
                                if (features[9] <= 36) {
                                    if (features[3] <= 179) {
                                        result[2] = 0.625;

                                        result[3] = 0.375;

                                        return 255;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[3] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 78) {
                                        if (features[5] <= 88) {
                                            result[0] = 0.8571428571428571;

                                            result[2] = 0.14285714285714285;

                                            return 255;
                                        } else {
                                            result[1] = 0.8571428571428571;

                                            result[3] = 0.14285714285714285;

                                            return 255;

                                        }
                                    } else {
                                        if (features[6] <= 131) {
                                            return 0;
                                        } else {
                                            result[0] = 0.8;

                                            result[1] = 0.2;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 124) {
                                    if (features[9] <= 26) {
                                        result[3] = 0.3333333333333333;

                                        result[4] = 0.6666666666666666;

                                        return 255;
                                    } else {
                                        result[3] = 0.875;

                                        result[4] = 0.125;

                                        return 255;

                                    }
                                } else {
                                    if (features[2] <= 153) {
                                        return 4;
                                    } else {
                                        result[1] = 0.2;

                                        result[3] = 0.2;

                                        result[4] = 0.6;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[8] <= -892) {
                            return 3;
                        } else {
                            if (features[3] <= 1041) {
                                result[0] = 0.9090909090909091;

                                result[1] = 0.09090909090909091;

                                return 255;
                            } else {
                                return 0;

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[6] <= 57) {
            if (features[9] <= 316) {
                if (features[5] <= 324) {
                    if (features[8] <= 324) {
                        if (features[4] <= -104) {
                            return 1;
                        } else {
                            if (features[4] <= 198) {
                                if (features[3] <= 12) {
                                    if (features[3] <= -196) {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.3333333333333333;

                                        result[2] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[2] <= 6) {
                                        result[0] = 0.14285714285714285;

                                        result[3] = 0.8571428571428571;

                                        return 255;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[2] <= -180) {
                            result[1] = 0.8333333333333334;

                            result[2] = 0.16666666666666666;

                            return 255;
                        } else {
                            if (features[3] <= 475) {
                                if (features[6] <= -142) {
                                    if (features[2] <= -88) {
                                        result[2] = 0.8;

                                        result[4] = 0.2;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    result[0] = 0.3333333333333333;

                                    result[2] = 0.6666666666666666;

                                    return 255;

                                }
                            } else {
                                return 0;

                            }

                        }

                    }
                } else {
                    return 4;

                }
            } else {
                if (features[0] <= -333) {
                    result[0] = 0.5555555555555556;

                    result[2] = 0.4444444444444444;

                    return 255;
                } else {
                    if (features[0] <= 158) {
                        return 2;
                    } else {
                        if (features[5] <= -402) {
                            return 2;
                        } else {
                            if (features[4] <= -330) {
                                return 1;
                            } else {
                                return 2;

                            }

                        }

                    }

                }

            }
        } else {
            if (features[5] <= 314) {
                if (features[1] <= 58) {
                    if (features[1] <= -120) {
                        return 0;
                    } else {
                        result[0] = 0.75;

                        result[4] = 0.25;

                        return 255;

                    }
                } else {
                    if (features[2] <= 107) {
                        if (features[3] <= -250) {
                            return 1;
                        } else {
                            result[0] = 0.2;

                            result[1] = 0.8;

                            return 255;

                        }
                    } else {
                        result[1] = 0.42857142857142855;

                        result[2] = 0.5714285714285714;

                        return 255;

                    }

                }
            } else {
                if (features[3] <= 81) {
                    return 4;
                } else {
                    result[0] = 0.14285714285714285;

                    result[4] = 0.8571428571428571;

                    return 255;

                }

            }

        }

    }
}

unsigned char tree2(short* features, float* result){
    if (features[5] <= 282) {
        if (features[6] <= -374) {
            if (features[3] <= -313) {
                if (features[8] <= 1010) {
                    return 1;
                } else {
                    if (features[5] <= -327) {
                        return 2;
                    } else {
                        result[1] = 0.3333333333333333;

                        result[2] = 0.6666666666666666;

                        return 255;

                    }

                }
            } else {
                if (features[1] <= -401) {
                    if (features[8] <= 500) {
                        if (features[4] <= 6) {
                            result[0] = 0.75;

                            result[2] = 0.25;

                            return 255;
                        } else {
                            return 0;

                        }
                    } else {
                        result[0] = 0.375;

                        result[3] = 0.625;

                        return 255;

                    }
                } else {
                    if (features[2] <= -0) {
                        if (features[8] <= 80) {
                            result[0] = 0.2222222222222222;

                            result[1] = 0.6666666666666666;

                            result[2] = 0.1111111111111111;

                            return 255;
                        } else {
                            if (features[9] <= 6) {
                                if (features[7] <= 50) {
                                    result[1] = 0.6;

                                    result[2] = 0.4;

                                    return 255;
                                } else {
                                    return 2;

                                }
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[4] <= -218) {
                            result[1] = 0.16666666666666666;

                            result[2] = 0.8333333333333334;

                            return 255;
                        } else {
                            return 2;

                        }

                    }

                }

            }
        } else {
            if (features[8] <= -12) {
                if (features[0] <= -93) {
                    if (features[0] <= -737) {
                        if (features[2] <= -15) {
                            result[0] = 0.75;

                            result[4] = 0.25;

                            return 255;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[6] <= 98) {
                            if (features[3] <= 66) {
                                if (features[9] <= -214) {
                                    if (features[2] <= -43) {
                                        result[0] = 0.4444444444444444;

                                        result[4] = 0.5555555555555556;

                                        return 255;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[4] <= 150) {
                                        return 4;
                                    } else {
                                        result[0] = 0.8333333333333334;

                                        result[4] = 0.16666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[9] <= -58) {
                                    if (features[0] <= -412) {
                                        if (features[8] <= -98) {
                                            if (features[6] <= -6) {
                                                return 4;
                                            } else {
                                                result[0] = 0.42857142857142855;

                                                result[4] = 0.5714285714285714;

                                                return 255;

                                            }
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[1] <= -158) {
                                            return 0;
                                        } else {
                                            result[0] = 0.2;

                                            result[1] = 0.6;

                                            result[2] = 0.2;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[8] <= -319) {
                                        result[0] = 0.4;

                                        result[4] = 0.6;

                                        return 255;
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= -130) {
                                result[0] = 0.25;

                                result[2] = 0.25;

                                result[3] = 0.5;

                                return 255;
                            } else {
                                if (features[5] <= 166) {
                                    return 3;
                                } else {
                                    result[1] = 0.5;

                                    result[3] = 0.5;

                                    return 255;

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= -24) {
                        if (features[9] <= 126) {
                            if (features[0] <= 128) {
                                if (features[1] <= -489) {
                                    return 0;
                                } else {
                                    if (features[8] <= -208) {
                                        if (features[8] <= -586) {
                                            return 3;
                                        } else {
                                            result[0] = 0.125;

                                            result[2] = 0.875;

                                            return 255;

                                        }
                                    } else {
                                        if (features[0] <= -22) {
                                            result[1] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[3] <= -248) {
                                                return 1;
                                            } else {
                                                result[0] = 0.4444444444444444;

                                                result[1] = 0.5555555555555556;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= 55) {
                                    return 1;
                                } else {
                                    result[1] = 0.8888888888888888;

                                    result[4] = 0.1111111111111111;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[4] <= 28) {
                                result[1] = 0.25;

                                result[2] = 0.75;

                                return 255;
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[7] <= 2) {
                            if (features[2] <= 330) {
                                if (features[1] <= 8) {
                                    if (features[6] <= 92) {
                                        if (features[7] <= -41) {
                                            result[1] = 0.5714285714285714;

                                            result[2] = 0.14285714285714285;

                                            result[3] = 0.2857142857142857;

                                            return 255;
                                        } else {
                                            result[3] = 0.42857142857142855;

                                            result[4] = 0.5714285714285714;

                                            return 255;

                                        }
                                    } else {
                                        if (features[5] <= 46) {
                                            if (features[3] <= 866) {
                                                if (features[7] <= -166) {
                                                    return 3;
                                                } else {
                                                    result[2] = 0.2;

                                                    result[3] = 0.8;

                                                    return 255;

                                                }
                                            } else {
                                                result[0] = 0.25;

                                                result[3] = 0.75;

                                                return 255;

                                            }
                                        } else {
                                            if (features[2] <= -77) {
                                                if (features[6] <= 908) {
                                                    result[1] = 0.25;

                                                    result[2] = 0.25;

                                                    result[3] = 0.5;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[8] <= -412) {
                                        return 3;
                                    } else {
                                        if (features[9] <= -18) {
                                            if (features[2] <= 4) {
                                                return 2;
                                            } else {
                                                result[1] = 0.5714285714285714;

                                                result[2] = 0.42857142857142855;

                                                return 255;

                                            }
                                        } else {
                                            if (features[3] <= -264) {
                                                return 0;
                                            } else {
                                                result[3] = 0.3333333333333333;

                                                result[4] = 0.6666666666666666;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 1272) {
                                    result[1] = 0.4;

                                    result[3] = 0.6;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[8] <= -186) {
                                if (features[1] <= -609) {
                                    result[0] = 0.9;

                                    result[1] = 0.1;

                                    return 255;
                                } else {
                                    if (features[8] <= -468) {
                                        return 3;
                                    } else {
                                        if (features[3] <= -98) {
                                            result[0] = 0.2857142857142857;

                                            result[2] = 0.42857142857142855;

                                            result[3] = 0.2857142857142857;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 248) {
                                    if (features[5] <= 62) {
                                        if (features[7] <= 57) {
                                            result[1] = 0.09090909090909091;

                                            result[3] = 0.9090909090909091;

                                            return 255;
                                        } else {
                                            result[0] = 0.8571428571428571;

                                            result[1] = 0.14285714285714285;

                                            return 255;

                                        }
                                    } else {
                                        if (features[1] <= -18) {
                                            if (features[7] <= 48) {
                                                if (features[6] <= 120) {
                                                    result[3] = 0.2857142857142857;

                                                    result[4] = 0.7142857142857143;

                                                    return 255;
                                                } else {
                                                    if (features[5] <= 114) {
                                                        result[3] = 0.8;

                                                        result[4] = 0.2;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }

                                                }
                                            } else {
                                                result[0] = 0.1;

                                                result[4] = 0.9;

                                                return 255;

                                            }
                                        } else {
                                            if (features[1] <= 66) {
                                                return 4;
                                            } else {
                                                result[1] = 0.2857142857142857;

                                                result[4] = 0.7142857142857143;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[4] <= 81) {
                                        if (features[5] <= 246) {
                                            if (features[0] <= 81) {
                                                result[0] = 0.4;

                                                result[3] = 0.4;

                                                result[4] = 0.2;

                                                return 255;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[1] <= 171) {
                    if (features[4] <= 38) {
                        if (features[8] <= 44) {
                            if (features[1] <= -20) {
                                if (features[4] <= -1) {
                                    if (features[3] <= -18) {
                                        if (features[8] <= 32) {
                                            return 4;
                                        } else {
                                            result[0] = 0.14285714285714285;

                                            result[1] = 0.14285714285714285;

                                            result[4] = 0.7142857142857143;

                                            return 255;

                                        }
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.125;

                                        result[3] = 0.125;

                                        result[4] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    if (features[7] <= 77) {
                                        if (features[6] <= 197) {
                                            result[0] = 0.1111111111111111;

                                            result[3] = 0.3333333333333333;

                                            result[4] = 0.5555555555555556;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[4] <= -110) {
                                    if (features[9] <= -176) {
                                        result[1] = 0.8333333333333334;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[5] <= -206) {
                                        if (features[9] <= 170) {
                                            result[1] = 0.2;

                                            result[2] = 0.2;

                                            result[3] = 0.6;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[6] <= 6) {
                                            if (features[7] <= -29) {
                                                result[0] = 0.4166666666666667;

                                                result[1] = 0.25;

                                                result[3] = 0.08333333333333333;

                                                result[4] = 0.25;

                                                return 255;
                                            } else {
                                                if (features[0] <= -90) {
                                                    result[0] = 0.2;

                                                    result[3] = 0.4;

                                                    result[4] = 0.4;

                                                    return 255;
                                                } else {
                                                    if (features[7] <= 60) {
                                                        result[1] = 0.03225806451612903;

                                                        result[3] = 0.967741935483871;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.058823529411764705;

                                                        result[1] = 0.058823529411764705;

                                                        result[2] = 0.17647058823529413;

                                                        result[3] = 0.7058823529411765;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[1] <= 22) {
                                                if (features[8] <= 2) {
                                                    result[2] = 0.42857142857142855;

                                                    result[3] = 0.2857142857142857;

                                                    result[4] = 0.2857142857142857;

                                                    return 255;
                                                } else {
                                                    if (features[4] <= 14) {
                                                        return 4;
                                                    } else {
                                                        result[3] = 0.3333333333333333;

                                                        result[4] = 0.6666666666666666;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                if (features[9] <= 70) {
                                                    if (features[1] <= 50) {
                                                        result[1] = 0.8333333333333334;

                                                        result[3] = 0.16666666666666666;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.45454545454545453;

                                                        result[4] = 0.5454545454545454;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 74) {
                                if (features[3] <= 244) {
                                    if (features[0] <= 26) {
                                        if (features[3] <= -6) {
                                            if (features[2] <= 34) {
                                                if (features[1] <= -16) {
                                                    if (features[9] <= 118) {
                                                        result[1] = 0.03225806451612903;

                                                        result[2] = 0.14516129032258066;

                                                        result[3] = 0.16129032258064516;

                                                        result[4] = 0.6612903225806451;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.11764705882352941;

                                                        result[2] = 0.8529411764705882;

                                                        result[4] = 0.029411764705882353;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[5] <= 97) {
                                                        result[2] = 0.9896907216494846;

                                                        result[3] = 0.010309278350515464;

                                                        return 255;
                                                    } else {
                                                        result[2] = 0.5714285714285714;

                                                        result[4] = 0.42857142857142855;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                result[1] = 0.5555555555555556;

                                                result[3] = 0.4444444444444444;

                                                return 255;

                                            }
                                        } else {
                                            if (features[1] <= 24) {
                                                if (features[8] <= 120) {
                                                    if (features[5] <= 125) {
                                                        result[0] = 0.03225806451612903;

                                                        result[3] = 0.967741935483871;

                                                        return 255;
                                                    } else {
                                                        result[3] = 0.3333333333333333;

                                                        result[4] = 0.6666666666666666;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[8] <= 280) {
                                                        result[2] = 0.3333333333333333;

                                                        result[3] = 0.6666666666666666;

                                                        return 255;
                                                    } else {
                                                        return 2;

                                                    }

                                                }
                                            } else {
                                                if (features[6] <= 76) {
                                                    result[2] = 0.6;

                                                    result[4] = 0.4;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[6] <= 118) {
                                            if (features[6] <= -105) {
                                                result[0] = 0.2;

                                                result[2] = 0.4;

                                                result[3] = 0.4;

                                                return 255;
                                            } else {
                                                if (features[2] <= 36) {
                                                    return 2;
                                                } else {
                                                    result[2] = 0.8;

                                                    result[4] = 0.2;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            result[0] = 0.8333333333333334;

                                            result[2] = 0.16666666666666666;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= -271) {
                                        result[0] = 0.7692307692307693;

                                        result[2] = 0.23076923076923078;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[5] <= 75) {
                                    if (features[6] <= -167) {
                                        result[2] = 0.8;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        if (features[3] <= -82) {
                                            return 1;
                                        } else {
                                            result[1] = 0.8;

                                            result[2] = 0.2;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[4] <= -40) {
                                        result[0] = 0.75;

                                        result[1] = 0.25;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 84) {
                            if (features[5] <= -578) {
                                return 2;
                            } else {
                                if (features[4] <= 166) {
                                    if (features[3] <= 66) {
                                        if (features[9] <= 78) {
                                            if (features[0] <= -88) {
                                                result[0] = 0.5;

                                                result[4] = 0.5;

                                                return 255;
                                            } else {
                                                if (features[9] <= -44) {
                                                    if (features[8] <= -4) {
                                                        result[1] = 0.2222222222222222;

                                                        result[3] = 0.7777777777777778;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }
                                                } else {
                                                    if (features[7] <= 56) {
                                                        result[0] = 0.7;

                                                        result[3] = 0.1;

                                                        result[4] = 0.2;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[9] <= 122) {
                                                if (features[2] <= -34) {
                                                    return 2;
                                                } else {
                                                    if (features[2] <= 4) {
                                                        return 3;
                                                    } else {
                                                        result[2] = 0.625;

                                                        result[3] = 0.375;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }
                                    } else {
                                        if (features[3] <= 188) {
                                            if (features[3] <= 167) {
                                                if (features[8] <= 113) {
                                                    if (features[1] <= 78) {
                                                        return 0;
                                                    } else {
                                                        result[0] = 0.5;

                                                        result[3] = 0.5;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[2] = 0.8333333333333334;

                                                    result[3] = 0.16666666666666666;

                                                    return 255;

                                                }
                                            } else {
                                                result[1] = 0.6666666666666666;

                                                result[2] = 0.3333333333333333;

                                                return 255;

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[3] <= 1) {
                                        if (features[9] <= 196) {
                                            if (features[7] <= -6) {
                                                return 0;
                                            } else {
                                                result[0] = 0.5;

                                                result[3] = 0.5;

                                                return 255;

                                            }
                                        } else {
                                            result[0] = 0.2;

                                            result[2] = 0.8;

                                            return 255;

                                        }
                                    } else {
                                        return 0;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 78) {
                                if (features[0] <= 38) {
                                    if (features[3] <= 98) {
                                        result[1] = 0.25;

                                        result[3] = 0.5;

                                        result[4] = 0.25;

                                        return 255;
                                    } else {
                                        if (features[1] <= -652) {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[6] <= 92) {
                                                result[0] = 0.4;

                                                result[1] = 0.6;

                                                return 255;
                                            } else {
                                                return 1;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[2] <= 18) {
                                        return 0;
                                    } else {
                                        if (features[4] <= 86) {
                                            result[0] = 0.1;

                                            result[1] = 0.9;

                                            return 255;
                                        } else {
                                            if (features[5] <= 100) {
                                                result[2] = 0.1;

                                                result[3] = 0.9;

                                                return 255;
                                            } else {
                                                result[0] = 0.2857142857142857;

                                                result[1] = 0.42857142857142855;

                                                result[3] = 0.2857142857142857;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[0] <= 2) {
                                    if (features[0] <= -314) {
                                        return 0;
                                    } else {
                                        if (features[1] <= -607) {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[8] <= 230) {
                                                return 1;
                                            } else {
                                                result[0] = 0.3333333333333333;

                                                result[1] = 0.6666666666666666;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[1] <= 62) {
                                        if (features[4] <= 62) {
                                            result[0] = 0.8333333333333334;

                                            result[2] = 0.16666666666666666;

                                            return 255;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[3] <= 36) {
                                            return 1;
                                        } else {
                                            result[1] = 0.4;

                                            result[2] = 0.6;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= 130) {
                        if (features[1] <= 426) {
                            if (features[6] <= -264) {
                                result[1] = 0.1111111111111111;

                                result[2] = 0.8888888888888888;

                                return 255;
                            } else {
                                if (features[3] <= -294) {
                                    result[0] = 0.625;

                                    result[1] = 0.375;

                                    return 255;
                                } else {
                                    if (features[7] <= -14) {
                                        result[1] = 0.5555555555555556;

                                        result[3] = 0.4444444444444444;

                                        return 255;
                                    } else {
                                        if (features[1] <= 199) {
                                            result[1] = 0.8;

                                            result[3] = 0.2;

                                            return 255;
                                        } else {
                                            return 1;

                                        }

                                    }

                                }

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[9] <= 52) {
                            return 0;
                        } else {
                            if (features[6] <= 328) {
                                if (features[7] <= 270) {
                                    return 1;
                                } else {
                                    result[0] = 0.8571428571428571;

                                    result[1] = 0.14285714285714285;

                                    return 255;

                                }
                            } else {
                                if (features[9] <= 68) {
                                    result[0] = 0.8571428571428571;

                                    result[1] = 0.14285714285714285;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[9] <= -148) {
            if (features[4] <= -246) {
                result[3] = 0.25;

                result[4] = 0.75;

                return 255;
            } else {
                if (features[2] <= 12) {
                    if (features[5] <= 437) {
                        if (features[3] <= -4) {
                            result[3] = 0.75;

                            result[4] = 0.25;

                            return 255;
                        } else {
                            return 3;

                        }
                    } else {
                        return 3;

                    }
                } else {
                    if (features[6] <= 346) {
                        return 3;
                    } else {
                        if (features[8] <= -531) {
                            return 3;
                        } else {
                            if (features[0] <= 34) {
                                result[3] = 0.6666666666666666;

                                result[4] = 0.3333333333333333;

                                return 255;
                            } else {
                                return 4;

                            }

                        }

                    }

                }

            }
        } else {
            if (features[8] <= -156) {
                if (features[1] <= 8) {
                    if (features[7] <= 80) {
                        if (features[4] <= -8) {
                            result[3] = 0.3333333333333333;

                            result[4] = 0.6666666666666666;

                            return 255;
                        } else {
                            if (features[3] <= 58) {
                                return 3;
                            } else {
                                result[3] = 0.7142857142857143;

                                result[4] = 0.2857142857142857;

                                return 255;

                            }

                        }
                    } else {
                        return 4;

                    }
                } else {
                    return 4;

                }
            } else {
                if (features[0] <= 178) {
                    if (features[2] <= 150) {
                        if (features[3] <= 81) {
                            return 4;
                        } else {
                            if (features[3] <= 96) {
                                result[0] = 0.4;

                                result[4] = 0.6;

                                return 255;
                            } else {
                                if (features[0] <= 13) {
                                    result[0] = 0.2;

                                    result[4] = 0.8;

                                    return 255;
                                } else {
                                    return 4;

                                }

                            }

                        }
                    } else {
                        if (features[1] <= -86) {
                            result[0] = 0.09090909090909091;

                            result[1] = 0.9090909090909091;

                            return 255;
                        } else {
                            return 4;

                        }

                    }
                } else {
                    if (features[8] <= -2) {
                        return 0;
                    } else {
                        result[0] = 0.8;

                        result[1] = 0.2;

                        return 255;

                    }

                }

            }

        }

    }
}

unsigned char tree3(short* features, float* result){
    if (features[5] <= 271) {
        if (features[0] <= -98) {
            if (features[6] <= 303) {
                if (features[4] <= 212) {
                    if (features[9] <= 68) {
                        if (features[5] <= -66) {
                            if (features[1] <= 36) {
                                if (features[3] <= 232) {
                                    if (features[9] <= -14) {
                                        if (features[3] <= 2) {
                                            if (features[1] <= -90) {
                                                if (features[9] <= -184) {
                                                    result[0] = 0.16666666666666666;

                                                    result[4] = 0.8333333333333334;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                result[3] = 0.5;

                                                result[4] = 0.5;

                                                return 255;

                                            }
                                        } else {
                                            if (features[3] <= 132) {
                                                if (features[6] <= -154) {
                                                    result[0] = 0.5;

                                                    result[2] = 0.3333333333333333;

                                                    result[4] = 0.16666666666666666;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.6;

                                                    result[2] = 0.4;

                                                    return 255;

                                                }
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[1] <= -160) {
                                            result[0] = 0.42857142857142855;

                                            result[3] = 0.14285714285714285;

                                            result[4] = 0.42857142857142855;

                                            return 255;
                                        } else {
                                            result[0] = 0.875;

                                            result[2] = 0.125;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[9] <= -109) {
                                        if (features[3] <= 786) {
                                            if (features[1] <= -816) {
                                                result[0] = 0.2;

                                                result[4] = 0.8;

                                                return 255;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                if (features[1] <= 494) {
                                    result[1] = 0.375;

                                    result[2] = 0.375;

                                    result[4] = 0.25;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[3] <= 111) {
                                if (features[4] <= 120) {
                                    if (features[5] <= 48) {
                                        if (features[8] <= 24) {
                                            if (features[9] <= -316) {
                                                result[2] = 0.25;

                                                result[4] = 0.75;

                                                return 255;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            result[1] = 0.2857142857142857;

                                            result[4] = 0.7142857142857143;

                                            return 255;

                                        }
                                    } else {
                                        result[1] = 0.16666666666666666;

                                        result[3] = 0.16666666666666666;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    result[0] = 0.5;

                                    result[3] = 0.125;

                                    result[4] = 0.375;

                                    return 255;

                                }
                            } else {
                                if (features[6] <= 9) {
                                    if (features[8] <= -40) {
                                        if (features[0] <= -645) {
                                            result[0] = 0.25;

                                            result[4] = 0.75;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        result[0] = 0.8333333333333334;

                                        result[4] = 0.16666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 140) {
                                        result[0] = 0.42857142857142855;

                                        result[1] = 0.5714285714285714;

                                        return 255;
                                    } else {
                                        result[0] = 0.8571428571428571;

                                        result[1] = 0.14285714285714285;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 270) {
                            if (features[4] <= 84) {
                                if (features[3] <= 2) {
                                    return 2;
                                } else {
                                    result[2] = 0.8333333333333334;

                                    result[3] = 0.16666666666666666;

                                    return 255;

                                }
                            } else {
                                result[0] = 0.4444444444444444;

                                result[2] = 0.5555555555555556;

                                return 255;

                            }
                        } else {
                            return 0;

                        }

                    }
                } else {
                    if (features[8] <= -159) {
                        if (features[9] <= -168) {
                            if (features[7] <= -39) {
                                result[0] = 0.6666666666666666;

                                result[4] = 0.3333333333333333;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[0] <= -256) {
                            return 0;
                        } else {
                            if (features[2] <= 103) {
                                if (features[2] <= 3) {
                                    if (features[9] <= 32) {
                                        return 0;
                                    } else {
                                        result[0] = 0.75;

                                        result[2] = 0.25;

                                        return 255;

                                    }
                                } else {
                                    result[0] = 0.8;

                                    result[3] = 0.2;

                                    return 255;

                                }
                            } else {
                                result[0] = 0.7142857142857143;

                                result[1] = 0.2857142857142857;

                                return 255;

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 770) {
                    if (features[8] <= -78) {
                        result[1] = 0.2;

                        result[3] = 0.8;

                        return 255;
                    } else {
                        if (features[6] <= 329) {
                            return 1;
                        } else {
                            if (features[0] <= -184) {
                                result[0] = 0.5;

                                result[1] = 0.5;

                                return 255;
                            } else {
                                return 1;

                            }

                        }

                    }
                } else {
                    if (features[7] <= -346) {
                        result[1] = 0.3333333333333333;

                        result[3] = 0.6666666666666666;

                        return 255;
                    } else {
                        return 3;

                    }

                }

            }
        } else {
            if (features[8] <= 140) {
                if (features[0] <= 50) {
                    if (features[8] <= -50) {
                        if (features[4] <= -0) {
                            if (features[9] <= -35) {
                                if (features[2] <= 8) {
                                    if (features[5] <= -5) {
                                        result[1] = 0.875;

                                        result[2] = 0.125;

                                        return 255;
                                    } else {
                                        if (features[9] <= -182) {
                                            result[2] = 0.6;

                                            result[3] = 0.4;

                                            return 255;
                                        } else {
                                            result[2] = 0.5;

                                            result[3] = 0.5;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= -22) {
                                        return 3;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.16666666666666666;

                                        result[3] = 0.5;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[0] <= 18) {
                                    if (features[1] <= 10) {
                                        if (features[8] <= -90) {
                                            result[3] = 0.14285714285714285;

                                            result[4] = 0.8571428571428571;

                                            return 255;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[2] = 0.16666666666666666;

                                        result[4] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    result[3] = 0.6666666666666666;

                                    result[4] = 0.3333333333333333;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[5] <= 2) {
                                if (features[3] <= 1370) {
                                    if (features[0] <= 1) {
                                        if (features[8] <= -864) {
                                            return 3;
                                        } else {
                                            if (features[1] <= 0) {
                                                result[0] = 0.75;

                                                result[3] = 0.25;

                                                return 255;
                                            } else {
                                                result[2] = 0.125;

                                                result[3] = 0.875;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        result[0] = 0.5;

                                        result[1] = 0.4166666666666667;

                                        result[2] = 0.08333333333333333;

                                        return 255;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[6] <= 354) {
                                    if (features[9] <= -96) {
                                        if (features[9] <= -259) {
                                            result[2] = 0.16666666666666666;

                                            result[3] = 0.8333333333333334;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[6] <= 94) {
                                            result[3] = 0.2857142857142857;

                                            result[4] = 0.7142857142857143;

                                            return 255;
                                        } else {
                                            if (features[5] <= 164) {
                                                if (features[3] <= -20) {
                                                    result[3] = 0.6666666666666666;

                                                    result[4] = 0.3333333333333333;

                                                    return 255;
                                                } else {
                                                    if (features[4] <= 14) {
                                                        result[3] = 0.8888888888888888;

                                                        result[4] = 0.1111111111111111;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }

                                                }
                                            } else {
                                                result[3] = 0.5;

                                                result[4] = 0.5;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[8] <= -163) {
                                        if (features[2] <= 64) {
                                            return 3;
                                        } else {
                                            if (features[7] <= -228) {
                                                return 3;
                                            } else {
                                                result[1] = 0.2;

                                                result[3] = 0.8;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        result[1] = 0.875;

                                        result[3] = 0.125;

                                        return 255;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 70) {
                            if (features[6] <= 8) {
                                if (features[9] <= 16) {
                                    if (features[3] <= -96) {
                                        return 1;
                                    } else {
                                        if (features[5] <= 8) {
                                            if (features[9] <= -2) {
                                                if (features[3] <= -12) {
                                                    result[2] = 0.25;

                                                    result[3] = 0.75;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                if (features[1] <= 4) {
                                                    if (features[1] <= -398) {
                                                        return 0;
                                                    } else {
                                                        result[0] = 0.16666666666666666;

                                                        result[2] = 0.3888888888888889;

                                                        result[3] = 0.4444444444444444;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[2] <= 24) {
                                                        result[1] = 0.7857142857142857;

                                                        result[2] = 0.21428571428571427;

                                                        return 255;
                                                    } else {
                                                        return 2;

                                                    }

                                                }

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 18) {
                                        if (features[9] <= 218) {
                                            if (features[3] <= 12) {
                                                if (features[0] <= 6) {
                                                    if (features[5] <= -38) {
                                                        result[2] = 0.6666666666666666;

                                                        result[3] = 0.3333333333333333;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.4;

                                                        result[4] = 0.6;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                if (features[1] <= -2) {
                                                    result[3] = 0.875;

                                                    result[4] = 0.125;

                                                    return 255;
                                                } else {
                                                    result[0] = 0.4444444444444444;

                                                    result[3] = 0.5555555555555556;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[8] <= 6) {
                                            result[1] = 0.2;

                                            result[2] = 0.6;

                                            result[4] = 0.2;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 50) {
                                    if (features[1] <= -18) {
                                        if (features[5] <= 42) {
                                            return 0;
                                        } else {
                                            result[0] = 0.3333333333333333;

                                            result[2] = 0.6666666666666666;

                                            return 255;

                                        }
                                    } else {
                                        if (features[7] <= 42) {
                                            if (features[0] <= 19) {
                                                if (features[5] <= 129) {
                                                    result[0] = 0.25;

                                                    result[1] = 0.5;

                                                    result[2] = 0.25;

                                                    return 255;
                                                } else {
                                                    if (features[6] <= 35) {
                                                        return 4;
                                                    } else {
                                                        result[2] = 0.3333333333333333;

                                                        result[4] = 0.6666666666666666;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                if (features[1] <= 26) {
                                                    result[1] = 0.45454545454545453;

                                                    result[2] = 0.09090909090909091;

                                                    result[4] = 0.45454545454545453;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            return 2;

                                        }

                                    }
                                } else {
                                    if (features[4] <= 26) {
                                        if (features[6] <= 168) {
                                            if (features[5] <= 110) {
                                                if (features[6] <= 120) {
                                                    if (features[6] <= 82) {
                                                        result[0] = 0.07142857142857142;

                                                        result[2] = 0.21428571428571427;

                                                        result[3] = 0.42857142857142855;

                                                        result[4] = 0.2857142857142857;

                                                        return 255;
                                                    } else {
                                                        result[2] = 0.9130434782608695;

                                                        result[3] = 0.08695652173913043;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                if (features[2] <= -61) {
                                                    result[1] = 0.25;

                                                    result[3] = 0.125;

                                                    result[4] = 0.625;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            if (features[3] <= -100) {
                                                result[0] = 0.1111111111111111;

                                                result[1] = 0.5555555555555556;

                                                result[4] = 0.3333333333333333;

                                                return 255;
                                            } else {
                                                if (features[7] <= 56) {
                                                    return 3;
                                                } else {
                                                    result[0] = 0.14285714285714285;

                                                    result[3] = 0.7142857142857143;

                                                    result[4] = 0.14285714285714285;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[2] <= 30) {
                                            if (features[5] <= 101) {
                                                return 3;
                                            } else {
                                                if (features[1] <= -33) {
                                                    result[3] = 0.8888888888888888;

                                                    result[4] = 0.1111111111111111;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            result[0] = 0.1;

                                            result[3] = 0.2;

                                            result[4] = 0.7;

                                            return 255;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 70) {
                                if (features[0] <= -36) {
                                    result[0] = 0.8333333333333334;

                                    result[1] = 0.16666666666666666;

                                    return 255;
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[1] <= -32) {
                                    if (features[4] <= 131) {
                                        if (features[2] <= -6) {
                                            result[0] = 0.6666666666666666;

                                            result[1] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[6] <= 382) {
                                            result[0] = 0.9;

                                            result[1] = 0.1;

                                            return 255;
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    result[0] = 0.5;

                                    result[3] = 0.16666666666666666;

                                    result[4] = 0.3333333333333333;

                                    return 255;

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= 352) {
                        if (features[9] <= 128) {
                            if (features[7] <= 12) {
                                if (features[6] <= 274) {
                                    if (features[0] <= 128) {
                                        if (features[8] <= -2) {
                                            if (features[9] <= -158) {
                                                result[1] = 0.7777777777777778;

                                                result[2] = 0.2222222222222222;

                                                return 255;
                                            } else {
                                                if (features[8] <= -66) {
                                                    result[0] = 0.875;

                                                    result[1] = 0.125;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            if (features[6] <= -58) {
                                                return 3;
                                            } else {
                                                if (features[6] <= 8) {
                                                    result[1] = 0.6;

                                                    result[3] = 0.4;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.75;

                                                    result[2] = 0.25;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[4] <= -19) {
                                            return 1;
                                        } else {
                                            result[1] = 0.5;

                                            result[2] = 0.16666666666666666;

                                            result[3] = 0.3333333333333333;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[8] <= -309) {
                                        return 3;
                                    } else {
                                        result[0] = 0.875;

                                        result[3] = 0.125;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= 70) {
                                    if (features[6] <= 218) {
                                        if (features[4] <= 63) {
                                            if (features[0] <= 58) {
                                                result[1] = 0.16666666666666666;

                                                result[2] = 0.8333333333333334;

                                                return 255;
                                            } else {
                                                if (features[7] <= 90) {
                                                    result[0] = 0.6;

                                                    result[2] = 0.4;

                                                    return 255;
                                                } else {
                                                    result[0] = 0.125;

                                                    result[1] = 0.125;

                                                    result[2] = 0.75;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[8] <= 76) {
                                                result[0] = 0.5;

                                                result[3] = 0.5;

                                                return 255;
                                            } else {
                                                return 0;

                                            }

                                        }
                                    } else {
                                        if (features[5] <= 114) {
                                            result[2] = 0.2222222222222222;

                                            result[3] = 0.7777777777777778;

                                            return 255;
                                        } else {
                                            result[1] = 0.5714285714285714;

                                            result[3] = 0.42857142857142855;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 88) {
                                        if (features[3] <= -34) {
                                            if (features[4] <= 48) {
                                                if (features[9] <= 63) {
                                                    result[0] = 0.7142857142857143;

                                                    result[2] = 0.2857142857142857;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            if (features[9] <= 89) {
                                                result[0] = 0.125;

                                                result[1] = 0.75;

                                                result[4] = 0.125;

                                                return 255;
                                            } else {
                                                return 1;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 71) {
                                            if (features[1] <= 146) {
                                                if (features[5] <= 84) {
                                                    result[0] = 0.8333333333333334;

                                                    result[2] = 0.16666666666666666;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[6] <= 335) {
                                                    if (features[4] <= -4) {
                                                        return 1;
                                                    } else {
                                                        result[0] = 0.5;

                                                        result[1] = 0.5;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[2] <= 104) {
                                                        return 0;
                                                    } else {
                                                        result[0] = 0.75;

                                                        result[3] = 0.25;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[4] <= 88) {
                                                if (features[5] <= 98) {
                                                    return 1;
                                                } else {
                                                    result[0] = 0.3333333333333333;

                                                    result[1] = 0.6666666666666666;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= 46) {
                                                    return 1;
                                                } else {
                                                    if (features[6] <= 122) {
                                                        result[0] = 0.5714285714285714;

                                                        result[2] = 0.14285714285714285;

                                                        result[3] = 0.2857142857142857;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }

                                                }

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 192) {
                                if (features[5] <= -328) {
                                    return 2;
                                } else {
                                    if (features[3] <= 14) {
                                        result[1] = 0.8;

                                        result[2] = 0.2;

                                        return 255;
                                    } else {
                                        result[2] = 0.8333333333333334;

                                        result[3] = 0.16666666666666666;

                                        return 255;

                                    }

                                }
                            } else {
                                result[1] = 0.5;

                                result[2] = 0.5;

                                return 255;

                            }

                        }
                    } else {
                        return 1;

                    }

                }
            } else {
                if (features[2] <= -251) {
                    if (features[3] <= -226) {
                        return 1;
                    } else {
                        result[0] = 0.875;

                        result[2] = 0.125;

                        return 255;

                    }
                } else {
                    if (features[6] <= 106) {
                        if (features[5] <= -292) {
                            if (features[5] <= -428) {
                                return 2;
                            } else {
                                if (features[9] <= 152) {
                                    result[1] = 0.25;

                                    result[2] = 0.75;

                                    return 255;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[8] <= 708) {
                                if (features[3] <= -332) {
                                    if (features[1] <= -24) {
                                        return 2;
                                    } else {
                                        if (features[7] <= 48) {
                                            return 1;
                                        } else {
                                            if (features[5] <= -0) {
                                                result[1] = 0.8;

                                                result[2] = 0.2;

                                                return 255;
                                            } else {
                                                return 1;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[2] <= 246) {
                                        if (features[1] <= -447) {
                                            if (features[8] <= 316) {
                                                return 0;
                                            } else {
                                                result[0] = 0.8333333333333334;

                                                result[2] = 0.16666666666666666;

                                                return 255;

                                            }
                                        } else {
                                            if (features[9] <= 66) {
                                                if (features[2] <= -36) {
                                                    result[0] = 0.7777777777777778;

                                                    result[2] = 0.2222222222222222;

                                                    return 255;
                                                } else {
                                                    if (features[4] <= -10) {
                                                        result[1] = 0.18181818181818182;

                                                        result[3] = 0.8181818181818182;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.05555555555555555;

                                                        result[1] = 0.2777777777777778;

                                                        result[2] = 0.6666666666666666;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                if (features[5] <= -100) {
                                                    if (features[6] <= -214) {
                                                        return 2;
                                                    } else {
                                                        result[0] = 0.5555555555555556;

                                                        result[2] = 0.2222222222222222;

                                                        result[3] = 0.2222222222222222;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 2;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[2] <= 1512) {
                                            return 0;
                                        } else {
                                            result[0] = 0.375;

                                            result[2] = 0.625;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[1] <= 1334) {
                                    if (features[1] <= -162) {
                                        result[0] = 0.2;

                                        result[2] = 0.8;

                                        return 255;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[4] <= -110) {
                            return 1;
                        } else {
                            if (features[6] <= 389) {
                                if (features[1] <= -215) {
                                    return 0;
                                } else {
                                    if (features[7] <= 108) {
                                        return 1;
                                    } else {
                                        if (features[2] <= -98) {
                                            result[0] = 0.75;

                                            result[1] = 0.25;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                result[0] = 0.36363636363636365;

                                result[1] = 0.6363636363636364;

                                return 255;

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[9] <= -140) {
            if (features[6] <= 364) {
                return 3;
            } else {
                if (features[1] <= 26) {
                    if (features[7] <= 76) {
                        if (features[4] <= 240) {
                            return 3;
                        } else {
                            if (features[8] <= -2406) {
                                return 3;
                            } else {
                                result[3] = 0.75;

                                result[4] = 0.25;

                                return 255;

                            }

                        }
                    } else {
                        if (features[3] <= -78) {
                            return 4;
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[6] <= 657) {
                        return 4;
                    } else {
                        result[3] = 0.8;

                        result[4] = 0.2;

                        return 255;

                    }

                }

            }
        } else {
            if (features[8] <= -158) {
                if (features[5] <= 548) {
                    if (features[7] <= 80) {
                        if (features[1] <= -72) {
                            return 3;
                        } else {
                            result[3] = 0.7142857142857143;

                            result[4] = 0.2857142857142857;

                            return 255;

                        }
                    } else {
                        result[3] = 0.18181818181818182;

                        result[4] = 0.8181818181818182;

                        return 255;

                    }
                } else {
                    return 4;

                }
            } else {
                if (features[0] <= -126) {
                    if (features[5] <= 365) {
                        return 1;
                    } else {
                        if (features[1] <= -900) {
                            return 0;
                        } else {
                            result[0] = 0.2857142857142857;

                            result[4] = 0.7142857142857143;

                            return 255;

                        }

                    }
                } else {
                    if (features[1] <= 393) {
                        if (features[5] <= 742) {
                            return 4;
                        } else {
                            result[3] = 0.2857142857142857;

                            result[4] = 0.7142857142857143;

                            return 255;

                        }
                    } else {
                        return 0;

                    }

                }

            }

        }

    }
}

unsigned char tree4(short* features, float* result){
    if (features[5] <= 124) {
        if (features[4] <= 140) {
            if (features[3] <= -536) {
                if (features[5] <= -673) {
                    return 2;
                } else {
                    if (features[9] <= 76) {
                        if (features[5] <= -0) {
                            return 1;
                        } else {
                            if (features[8] <= 985) {
                                return 1;
                            } else {
                                result[1] = 0.75;

                                result[2] = 0.25;

                                return 255;

                            }

                        }
                    } else {
                        if (features[6] <= -8) {
                            return 1;
                        } else {
                            result[0] = 0.6;

                            result[1] = 0.4;

                            return 255;

                        }

                    }

                }
            } else {
                if (features[4] <= -254) {
                    if (features[2] <= 45) {
                        if (features[5] <= -216) {
                            if (features[8] <= 68) {
                                return 1;
                            } else {
                                result[1] = 0.8333333333333334;

                                result[2] = 0.16666666666666666;

                                return 255;

                            }
                        } else {
                            if (features[1] <= -30) {
                                if (features[6] <= 43) {
                                    return 4;
                                } else {
                                    result[0] = 0.8333333333333334;

                                    result[4] = 0.16666666666666666;

                                    return 255;

                                }
                            } else {
                                if (features[2] <= -13) {
                                    result[0] = 0.16666666666666666;

                                    result[1] = 0.6666666666666666;

                                    result[2] = 0.16666666666666666;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        return 4;

                    }
                } else {
                    if (features[8] <= -2) {
                        if (features[5] <= 30) {
                            if (features[1] <= -73) {
                                if (features[0] <= -86) {
                                    if (features[9] <= -206) {
                                        if (features[1] <= -476) {
                                            return 4;
                                        } else {
                                            result[0] = 0.75;

                                            result[3] = 0.25;

                                            return 255;

                                        }
                                    } else {
                                        if (features[9] <= -54) {
                                            if (features[0] <= -216) {
                                                return 4;
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            if (features[2] <= -6) {
                                                return 4;
                                            } else {
                                                if (features[8] <= -112) {
                                                    result[0] = 0.25;

                                                    result[3] = 0.25;

                                                    result[4] = 0.5;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[1] <= -515) {
                                        return 0;
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[8] <= -434) {
                                    return 3;
                                } else {
                                    if (features[5] <= -81) {
                                        if (features[3] <= -46) {
                                            result[0] = 0.3076923076923077;

                                            result[1] = 0.6153846153846154;

                                            result[3] = 0.07692307692307693;

                                            return 255;
                                        } else {
                                            if (features[0] <= 86) {
                                                if (features[1] <= 5) {
                                                    return 2;
                                                } else {
                                                    if (features[2] <= 5) {
                                                        result[2] = 0.2222222222222222;

                                                        result[3] = 0.7777777777777778;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.1111111111111111;

                                                        result[2] = 0.8888888888888888;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                if (features[4] <= 19) {
                                                    return 1;
                                                } else {
                                                    result[1] = 0.4666666666666667;

                                                    result[2] = 0.5333333333333333;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[0] <= -129) {
                                            return 4;
                                        } else {
                                            if (features[8] <= -228) {
                                                result[2] = 0.8888888888888888;

                                                result[4] = 0.1111111111111111;

                                                return 255;
                                            } else {
                                                if (features[5] <= -22) {
                                                    if (features[0] <= 100) {
                                                        result[1] = 0.7857142857142857;

                                                        result[2] = 0.14285714285714285;

                                                        result[3] = 0.07142857142857142;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.75;

                                                        result[1] = 0.25;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[3] <= 10) {
                                                        return 3;
                                                    } else {
                                                        result[0] = 0.14285714285714285;

                                                        result[1] = 0.42857142857142855;

                                                        result[3] = 0.42857142857142855;

                                                        return 255;

                                                    }

                                                }

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= -208) {
                                if (features[9] <= -142) {
                                    return 4;
                                } else {
                                    if (features[2] <= -84) {
                                        result[1] = 0.4;

                                        result[3] = 0.6;

                                        return 255;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[7] <= 26) {
                                    if (features[5] <= 54) {
                                        if (features[8] <= -15) {
                                            if (features[9] <= -155) {
                                                result[2] = 0.4;

                                                result[3] = 0.6;

                                                return 255;
                                            } else {
                                                result[2] = 0.6666666666666666;

                                                result[3] = 0.3333333333333333;

                                                return 255;

                                            }
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[4] <= -6) {
                                            result[1] = 0.2;

                                            result[3] = 0.8;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }
                                } else {
                                    if (features[6] <= 182) {
                                        return 4;
                                    } else {
                                        if (features[3] <= -152) {
                                            result[0] = 0.5;

                                            result[3] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[2] <= -38) {
                                                return 3;
                                            } else {
                                                result[3] = 0.7142857142857143;

                                                result[4] = 0.2857142857142857;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 6) {
                            if (features[9] <= 38) {
                                if (features[0] <= -31) {
                                    if (features[6] <= -546) {
                                        return 2;
                                    } else {
                                        if (features[3] <= 87) {
                                            if (features[2] <= -4) {
                                                if (features[1] <= -142) {
                                                    result[1] = 0.3333333333333333;

                                                    result[3] = 0.3333333333333333;

                                                    result[4] = 0.3333333333333333;

                                                    return 255;
                                                } else {
                                                    result[0] = 0.3333333333333333;

                                                    result[4] = 0.6666666666666666;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[2] <= 0) {
                                                    return 3;
                                                } else {
                                                    result[0] = 0.5;

                                                    result[3] = 0.5;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[8] <= 1180) {
                                        if (features[5] <= -33) {
                                            if (features[0] <= 110) {
                                                if (features[3] <= -114) {
                                                    return 1;
                                                } else {
                                                    if (features[2] <= 8) {
                                                        return 3;
                                                    } else {
                                                        result[0] = 0.4;

                                                        result[1] = 0.4;

                                                        result[3] = 0.2;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            if (features[2] <= -156) {
                                                if (features[3] <= 460) {
                                                    if (features[7] <= 1372) {
                                                        result[0] = 0.058823529411764705;

                                                        result[1] = 0.9411764705882353;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.6666666666666666;

                                                        result[3] = 0.3333333333333333;

                                                        return 255;

                                                    }
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[1] <= -456) {
                                                    return 0;
                                                } else {
                                                    if (features[7] <= 371) {
                                                        result[1] = 0.2631578947368421;

                                                        result[2] = 0.42105263157894735;

                                                        result[3] = 0.3157894736842105;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.03333333333333333;

                                                        result[2] = 0.9666666666666667;

                                                        return 255;

                                                    }

                                                }

                                            }

                                        }
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[9] <= 218) {
                                    if (features[8] <= 52) {
                                        if (features[2] <= 4) {
                                            return 3;
                                        } else {
                                            result[0] = 0.6666666666666666;

                                            result[1] = 0.1111111111111111;

                                            result[2] = 0.2222222222222222;

                                            return 255;

                                        }
                                    } else {
                                        if (features[7] <= 0) {
                                            if (features[3] <= -8) {
                                                if (features[5] <= -138) {
                                                    result[0] = 0.1111111111111111;

                                                    result[2] = 0.6666666666666666;

                                                    result[3] = 0.2222222222222222;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                if (features[7] <= -8) {
                                                    result[0] = 0.375;

                                                    result[2] = 0.625;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            if (features[5] <= -88) {
                                                if (features[4] <= -20) {
                                                    if (features[7] <= 50) {
                                                        result[0] = 0.25;

                                                        result[2] = 0.75;

                                                        return 255;
                                                    } else {
                                                        return 2;

                                                    }
                                                } else {
                                                    result[0] = 0.5;

                                                    result[2] = 0.5;

                                                    return 255;

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[8] <= 4) {
                                        result[1] = 0.25;

                                        result[2] = 0.75;

                                        return 255;
                                    } else {
                                        if (features[3] <= -186) {
                                            if (features[3] <= -217) {
                                                return 2;
                                            } else {
                                                result[2] = 0.75;

                                                result[4] = 0.25;

                                                return 255;

                                            }
                                        } else {
                                            return 2;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[0] <= 33) {
                                if (features[6] <= 96) {
                                    if (features[0] <= -57) {
                                        if (features[3] <= -2) {
                                            return 4;
                                        } else {
                                            if (features[4] <= 72) {
                                                return 0;
                                            } else {
                                                result[0] = 0.2857142857142857;

                                                result[1] = 0.2857142857142857;

                                                result[3] = 0.42857142857142855;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 38) {
                                            if (features[3] <= -2) {
                                                if (features[0] <= 19) {
                                                    if (features[2] <= -12) {
                                                        result[2] = 0.3333333333333333;

                                                        result[3] = 0.6666666666666666;

                                                        return 255;
                                                    } else {
                                                        return 2;

                                                    }
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                if (features[5] <= 84) {
                                                    if (features[7] <= 46) {
                                                        result[1] = 0.7142857142857143;

                                                        result[3] = 0.2857142857142857;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }
                                                } else {
                                                    result[2] = 0.6;

                                                    result[4] = 0.4;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[7] <= 60) {
                                                return 0;
                                            } else {
                                                if (features[0] <= 18) {
                                                    return 3;
                                                } else {
                                                    result[0] = 0.14285714285714285;

                                                    result[3] = 0.8571428571428571;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[4] <= 50) {
                                        if (features[6] <= 168) {
                                            if (features[1] <= -72) {
                                                result[0] = 0.5;

                                                result[4] = 0.5;

                                                return 255;
                                            } else {
                                                if (features[6] <= 120) {
                                                    if (features[7] <= 92) {
                                                        result[2] = 0.16666666666666666;

                                                        result[3] = 0.3333333333333333;

                                                        result[4] = 0.5;

                                                        return 255;
                                                    } else {
                                                        result[2] = 0.75;

                                                        result[4] = 0.25;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[0] <= 14) {
                                                        return 4;
                                                    } else {
                                                        result[3] = 0.4;

                                                        result[4] = 0.6;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[3] <= 242) {
                                                if (features[2] <= 184) {
                                                    result[0] = 0.2857142857142857;

                                                    result[1] = 0.2857142857142857;

                                                    result[3] = 0.42857142857142855;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                return 0;

                                            }

                                        }
                                    } else {
                                        if (features[8] <= 264) {
                                            if (features[1] <= -72) {
                                                return 1;
                                            } else {
                                                result[1] = 0.8;

                                                result[3] = 0.2;

                                                return 255;

                                            }
                                        } else {
                                            result[0] = 0.7142857142857143;

                                            result[1] = 0.2857142857142857;

                                            return 255;

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= -12) {
                                    if (features[9] <= 71) {
                                        if (features[1] <= 92) {
                                            result[0] = 0.16666666666666666;

                                            result[2] = 0.8333333333333334;

                                            return 255;
                                        } else {
                                            if (features[9] <= 62) {
                                                result[0] = 0.5;

                                                result[1] = 0.5;

                                                return 255;
                                            } else {
                                                result[0] = 0.6;

                                                result[1] = 0.4;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 43) {
                                            return 0;
                                        } else {
                                            result[0] = 0.2;

                                            result[1] = 0.8;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[3] <= 55) {
                                        if (features[7] <= 54) {
                                            if (features[2] <= 0) {
                                                if (features[3] <= -105) {
                                                    return 0;
                                                } else {
                                                    result[0] = 0.8;

                                                    result[2] = 0.2;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[8] <= 52) {
                                                    return 1;
                                                } else {
                                                    result[0] = 0.16666666666666666;

                                                    result[1] = 0.6666666666666666;

                                                    result[2] = 0.16666666666666666;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[4] <= 44) {
                                                if (features[9] <= 58) {
                                                    result[1] = 0.6;

                                                    result[2] = 0.4;

                                                    return 255;
                                                } else {
                                                    if (features[6] <= 98) {
                                                        return 2;
                                                    } else {
                                                        result[1] = 0.2;

                                                        result[2] = 0.8;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                if (features[8] <= 107) {
                                                    return 1;
                                                } else {
                                                    result[1] = 0.36363636363636365;

                                                    result[2] = 0.6363636363636364;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[1] <= 30) {
                                            if (features[8] <= 77) {
                                                result[0] = 0.5;

                                                result[1] = 0.5;

                                                return 255;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            if (features[8] <= 76) {
                                                if (features[0] <= 105) {
                                                    return 3;
                                                } else {
                                                    result[1] = 0.8333333333333334;

                                                    result[3] = 0.16666666666666666;

                                                    return 255;

                                                }
                                            } else {
                                                result[0] = 0.75;

                                                result[2] = 0.25;

                                                return 255;

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[1] <= -18) {
                if (features[8] <= -196) {
                    if (features[0] <= -680) {
                        result[0] = 0.8333333333333334;

                        result[4] = 0.16666666666666666;

                        return 255;
                    } else {
                        if (features[4] <= 251) {
                            return 4;
                        } else {
                            result[0] = 0.25;

                            result[3] = 0.25;

                            result[4] = 0.5;

                            return 255;

                        }

                    }
                } else {
                    if (features[4] <= 212) {
                        if (features[7] <= -48) {
                            result[0] = 0.4;

                            result[4] = 0.6;

                            return 255;
                        } else {
                            if (features[7] <= 70) {
                                return 0;
                            } else {
                                result[0] = 0.9090909090909091;

                                result[1] = 0.09090909090909091;

                                return 255;

                            }

                        }
                    } else {
                        return 0;

                    }

                }
            } else {
                if (features[5] <= -482) {
                    return 2;
                } else {
                    if (features[2] <= 125) {
                        if (features[0] <= -108) {
                            if (features[9] <= 217) {
                                return 0;
                            } else {
                                result[0] = 0.875;

                                result[2] = 0.125;

                                return 255;

                            }
                        } else {
                            if (features[9] <= 202) {
                                result[0] = 0.6666666666666666;

                                result[2] = 0.2222222222222222;

                                result[3] = 0.1111111111111111;

                                return 255;
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        result[2] = 0.6666666666666666;

                        result[3] = 0.3333333333333333;

                        return 255;

                    }

                }

            }

        }
    } else {
        if (features[8] <= 10) {
            if (features[0] <= 128) {
                if (features[3] <= 178) {
                    if (features[1] <= 14) {
                        if (features[4] <= 16) {
                            if (features[5] <= 160) {
                                if (features[9] <= -6) {
                                    return 3;
                                } else {
                                    if (features[4] <= 8) {
                                        return 4;
                                    } else {
                                        result[3] = 0.375;

                                        result[4] = 0.625;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[9] <= 128) {
                                    if (features[3] <= -22) {
                                        if (features[7] <= 46) {
                                            if (features[6] <= 352) {
                                                return 4;
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            if (features[8] <= -616) {
                                                result[3] = 0.75;

                                                result[4] = 0.25;

                                                return 255;
                                            } else {
                                                if (features[9] <= 6) {
                                                    return 4;
                                                } else {
                                                    result[3] = 0.5714285714285714;

                                                    result[4] = 0.42857142857142855;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[2] <= -8) {
                                            if (features[1] <= -70) {
                                                return 3;
                                            } else {
                                                result[3] = 0.8333333333333334;

                                                result[4] = 0.16666666666666666;

                                                return 255;

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[8] <= -63) {
                                return 3;
                            } else {
                                if (features[5] <= 212) {
                                    if (features[9] <= 3) {
                                        result[3] = 0.25;

                                        result[4] = 0.75;

                                        return 255;
                                    } else {
                                        result[3] = 0.8181818181818182;

                                        result[4] = 0.18181818181818182;

                                        return 255;

                                    }
                                } else {
                                    return 3;

                                }

                            }

                        }
                    } else {
                        if (features[9] <= -340) {
                            return 3;
                        } else {
                            if (features[7] <= 36) {
                                if (features[0] <= 10) {
                                    result[2] = 0.6;

                                    result[4] = 0.4;

                                    return 255;
                                } else {
                                    if (features[1] <= 72) {
                                        result[3] = 0.625;

                                        result[4] = 0.375;

                                        return 255;
                                    } else {
                                        result[3] = 0.125;

                                        result[4] = 0.875;

                                        return 255;

                                    }

                                }
                            } else {
                                return 4;

                            }

                        }

                    }
                } else {
                    if (features[1] <= 16) {
                        if (features[7] <= -38) {
                            if (features[8] <= -504) {
                                return 3;
                            } else {
                                result[0] = 0.25;

                                result[3] = 0.75;

                                return 255;

                            }
                        } else {
                            if (features[2] <= 67) {
                                if (features[7] <= 62) {
                                    return 3;
                                } else {
                                    result[1] = 0.4;

                                    result[3] = 0.6;

                                    return 255;

                                }
                            } else {
                                if (features[9] <= 70) {
                                    result[1] = 0.75;

                                    result[4] = 0.25;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 657) {
                            return 4;
                        } else {
                            result[3] = 0.7142857142857143;

                            result[4] = 0.2857142857142857;

                            return 255;

                        }

                    }

                }
            } else {
                if (features[1] <= 410) {
                    if (features[1] <= 220) {
                        return 3;
                    } else {
                        result[0] = 0.3333333333333333;

                        result[3] = 0.6666666666666666;

                        return 255;

                    }
                } else {
                    if (features[6] <= 455) {
                        result[0] = 0.7142857142857143;

                        result[1] = 0.2857142857142857;

                        return 255;
                    } else {
                        if (features[3] <= -144) {
                            return 0;
                        } else {
                            result[0] = 0.8;

                            result[3] = 0.2;

                            return 255;

                        }

                    }

                }

            }
        } else {
            if (features[0] <= 81) {
                if (features[4] <= 40) {
                    if (features[0] <= 35) {
                        if (features[7] <= 112) {
                            return 4;
                        } else {
                            if (features[2] <= 32) {
                                return 4;
                            } else {
                                if (features[3] <= 24) {
                                    return 4;
                                } else {
                                    result[3] = 0.6;

                                    result[4] = 0.4;

                                    return 255;

                                }

                            }

                        }
                    } else {
                        result[2] = 0.6;

                        result[4] = 0.4;

                        return 255;

                    }
                } else {
                    if (features[0] <= 15) {
                        if (features[0] <= -218) {
                            return 0;
                        } else {
                            if (features[6] <= 126) {
                                if (features[8] <= 68) {
                                    return 1;
                                } else {
                                    result[0] = 0.625;

                                    result[1] = 0.375;

                                    return 255;

                                }
                            } else {
                                if (features[1] <= -78) {
                                    return 1;
                                } else {
                                    result[1] = 0.8;

                                    result[4] = 0.2;

                                    return 255;

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 108) {
                            if (features[0] <= 64) {
                                return 4;
                            } else {
                                result[0] = 0.25;

                                result[4] = 0.75;

                                return 255;

                            }
                        } else {
                            if (features[1] <= -108) {
                                result[0] = 0.25;

                                result[1] = 0.75;

                                return 255;
                            } else {
                                result[1] = 0.2857142857142857;

                                result[4] = 0.7142857142857143;

                                return 255;

                            }

                        }

                    }

                }
            } else {
                if (features[7] <= 202) {
                    if (features[2] <= -1) {
                        if (features[1] <= 566) {
                            return 0;
                        } else {
                            result[0] = 0.3333333333333333;

                            result[1] = 0.6666666666666666;

                            return 255;

                        }
                    } else {
                        if (features[0] <= 112) {
                            result[0] = 0.6666666666666666;

                            result[4] = 0.3333333333333333;

                            return 255;
                        } else {
                            if (features[4] <= 100) {
                                if (features[7] <= 72) {
                                    return 1;
                                } else {
                                    result[0] = 0.25;

                                    result[1] = 0.75;

                                    return 255;

                                }
                            } else {
                                result[1] = 0.5555555555555556;

                                result[3] = 0.4444444444444444;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[4] <= 66) {
                        if (features[9] <= 88) {
                            return 0;
                        } else {
                            result[0] = 0.8333333333333334;

                            result[1] = 0.16666666666666666;

                            return 255;

                        }
                    } else {
                        result[0] = 0.5;

                        result[4] = 0.5;

                        return 255;

                    }

                }

            }

        }

    }
}

unsigned char tree5(short* features, float* result){
    if (features[0] <= -328) {
        if (features[8] <= -38) {
            if (features[5] <= -276) {
                return 0;
            } else {
                if (features[1] <= -1851) {
                    return 0;
                } else {
                    if (features[2] <= -16) {
                        return 4;
                    } else {
                        if (features[2] <= 32) {
                            result[0] = 0.25;

                            result[4] = 0.75;

                            return 255;
                        } else {
                            return 4;

                        }

                    }

                }

            }
        } else {
            if (features[9] <= 68) {
                if (features[2] <= -52) {
                    if (features[4] <= 94) {
                        if (features[9] <= -26) {
                            result[1] = 0.4;

                            result[4] = 0.6;

                            return 255;
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[4] <= 637) {
                            result[0] = 0.8;

                            result[4] = 0.2;

                            return 255;
                        } else {
                            return 0;

                        }

                    }
                } else {
                    if (features[3] <= -14) {
                        return 4;
                    } else {
                        return 0;

                    }

                }
            } else {
                if (features[0] <= -382) {
                    return 0;
                } else {
                    result[0] = 0.7333333333333333;

                    result[2] = 0.26666666666666666;

                    return 255;

                }

            }

        }
    } else {
        if (features[8] <= 10) {
            if (features[6] <= 32) {
                if (features[1] <= -20) {
                    if (features[1] <= -638) {
                        return 0;
                    } else {
                        if (features[0] <= -62) {
                            if (features[5] <= -70) {
                                if (features[1] <= -302) {
                                    result[0] = 0.4;

                                    result[4] = 0.6;

                                    return 255;
                                } else {
                                    if (features[8] <= -86) {
                                        result[0] = 0.7;

                                        result[1] = 0.3;

                                        return 255;
                                    } else {
                                        result[0] = 0.14285714285714285;

                                        result[1] = 0.7142857142857143;

                                        result[3] = 0.14285714285714285;

                                        return 255;

                                    }

                                }
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[6] <= -54) {
                                result[0] = 0.3333333333333333;

                                result[2] = 0.2222222222222222;

                                result[4] = 0.4444444444444444;

                                return 255;
                            } else {
                                result[1] = 0.8666666666666667;

                                result[3] = 0.13333333333333333;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[4] <= -126) {
                        if (features[7] <= -66) {
                            result[0] = 0.5;

                            result[1] = 0.5;

                            return 255;
                        } else {
                            if (features[0] <= 0) {
                                result[1] = 0.25;

                                result[3] = 0.75;

                                return 255;
                            } else {
                                return 1;

                            }

                        }
                    } else {
                        if (features[9] <= 0) {
                            if (features[1] <= 10) {
                                if (features[8] <= -0) {
                                    if (features[7] <= -2) {
                                        if (features[4] <= 208) {
                                            return 3;
                                        } else {
                                            result[0] = 0.4;

                                            result[3] = 0.6;

                                            return 255;

                                        }
                                    } else {
                                        if (features[8] <= -18) {
                                            if (features[7] <= 1) {
                                                result[2] = 0.42857142857142855;

                                                result[3] = 0.2857142857142857;

                                                result[4] = 0.2857142857142857;

                                                return 255;
                                            } else {
                                                result[0] = 0.08333333333333333;

                                                result[3] = 0.9166666666666666;

                                                return 255;

                                            }
                                        } else {
                                            if (features[9] <= -46) {
                                                return 3;
                                            } else {
                                                result[3] = 0.6;

                                                result[4] = 0.4;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[0] <= 2) {
                                        if (features[6] <= -1) {
                                            result[0] = 0.2;

                                            result[2] = 0.8;

                                            return 255;
                                        } else {
                                            result[0] = 0.15789473684210525;

                                            result[2] = 0.15789473684210525;

                                            result[3] = 0.6842105263157895;

                                            return 255;

                                        }
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[9] <= -374) {
                                    return 3;
                                } else {
                                    if (features[4] <= -50) {
                                        result[1] = 0.5;

                                        result[3] = 0.5;

                                        return 255;
                                    } else {
                                        if (features[1] <= 54) {
                                            result[1] = 0.5;

                                            result[2] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[9] <= -74) {
                                                result[1] = 0.8333333333333334;

                                                result[3] = 0.16666666666666666;

                                                return 255;
                                            } else {
                                                return 1;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= 210) {
                                if (features[5] <= -24) {
                                    if (features[3] <= 0) {
                                        result[0] = 0.8;

                                        result[3] = 0.2;

                                        return 255;
                                    } else {
                                        result[0] = 0.6666666666666666;

                                        result[2] = 0.3333333333333333;

                                        return 255;

                                    }
                                } else {
                                    if (features[3] <= 75) {
                                        return 4;
                                    } else {
                                        result[2] = 0.2;

                                        result[4] = 0.8;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[9] <= 336) {
                                    if (features[4] <= 54) {
                                        return 2;
                                    } else {
                                        result[0] = 0.2;

                                        result[2] = 0.4;

                                        result[4] = 0.4;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[1] <= 258) {
                    if (features[1] <= -384) {
                        if (features[9] <= 32) {
                            if (features[1] <= -810) {
                                return 0;
                            } else {
                                if (features[3] <= -84) {
                                    result[1] = 0.5;

                                    result[3] = 0.5;

                                    return 255;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[7] <= 2) {
                            if (features[5] <= -16) {
                                if (features[6] <= 440) {
                                    return 2;
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[4] <= -4) {
                                    if (features[9] <= -124) {
                                        if (features[1] <= -20) {
                                            return 3;
                                        } else {
                                            if (features[0] <= 22) {
                                                if (features[1] <= 12) {
                                                    result[2] = 0.2857142857142857;

                                                    result[3] = 0.7142857142857143;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        if (features[3] <= -303) {
                                            result[3] = 0.14285714285714285;

                                            result[4] = 0.8571428571428571;

                                            return 255;
                                        } else {
                                            if (features[1] <= -61) {
                                                result[1] = 0.2857142857142857;

                                                result[3] = 0.7142857142857143;

                                                return 255;
                                            } else {
                                                result[2] = 0.42857142857142855;

                                                result[3] = 0.2857142857142857;

                                                result[4] = 0.2857142857142857;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[9] <= -136) {
                                        if (features[1] <= 36) {
                                            return 3;
                                        } else {
                                            if (features[1] <= 76) {
                                                result[2] = 0.45454545454545453;

                                                result[3] = 0.5454545454545454;

                                                return 255;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        if (features[9] <= -61) {
                                            if (features[2] <= 55) {
                                                result[1] = 0.09090909090909091;

                                                result[3] = 0.9090909090909091;

                                                return 255;
                                            } else {
                                                result[3] = 0.5;

                                                result[4] = 0.5;

                                                return 255;

                                            }
                                        } else {
                                            if (features[6] <= 88) {
                                                result[3] = 0.8;

                                                result[4] = 0.2;

                                                return 255;
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 64) {
                                if (features[7] <= 6) {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.42857142857142855;

                                    result[3] = 0.42857142857142855;

                                    return 255;
                                } else {
                                    if (features[9] <= -212) {
                                        result[2] = 0.5714285714285714;

                                        result[3] = 0.42857142857142855;

                                        return 255;
                                    } else {
                                        if (features[5] <= -6) {
                                            result[0] = 0.5714285714285714;

                                            result[3] = 0.42857142857142855;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= 140) {
                                    if (features[8] <= -768) {
                                        if (features[1] <= -283) {
                                            result[3] = 0.8333333333333334;

                                            result[4] = 0.16666666666666666;

                                            return 255;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[4] <= 40) {
                                            if (features[9] <= -78) {
                                                if (features[3] <= -48) {
                                                    if (features[7] <= 45) {
                                                        result[3] = 0.6666666666666666;

                                                        result[4] = 0.3333333333333333;

                                                        return 255;
                                                    } else {
                                                        return 4;

                                                    }
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                if (features[4] <= 8) {
                                                    return 4;
                                                } else {
                                                    if (features[5] <= 140) {
                                                        result[3] = 0.5789473684210527;

                                                        result[4] = 0.42105263157894735;

                                                        return 255;
                                                    } else {
                                                        result[3] = 0.14285714285714285;

                                                        result[4] = 0.8571428571428571;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[6] <= 356) {
                                                if (features[4] <= 65) {
                                                    return 3;
                                                } else {
                                                    result[3] = 0.8571428571428571;

                                                    result[4] = 0.14285714285714285;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[4] <= 142) {
                                                    result[1] = 0.125;

                                                    result[3] = 0.5;

                                                    result[4] = 0.375;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    result[1] = 0.8;

                                    result[3] = 0.2;

                                    return 255;

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= 48) {
                        result[1] = 0.5555555555555556;

                        result[3] = 0.4444444444444444;

                        return 255;
                    } else {
                        if (features[9] <= 4) {
                            result[1] = 0.25;

                            result[3] = 0.75;

                            return 255;
                        } else {
                            return 0;

                        }

                    }

                }

            }
        } else {
            if (features[6] <= 10) {
                if (features[0] <= 143) {
                    if (features[1] <= -468) {
                        return 0;
                    } else {
                        if (features[5] <= -317) {
                            return 2;
                        } else {
                            if (features[5] <= 0) {
                                if (features[1] <= 408) {
                                    if (features[8] <= 541) {
                                        if (features[3] <= -2) {
                                            if (features[9] <= 31) {
                                                if (features[1] <= 60) {
                                                    if (features[3] <= -72) {
                                                        result[1] = 0.2857142857142857;

                                                        result[2] = 0.42857142857142855;

                                                        result[3] = 0.2857142857142857;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[3] <= -96) {
                                                    return 2;
                                                } else {
                                                    if (features[7] <= 38) {
                                                        result[0] = 0.024390243902439025;

                                                        result[2] = 0.9512195121951219;

                                                        result[3] = 0.024390243902439025;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.5714285714285714;

                                                        result[2] = 0.42857142857142855;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[0] <= -94) {
                                                if (features[6] <= -168) {
                                                    result[0] = 0.3333333333333333;

                                                    result[3] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    if (features[3] <= 95) {
                                                        result[0] = 0.8333333333333334;

                                                        result[4] = 0.16666666666666666;

                                                        return 255;
                                                    } else {
                                                        return 0;

                                                    }

                                                }
                                            } else {
                                                if (features[6] <= -330) {
                                                    result[0] = 0.09090909090909091;

                                                    result[2] = 0.9090909090909091;

                                                    return 255;
                                                } else {
                                                    if (features[6] <= -98) {
                                                        return 3;
                                                    } else {
                                                        result[0] = 0.2777777777777778;

                                                        result[2] = 0.2222222222222222;

                                                        result[3] = 0.5;

                                                        return 255;

                                                    }

                                                }

                                            }

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[6] <= -1692) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[7] <= -36) {
                                    return 4;
                                } else {
                                    if (features[2] <= -180) {
                                        result[1] = 0.36363636363636365;

                                        result[2] = 0.6363636363636364;

                                        return 255;
                                    } else {
                                        if (features[9] <= 40) {
                                            result[2] = 0.75;

                                            result[3] = 0.25;

                                            return 255;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[6] <= -1779) {
                        return 2;
                    } else {
                        if (features[1] <= 336) {
                            if (features[4] <= -67) {
                                return 1;
                            } else {
                                if (features[3] <= 50) {
                                    return 2;
                                } else {
                                    result[2] = 0.5;

                                    result[3] = 0.5;

                                    return 255;

                                }

                            }
                        } else {
                            return 1;

                        }

                    }

                }
            } else {
                if (features[5] <= 327) {
                    if (features[4] <= 50) {
                        if (features[0] <= 32) {
                            if (features[3] <= 225) {
                                if (features[5] <= 102) {
                                    if (features[8] <= 43) {
                                        if (features[1] <= -54) {
                                            result[1] = 0.18181818181818182;

                                            result[4] = 0.8181818181818182;

                                            return 255;
                                        } else {
                                            if (features[8] <= 29) {
                                                result[0] = 0.9166666666666666;

                                                result[3] = 0.08333333333333333;

                                                return 255;
                                            } else {
                                                result[0] = 0.25;

                                                result[3] = 0.25;

                                                result[4] = 0.5;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[9] <= 45) {
                                            result[0] = 0.14285714285714285;

                                            result[1] = 0.7142857142857143;

                                            result[4] = 0.14285714285714285;

                                            return 255;
                                        } else {
                                            if (features[6] <= 130) {
                                                if (features[5] <= 83) {
                                                    if (features[3] <= -5) {
                                                        result[2] = 0.7272727272727273;

                                                        result[3] = 0.2727272727272727;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }
                                                } else {
                                                    result[2] = 0.7777777777777778;

                                                    result[4] = 0.2222222222222222;

                                                    return 255;

                                                }
                                            } else {
                                                result[0] = 0.2;

                                                result[1] = 0.6;

                                                result[4] = 0.2;

                                                return 255;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[7] <= 43) {
                                        return 4;
                                    } else {
                                        if (features[3] <= 58) {
                                            if (features[9] <= 86) {
                                                if (features[7] <= 66) {
                                                    result[2] = 0.16666666666666666;

                                                    result[4] = 0.8333333333333334;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                if (features[4] <= 12) {
                                                    if (features[3] <= -2) {
                                                        result[3] = 0.42857142857142855;

                                                        result[4] = 0.5714285714285714;

                                                        return 255;
                                                    } else {
                                                        result[3] = 0.8;

                                                        result[4] = 0.2;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[2] = 0.18181818181818182;

                                                    result[3] = 0.7272727272727273;

                                                    result[4] = 0.09090909090909091;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            return 4;

                                        }

                                    }

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[1] <= 72) {
                                if (features[4] <= 8) {
                                    if (features[8] <= 38) {
                                        return 1;
                                    } else {
                                        result[1] = 0.6;

                                        result[2] = 0.4;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[2] <= 0) {
                                    if (features[9] <= 114) {
                                        if (features[1] <= 406) {
                                            return 0;
                                        } else {
                                            if (features[3] <= -334) {
                                                if (features[8] <= 226) {
                                                    return 0;
                                                } else {
                                                    result[0] = 0.875;

                                                    result[1] = 0.125;

                                                    return 255;

                                                }
                                            } else {
                                                result[0] = 0.5;

                                                result[1] = 0.5;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        result[0] = 0.2857142857142857;

                                        result[1] = 0.42857142857142855;

                                        result[2] = 0.2857142857142857;

                                        return 255;

                                    }
                                } else {
                                    if (features[9] <= 96) {
                                        if (features[5] <= 196) {
                                            if (features[5] <= 137) {
                                                if (features[7] <= 113) {
                                                    if (features[5] <= 74) {
                                                        return 1;
                                                    } else {
                                                        result[0] = 0.25;

                                                        result[1] = 0.75;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[0] = 0.5;

                                                    result[1] = 0.5;

                                                    return 255;

                                                }
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            result[0] = 0.8333333333333334;

                                            result[1] = 0.16666666666666666;

                                            return 255;

                                        }
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 87) {
                            if (features[1] <= 126) {
                                if (features[8] <= 96) {
                                    if (features[3] <= 95) {
                                        if (features[6] <= 138) {
                                            if (features[9] <= 46) {
                                                result[0] = 0.5;

                                                result[3] = 0.5;

                                                return 255;
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            result[0] = 0.5714285714285714;

                                            result[3] = 0.42857142857142855;

                                            return 255;

                                        }
                                    } else {
                                        if (features[9] <= -13) {
                                            result[0] = 0.7142857142857143;

                                            result[1] = 0.2857142857142857;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 87) {
                                        if (features[4] <= 74) {
                                            result[0] = 0.7;

                                            result[1] = 0.2;

                                            result[3] = 0.1;

                                            return 255;
                                        } else {
                                            if (features[6] <= 179) {
                                                return 0;
                                            } else {
                                                result[0] = 0.8571428571428571;

                                                result[1] = 0.14285714285714285;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        result[0] = 0.2;

                                        result[2] = 0.8;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[6] <= 180) {
                                    result[1] = 0.625;

                                    result[2] = 0.375;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[0] <= 32) {
                                if (features[3] <= 216) {
                                    return 1;
                                } else {
                                    if (features[1] <= -183) {
                                        if (features[8] <= 242) {
                                            return 1;
                                        } else {
                                            result[0] = 0.5;

                                            result[1] = 0.5;

                                            return 255;

                                        }
                                    } else {
                                        if (features[9] <= 104) {
                                            result[0] = 0.8;

                                            result[1] = 0.2;

                                            return 255;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 60) {
                                    if (features[5] <= 138) {
                                        return 1;
                                    } else {
                                        result[0] = 0.3333333333333333;

                                        result[1] = 0.6666666666666666;

                                        return 255;

                                    }
                                } else {
                                    if (features[8] <= 96) {
                                        if (features[1] <= 26) {
                                            result[0] = 0.625;

                                            result[1] = 0.375;

                                            return 255;
                                        } else {
                                            if (features[2] <= 60) {
                                                result[1] = 0.8333333333333334;

                                                result[3] = 0.16666666666666666;

                                                return 255;
                                            } else {
                                                result[1] = 0.14285714285714285;

                                                result[3] = 0.7142857142857143;

                                                result[4] = 0.14285714285714285;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 117) {
                                            if (features[1] <= 5) {
                                                return 0;
                                            } else {
                                                result[0] = 0.5714285714285714;

                                                result[4] = 0.42857142857142855;

                                                return 255;

                                            }
                                        } else {
                                            result[0] = 0.42857142857142855;

                                            result[2] = 0.5714285714285714;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[2] <= 86) {
                        return 4;
                    } else {
                        result[1] = 0.375;

                        result[4] = 0.625;

                        return 255;

                    }

                }

            }

        }

    }
}

unsigned char tree6(short* features, float* result){
    if (features[5] <= 302) {
        if (features[0] <= -114) {
            if (features[4] <= 186) {
                if (features[5] <= -66) {
                    if (features[9] <= 82) {
                        if (features[0] <= -370) {
                            if (features[8] <= 152) {
                                return 4;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[3] <= 110) {
                                if (features[7] <= 6) {
                                    if (features[2] <= -127) {
                                        result[2] = 0.2;

                                        result[3] = 0.4;

                                        result[4] = 0.4;

                                        return 255;
                                    } else {
                                        if (features[8] <= -63) {
                                            result[0] = 0.16666666666666666;

                                            result[1] = 0.6666666666666666;

                                            result[2] = 0.16666666666666666;

                                            return 255;
                                        } else {
                                            result[0] = 0.6153846153846154;

                                            result[3] = 0.38461538461538464;

                                            return 255;

                                        }

                                    }
                                } else {
                                    if (features[1] <= 566) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[8] <= 42) {
                                    result[0] = 0.4;

                                    result[3] = 0.6;

                                    return 255;
                                } else {
                                    if (features[2] <= -15) {
                                        result[0] = 0.8333333333333334;

                                        result[2] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 42) {
                            return 2;
                        } else {
                            result[0] = 0.4444444444444444;

                            result[2] = 0.4444444444444444;

                            result[3] = 0.1111111111111111;

                            return 255;

                        }

                    }
                } else {
                    if (features[8] <= 6) {
                        if (features[8] <= -924) {
                            return 3;
                        } else {
                            if (features[9] <= -330) {
                                if (features[0] <= -470) {
                                    return 4;
                                } else {
                                    result[2] = 0.125;

                                    result[3] = 0.875;

                                    return 255;

                                }
                            } else {
                                if (features[0] <= -659) {
                                    result[0] = 0.5;

                                    result[4] = 0.5;

                                    return 255;
                                } else {
                                    if (features[1] <= -386) {
                                        if (features[5] <= 40) {
                                            if (features[1] <= -754) {
                                                result[0] = 0.2;

                                                result[4] = 0.8;

                                                return 255;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            result[1] = 0.42857142857142855;

                                            result[4] = 0.5714285714285714;

                                            return 255;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[6] <= 282) {
                            if (features[9] <= 27) {
                                if (features[2] <= -10) {
                                    return 4;
                                } else {
                                    if (features[0] <= -136) {
                                        result[0] = 0.5;

                                        result[4] = 0.5;

                                        return 255;
                                    } else {
                                        result[0] = 0.7777777777777778;

                                        result[1] = 0.2222222222222222;

                                        return 255;

                                    }

                                }
                            } else {
                                if (features[1] <= -270) {
                                    result[0] = 0.14285714285714285;

                                    result[1] = 0.8571428571428571;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            return 1;

                        }

                    }

                }
            } else {
                if (features[8] <= -202) {
                    if (features[4] <= 498) {
                        return 4;
                    } else {
                        result[0] = 0.8;

                        result[4] = 0.2;

                        return 255;

                    }
                } else {
                    if (features[5] <= 203) {
                        if (features[2] <= 226) {
                            if (features[7] <= 6) {
                                return 0;
                            } else {
                                if (features[7] <= 9) {
                                    result[0] = 0.75;

                                    result[2] = 0.25;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            result[0] = 0.8333333333333334;

                            result[1] = 0.16666666666666666;

                            return 255;

                        }
                    } else {
                        if (features[6] <= 186) {
                            result[0] = 0.3333333333333333;

                            result[3] = 0.6666666666666666;

                            return 255;
                        } else {
                            result[0] = 0.125;

                            result[1] = 0.875;

                            return 255;

                        }

                    }

                }

            }
        } else {
            if (features[0] <= 72) {
                if (features[6] <= 6) {
                    if (features[8] <= 30) {
                        if (features[9] <= 2) {
                            if (features[3] <= 286) {
                                if (features[6] <= -371) {
                                    if (features[6] <= -685) {
                                        return 2;
                                    } else {
                                        result[0] = 0.16666666666666666;

                                        result[2] = 0.8333333333333334;

                                        return 255;

                                    }
                                } else {
                                    if (features[5] <= 1) {
                                        if (features[8] <= -60) {
                                            if (features[6] <= -20) {
                                                return 1;
                                            } else {
                                                result[0] = 0.2857142857142857;

                                                result[1] = 0.5714285714285714;

                                                result[3] = 0.14285714285714285;

                                                return 255;

                                            }
                                        } else {
                                            if (features[1] <= -46) {
                                                result[0] = 0.75;

                                                result[1] = 0.25;

                                                return 255;
                                            } else {
                                                if (features[1] <= 72) {
                                                    if (features[7] <= 68) {
                                                        result[0] = 0.034482758620689655;

                                                        result[1] = 0.06896551724137931;

                                                        result[3] = 0.896551724137931;

                                                        return 255;
                                                    } else {
                                                        result[1] = 0.2222222222222222;

                                                        result[2] = 0.3333333333333333;

                                                        result[3] = 0.4444444444444444;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[1] = 0.8333333333333334;

                                                    result[3] = 0.16666666666666666;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[1] <= -14) {
                                            result[3] = 0.5;

                                            result[4] = 0.5;

                                            return 255;
                                        } else {
                                            if (features[7] <= -10) {
                                                result[2] = 0.2;

                                                result[3] = 0.8;

                                                return 255;
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[2] <= -19) {
                                return 4;
                            } else {
                                if (features[9] <= 118) {
                                    if (features[2] <= 1) {
                                        result[1] = 0.6666666666666666;

                                        result[4] = 0.3333333333333333;

                                        return 255;
                                    } else {
                                        result[0] = 0.6;

                                        result[2] = 0.2;

                                        result[4] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }

                            }

                        }
                    } else {
                        if (features[3] <= -102) {
                            if (features[5] <= -141) {
                                return 2;
                            } else {
                                if (features[1] <= 130) {
                                    if (features[5] <= 1) {
                                        if (features[9] <= 34) {
                                            result[1] = 0.6666666666666666;

                                            result[2] = 0.3333333333333333;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[8] <= 1321) {
                                        if (features[5] <= 5) {
                                            return 1;
                                        } else {
                                            result[1] = 0.8888888888888888;

                                            result[2] = 0.1111111111111111;

                                            return 255;

                                        }
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= 10) {
                                if (features[1] <= -459) {
                                    return 0;
                                } else {
                                    if (features[0] <= -28) {
                                        return 3;
                                    } else {
                                        if (features[2] <= 28) {
                                            if (features[6] <= -316) {
                                                result[1] = 0.2857142857142857;

                                                result[2] = 0.7142857142857143;

                                                return 255;
                                            } else {
                                                result[0] = 0.3;

                                                result[3] = 0.7;

                                                return 255;

                                            }
                                        } else {
                                            return 2;

                                        }

                                    }

                                }
                            } else {
                                if (features[1] <= -60) {
                                    if (features[3] <= 410) {
                                        if (features[4] <= -2) {
                                            result[0] = 0.5714285714285714;

                                            result[2] = 0.42857142857142855;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[8] <= 132) {
                                        if (features[5] <= -16) {
                                            if (features[7] <= -2) {
                                                return 2;
                                            } else {
                                                if (features[0] <= -4) {
                                                    result[2] = 0.14285714285714285;

                                                    result[3] = 0.8571428571428571;

                                                    return 255;
                                                } else {
                                                    result[2] = 0.7142857142857143;

                                                    result[3] = 0.2857142857142857;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[5] <= -139) {
                                            return 2;
                                        } else {
                                            if (features[5] <= -64) {
                                                result[0] = 0.5;

                                                result[2] = 0.5;

                                                return 255;
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= -22) {
                        if (features[8] <= -230) {
                            if (features[6] <= 382) {
                                if (features[1] <= -1338) {
                                    return 0;
                                } else {
                                    if (features[6] <= 193) {
                                        if (features[1] <= 10) {
                                            result[2] = 0.375;

                                            result[3] = 0.625;

                                            return 255;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[0] <= -30) {
                                            result[2] = 0.2857142857142857;

                                            result[3] = 0.7142857142857143;

                                            return 255;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 496) {
                                    result[2] = 0.125;

                                    result[3] = 0.875;

                                    return 255;
                                } else {
                                    if (features[3] <= 1004) {
                                        return 3;
                                    } else {
                                        result[0] = 0.2;

                                        result[3] = 0.8;

                                        return 255;

                                    }

                                }

                            }
                        } else {
                            if (features[1] <= -157) {
                                if (features[9] <= 35) {
                                    result[0] = 0.3333333333333333;

                                    result[1] = 0.5;

                                    result[3] = 0.16666666666666666;

                                    return 255;
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[5] <= 51) {
                                    result[1] = 0.23529411764705882;

                                    result[2] = 0.5882352941176471;

                                    result[3] = 0.17647058823529413;

                                    return 255;
                                } else {
                                    if (features[4] <= 16) {
                                        if (features[1] <= -28) {
                                            if (features[0] <= -20) {
                                                return 4;
                                            } else {
                                                if (features[5] <= 140) {
                                                    result[0] = 0.14285714285714285;

                                                    result[3] = 0.42857142857142855;

                                                    result[4] = 0.42857142857142855;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[7] <= 9) {
                                            if (features[9] <= -42) {
                                                result[1] = 0.125;

                                                result[2] = 0.75;

                                                result[3] = 0.125;

                                                return 255;
                                            } else {
                                                if (features[6] <= 62) {
                                                    result[3] = 0.8571428571428571;

                                                    result[4] = 0.14285714285714285;

                                                    return 255;
                                                } else {
                                                    if (features[0] <= 18) {
                                                        return 3;
                                                    } else {
                                                        result[3] = 0.9545454545454546;

                                                        result[4] = 0.045454545454545456;

                                                        return 255;

                                                    }

                                                }

                                            }
                                        } else {
                                            if (features[6] <= 112) {
                                                return 4;
                                            } else {
                                                if (features[3] <= 22) {
                                                    result[3] = 0.2;

                                                    result[4] = 0.8;

                                                    return 255;
                                                } else {
                                                    if (features[8] <= -88) {
                                                        result[3] = 0.5;

                                                        result[4] = 0.5;

                                                        return 255;
                                                    } else {
                                                        return 3;

                                                    }

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 96) {
                            if (features[7] <= 230) {
                                if (features[5] <= 100) {
                                    if (features[6] <= 33) {
                                        if (features[3] <= 30) {
                                            if (features[9] <= 60) {
                                                if (features[3] <= -2) {
                                                    return 1;
                                                } else {
                                                    result[1] = 0.8333333333333334;

                                                    result[2] = 0.16666666666666666;

                                                    return 255;

                                                }
                                            } else {
                                                result[1] = 0.2;

                                                result[2] = 0.8;

                                                return 255;

                                            }
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        if (features[1] <= 2) {
                                            if (features[1] <= -57) {
                                                result[3] = 0.6;

                                                result[4] = 0.4;

                                                return 255;
                                            } else {
                                                if (features[4] <= -3) {
                                                    result[0] = 0.1111111111111111;

                                                    result[1] = 0.1111111111111111;

                                                    result[2] = 0.3333333333333333;

                                                    result[3] = 0.4444444444444444;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            if (features[3] <= 10) {
                                                if (features[6] <= 130) {
                                                    if (features[3] <= -4) {
                                                        return 2;
                                                    } else {
                                                        result[1] = 0.2;

                                                        result[2] = 0.5;

                                                        result[3] = 0.3;

                                                        return 255;

                                                    }
                                                } else {
                                                    result[0] = 0.4;

                                                    result[1] = 0.4;

                                                    result[3] = 0.2;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[5] <= 92) {
                                                    result[3] = 0.7777777777777778;

                                                    result[4] = 0.2222222222222222;

                                                    return 255;
                                                } else {
                                                    result[0] = 0.7;

                                                    result[3] = 0.3;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[6] <= 170) {
                                        if (features[9] <= 104) {
                                            if (features[3] <= 70) {
                                                if (features[0] <= 33) {
                                                    if (features[6] <= 148) {
                                                        return 4;
                                                    } else {
                                                        result[3] = 0.16666666666666666;

                                                        result[4] = 0.8333333333333334;

                                                        return 255;

                                                    }
                                                } else {
                                                    if (features[6] <= 118) {
                                                        result[2] = 0.5555555555555556;

                                                        result[3] = 0.2222222222222222;

                                                        result[4] = 0.2222222222222222;

                                                        return 255;
                                                    } else {
                                                        result[0] = 0.6666666666666666;

                                                        result[2] = 0.3333333333333333;

                                                        return 255;

                                                    }

                                                }
                                            } else {
                                                result[1] = 0.8;

                                                result[4] = 0.2;

                                                return 255;

                                            }
                                        } else {
                                            result[0] = 0.2222222222222222;

                                            result[1] = 0.3333333333333333;

                                            result[2] = 0.4444444444444444;

                                            return 255;

                                        }
                                    } else {
                                        if (features[3] <= -84) {
                                            result[1] = 0.42857142857142855;

                                            result[4] = 0.5714285714285714;

                                            return 255;
                                        } else {
                                            if (features[8] <= 70) {
                                                return 3;
                                            } else {
                                                result[3] = 0.5;

                                                result[4] = 0.5;

                                                return 255;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[9] <= 60) {
                                    return 0;
                                } else {
                                    result[0] = 0.23076923076923078;

                                    result[1] = 0.6923076923076923;

                                    result[3] = 0.07692307692307693;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[0] <= 38) {
                                if (features[1] <= -812) {
                                    return 0;
                                } else {
                                    if (features[4] <= 51) {
                                        result[0] = 0.625;

                                        result[4] = 0.375;

                                        return 255;
                                    } else {
                                        if (features[9] <= 124) {
                                            if (features[5] <= 100) {
                                                if (features[1] <= -86) {
                                                    if (features[1] <= -137) {
                                                        result[0] = 0.42857142857142855;

                                                        result[1] = 0.5714285714285714;

                                                        return 255;
                                                    } else {
                                                        return 1;

                                                    }
                                                } else {
                                                    result[0] = 0.6153846153846154;

                                                    result[1] = 0.38461538461538464;

                                                    return 255;

                                                }
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                return 0;

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 30) {
                    if (features[0] <= 280) {
                        if (features[9] <= 132) {
                            if (features[4] <= 44) {
                                if (features[0] <= 242) {
                                    if (features[3] <= -2) {
                                        return 1;
                                    } else {
                                        result[1] = 0.8;

                                        result[3] = 0.2;

                                        return 255;

                                    }
                                } else {
                                    result[1] = 0.6363636363636364;

                                    result[2] = 0.36363636363636365;

                                    return 255;

                                }
                            } else {
                                if (features[7] <= -8) {
                                    result[1] = 0.5;

                                    result[2] = 0.5;

                                    return 255;
                                } else {
                                    result[0] = 0.2222222222222222;

                                    result[3] = 0.7777777777777778;

                                    return 255;

                                }

                            }
                        } else {
                            if (features[5] <= -322) {
                                return 2;
                            } else {
                                if (features[4] <= -149) {
                                    if (features[8] <= 152) {
                                        return 1;
                                    } else {
                                        result[1] = 0.5714285714285714;

                                        result[2] = 0.42857142857142855;

                                        return 255;

                                    }
                                } else {
                                    return 2;

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 4) {
                            if (features[4] <= -282) {
                                return 1;
                            } else {
                                if (features[8] <= -20) {
                                    result[1] = 0.6666666666666666;

                                    result[4] = 0.3333333333333333;

                                    return 255;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            result[1] = 0.2857142857142857;

                            result[2] = 0.5714285714285714;

                            result[3] = 0.14285714285714285;

                            return 255;

                        }

                    }
                } else {
                    if (features[2] <= -0) {
                        if (features[7] <= 80) {
                            if (features[1] <= 288) {
                                return 0;
                            } else {
                                if (features[6] <= 589) {
                                    result[0] = 0.2;

                                    result[1] = 0.8;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[5] <= 144) {
                                if (features[9] <= 78) {
                                    if (features[0] <= 120) {
                                        result[1] = 0.6666666666666666;

                                        result[2] = 0.16666666666666666;

                                        result[3] = 0.16666666666666666;

                                        return 255;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[9] <= 118) {
                                        if (features[4] <= 74) {
                                            if (features[5] <= 106) {
                                                return 0;
                                            } else {
                                                result[0] = 0.8;

                                                result[1] = 0.2;

                                                return 255;

                                            }
                                        } else {
                                            result[0] = 0.5714285714285714;

                                            result[1] = 0.42857142857142855;

                                            return 255;

                                        }
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[7] <= -10) {
                            return 3;
                        } else {
                            if (features[4] <= 114) {
                                if (features[1] <= 68) {
                                    if (features[1] <= 4) {
                                        return 0;
                                    } else {
                                        result[0] = 0.1;

                                        result[2] = 0.6;

                                        result[3] = 0.3;

                                        return 255;

                                    }
                                } else {
                                    if (features[0] <= 106) {
                                        if (features[5] <= 70) {
                                            result[0] = 0.1;

                                            result[2] = 0.5;

                                            result[3] = 0.4;

                                            return 255;
                                        } else {
                                            if (features[0] <= 100) {
                                                return 1;
                                            } else {
                                                result[0] = 0.2;

                                                result[1] = 0.4;

                                                result[2] = 0.4;

                                                return 255;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 69) {
                                            if (features[7] <= 63) {
                                                if (features[9] <= 76) {
                                                    result[0] = 0.3333333333333333;

                                                    result[1] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[6] <= 507) {
                                                    result[0] = 0.4;

                                                    result[1] = 0.6;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }
                                        } else {
                                            return 1;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 122) {
                                    result[0] = 0.5;

                                    result[2] = 0.5;

                                    return 255;
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[3] <= 441) {
            if (features[7] <= 46) {
                if (features[8] <= 14) {
                    if (features[2] <= -95) {
                        if (features[7] <= -376) {
                            return 4;
                        } else {
                            result[3] = 0.8181818181818182;

                            result[4] = 0.18181818181818182;

                            return 255;

                        }
                    } else {
                        if (features[0] <= -244) {
                            result[0] = 0.2857142857142857;

                            result[3] = 0.7142857142857143;

                            return 255;
                        } else {
                            if (features[3] <= -274) {
                                result[3] = 0.25;

                                result[4] = 0.75;

                                return 255;
                            } else {
                                if (features[0] <= -64) {
                                    return 3;
                                } else {
                                    if (features[1] <= 20) {
                                        if (features[7] <= 16) {
                                            return 3;
                                        } else {
                                            result[3] = 0.8571428571428571;

                                            result[4] = 0.14285714285714285;

                                            return 255;

                                        }
                                    } else {
                                        if (features[2] <= 62) {
                                            if (features[1] <= 70) {
                                                if (features[7] <= -18) {
                                                    return 3;
                                                } else {
                                                    result[3] = 0.5;

                                                    result[4] = 0.5;

                                                    return 255;

                                                }
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            result[3] = 0.375;

                                            result[4] = 0.625;

                                            return 255;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    return 4;

                }
            } else {
                if (features[6] <= 1056) {
                    if (features[1] <= 264) {
                        if (features[8] <= -348) {
                            if (features[9] <= -208) {
                                return 4;
                            } else {
                                result[3] = 0.125;

                                result[4] = 0.875;

                                return 255;

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        result[0] = 0.42857142857142855;

                        result[4] = 0.5714285714285714;

                        return 255;

                    }
                } else {
                    return 3;

                }

            }
        } else {
            if (features[6] <= 1084) {
                if (features[5] <= 412) {
                    return 1;
                } else {
                    result[3] = 0.25;

                    result[4] = 0.75;

                    return 255;

                }
            } else {
                if (features[0] <= -321) {
                    return 0;
                } else {
                    return 3;

                }

            }

        }

    }
}

unsigned char evaluate_forest(short* args) {
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
float total_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char return_res = 0;
unsigned char result_map[5] = { 1,2,3,4, 9 };
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree0(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree1(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree2(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree3(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree4(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree5(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
tree_res[0] = 0.0;
tree_res[1] = 0.0;
tree_res[2] = 0.0;
tree_res[3] = 0.0;
tree_res[4] = 0.0;
return_res = tree6(args, tree_res);
if (return_res == 255) {
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
} else {
total_res[return_res] += 1.0;
}
unsigned char max_index = 0;
float max_value = 0;
for (unsigned char i = 0; i < 5; ++i) {
if (max_value < total_res[i]) {
max_value = total_res[i];
max_index = i;
}
}
return result_map[max_index];
}
