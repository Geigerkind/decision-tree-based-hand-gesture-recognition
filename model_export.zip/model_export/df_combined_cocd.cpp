unsigned char tree0(short* features, float* result){
    if (features[6] <= -4) {
        if (features[0] <= -88) {
            if (features[9] <= 36) {
                if (features[4] <= 366) {
                    if (features[1] <= -1028) {
                        if (features[2] <= -464) {
                            return 4;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[5] <= -100) {
                            if (features[4] <= -148) {
                                if (features[0] <= -416) {
                                    return 4;
                                } else {
                                    if (features[6] <= -1362) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[8] <= -120) {
                                    if (features[2] <= -94) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[7] <= 156) {
                                        if (features[8] <= 381) {
                                            if (features[2] <= 4) {
                                                if (features[4] <= 2) {
                                                    result[1] = 0.2;

                                                    result[3] = 0.8;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        return 3;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 34) {
                                if (features[9] <= -532) {
                                    return 3;
                                } else {
                                    if (features[9] <= -234) {
                                        if (features[1] <= -88) {
                                            return 4;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[5] <= -50) {
                                            if (features[0] <= -224) {
                                                return 4;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            return 4;

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= -386) {
                                    if (features[5] <= -60) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[5] <= -64) {
                                        return 0;
                                    } else {
                                        if (features[2] <= 8) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= -204) {
                        if (features[8] <= -314) {
                            return 0;
                        } else {
                            return 4;

                        }
                    } else {
                        return 0;

                    }

                }
            } else {
                if (features[4] <= 50) {
                    if (features[3] <= 27) {
                        return 2;
                    } else {
                        if (features[1] <= -197) {
                            return 3;
                        } else {
                            return 2;

                        }

                    }
                } else {
                    if (features[5] <= -473) {
                        return 2;
                    } else {
                        return 0;

                    }

                }

            }
        } else {
            if (features[0] <= 169) {
                if (features[9] <= 38) {
                    if (features[1] <= -438) {
                        return 0;
                    } else {
                        if (features[1] <= 107) {
                            if (features[2] <= 35) {
                                if (features[5] <= -10) {
                                    if (features[6] <= -66) {
                                        if (features[8] <= 362) {
                                            return 3;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[1] <= 3) {
                                            return 1;
                                        } else {
                                            if (features[3] <= -204) {
                                                return 1;
                                            } else {
                                                if (features[1] <= 24) {
                                                    return 3;
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[9] <= -26) {
                                        return 3;
                                    } else {
                                        if (features[1] <= -122) {
                                            return 4;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }
                            } else {
                                if (features[2] <= 80) {
                                    if (features[6] <= -678) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[2] <= 190) {
                                        if (features[9] <= -76) {
                                            return 1;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= -18) {
                                if (features[4] <= 126) {
                                    if (features[3] <= -150) {
                                        return 1;
                                    } else {
                                        if (features[4] <= 4) {
                                            return 3;
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[6] <= -1345) {
                                    return 2;
                                } else {
                                    if (features[7] <= 883) {
                                        if (features[9] <= 10) {
                                            return 1;
                                        } else {
                                            if (features[7] <= -48) {
                                                return 4;
                                            } else {
                                                if (features[0] <= 150) {
                                                    return 1;
                                                } else {
                                                    return 3;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[2] <= -342) {
                                            return 1;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[5] <= 169) {
                        if (features[2] <= 615) {
                            if (features[3] <= -716) {
                                return 1;
                            } else {
                                if (features[8] <= 132) {
                                    if (features[3] <= 30) {
                                        if (features[4] <= 37) {
                                            if (features[3] <= -6) {
                                                return 2;
                                            } else {
                                                if (features[0] <= -6) {
                                                    result[2] = 0.875;

                                                    result[3] = 0.125;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }

                                            }
                                        } else {
                                            if (features[7] <= -13) {
                                                return 2;
                                            } else {
                                                if (features[0] <= 36) {
                                                    return 2;
                                                } else {
                                                    result[2] = 0.3333333333333333;

                                                    result[3] = 0.6666666666666666;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[1] <= 91) {
                                            if (features[7] <= 993) {
                                                return 3;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            return 2;

                                        }

                                    }
                                } else {
                                    if (features[4] <= 134) {
                                        if (features[6] <= -142) {
                                            return 2;
                                        } else {
                                            if (features[1] <= -40) {
                                                if (features[5] <= -44) {
                                                    return 0;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }
                                    } else {
                                        if (features[1] <= -433) {
                                            return 0;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= -234) {
                                return 1;
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[5] <= 332) {
                            return 1;
                        } else {
                            return 4;

                        }

                    }

                }
            } else {
                if (features[4] <= -263) {
                    if (features[1] <= 360) {
                        return 1;
                    } else {
                        if (features[2] <= 64) {
                            return 1;
                        } else {
                            if (features[9] <= -4) {
                                return 4;
                            } else {
                                return 1;

                            }

                        }

                    }
                } else {
                    if (features[5] <= -396) {
                        return 2;
                    } else {
                        if (features[9] <= 370) {
                            if (features[2] <= -0) {
                                return 1;
                            } else {
                                if (features[3] <= -110) {
                                    return 1;
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            return 2;

                        }

                    }

                }

            }

        }
    } else {
        if (features[5] <= 310) {
            if (features[8] <= -40) {
                if (features[0] <= 116) {
                    if (features[1] <= -468) {
                        if (features[1] <= -1456) {
                            return 0;
                        } else {
                            if (features[9] <= 18) {
                                if (features[1] <= -748) {
                                    return 4;
                                } else {
                                    return 3;

                                }
                            } else {
                                return 1;

                            }

                        }
                    } else {
                        if (features[6] <= 505) {
                            if (features[4] <= 7) {
                                if (features[4] <= -41) {
                                    if (features[9] <= -176) {
                                        if (features[1] <= -34) {
                                            if (features[5] <= -87) {
                                                return 2;
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[8] <= -160) {
                                            return 2;
                                        } else {
                                            if (features[1] <= 36) {
                                                return 4;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[9] <= -62) {
                                        if (features[2] <= 2) {
                                            if (features[7] <= -15) {
                                                return 3;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        if (features[5] <= 100) {
                                            if (features[2] <= 0) {
                                                return 4;
                                            } else {
                                                if (features[9] <= 32) {
                                                    return 3;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            if (features[8] <= -44) {
                                                if (features[3] <= -93) {
                                                    result[3] = 0.3333333333333333;

                                                    result[4] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[9] <= -10) {
                                    if (features[2] <= 2) {
                                        if (features[9] <= -126) {
                                            if (features[8] <= -282) {
                                                return 4;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            if (features[3] <= -20) {
                                                return 1;
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[7] <= -88) {
                                            if (features[5] <= 64) {
                                                return 2;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[6] <= 58) {
                                                return 2;
                                            } else {
                                                if (features[0] <= 44) {
                                                    return 3;
                                                } else {
                                                    result[2] = 0.08333333333333333;

                                                    result[3] = 0.9166666666666666;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[3] <= -24) {
                                        if (features[7] <= 46) {
                                            return 4;
                                        } else {
                                            if (features[0] <= -17) {
                                                return 4;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        if (features[1] <= -172) {
                                            return 1;
                                        } else {
                                            if (features[9] <= 8) {
                                                if (features[5] <= 141) {
                                                    return 3;
                                                } else {
                                                    result[3] = 0.75;

                                                    result[4] = 0.25;

                                                    return 255;

                                                }
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[4] <= -110) {
                        return 1;
                    } else {
                        if (features[3] <= -62) {
                            return 0;
                        } else {
                            return 3;

                        }

                    }

                }
            } else {
                if (features[4] <= 40) {
                    if (features[6] <= 28) {
                        if (features[5] <= -22) {
                            if (features[0] <= 2) {
                                if (features[1] <= 10) {
                                    if (features[9] <= 124) {
                                        if (features[1] <= -34) {
                                            return 4;
                                        } else {
                                            if (features[2] <= -2) {
                                                return 0;
                                            } else {
                                                return 2;

                                            }

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[3] <= -0) {
                                    return 1;
                                } else {
                                    if (features[5] <= -180) {
                                        if (features[9] <= 383) {
                                            return 3;
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        return 1;

                                    }

                                }

                            }
                        } else {
                            if (features[6] <= 2) {
                                if (features[9] <= 6) {
                                    if (features[2] <= 679) {
                                        if (features[8] <= 92) {
                                            if (features[8] <= -14) {
                                                if (features[5] <= 12) {
                                                    return 4;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[1] <= -1) {
                                                    return 3;
                                                } else {
                                                    result[0] = 0.1;

                                                    result[1] = 0.05;

                                                    result[3] = 0.85;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[8] <= 434) {
                                                return 1;
                                            } else {
                                                return 0;

                                            }

                                        }
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[0] <= -68) {
                                        if (features[2] <= -98) {
                                            return 1;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[0] <= 22) {
                                    if (features[8] <= 40) {
                                        if (features[3] <= -1) {
                                            return 4;
                                        } else {
                                            if (features[3] <= 1) {
                                                return 3;
                                            } else {
                                                if (features[4] <= -53) {
                                                    return 3;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[0] <= 40) {
                                        return 2;
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 75) {
                            if (features[9] <= 2) {
                                if (features[3] <= 228) {
                                    if (features[4] <= -40) {
                                        if (features[0] <= -56) {
                                            if (features[3] <= -944) {
                                                return 1;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[4] <= -434) {
                                                return 1;
                                            } else {
                                                return 0;

                                            }

                                        }
                                    } else {
                                        if (features[1] <= -11) {
                                            return 3;
                                        } else {
                                            if (features[3] <= 7) {
                                                return 2;
                                            } else {
                                                if (features[2] <= 0) {
                                                    return 2;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                if (features[0] <= 32) {
                                    if (features[1] <= -401) {
                                        return 0;
                                    } else {
                                        if (features[5] <= 118) {
                                            if (features[5] <= 82) {
                                                if (features[8] <= 74) {
                                                    result[3] = 0.68;

                                                    result[4] = 0.32;

                                                    return 255;
                                                } else {
                                                    result[2] = 0.4;

                                                    result[3] = 0.6;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= 38) {
                                                    result[1] = 0.05405405405405406;

                                                    result[2] = 0.3783783783783784;

                                                    result[3] = 0.1891891891891892;

                                                    result[4] = 0.3783783783783784;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            if (features[9] <= 108) {
                                                if (features[1] <= -43) {
                                                    result[3] = 0.14814814814814814;

                                                    result[4] = 0.8518518518518519;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                if (features[2] <= 74) {
                                                    return 3;
                                                } else {
                                                    return 2;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[7] <= 38) {
                                        if (features[5] <= 85) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 2;

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 74) {
                                if (features[8] <= 22) {
                                    if (features[5] <= 8) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[6] <= 199) {
                                        return 1;
                                    } else {
                                        if (features[5] <= 43) {
                                            return 0;
                                        } else {
                                            return 1;

                                        }

                                    }

                                }
                            } else {
                                if (features[4] <= -110) {
                                    if (features[2] <= -14) {
                                        return 0;
                                    } else {
                                        if (features[6] <= 432) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    if (features[2] <= 2) {
                                        if (features[7] <= 222) {
                                            return 0;
                                        } else {
                                            if (features[0] <= 176) {
                                                if (features[0] <= 154) {
                                                    return 0;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[7] <= 262) {
                                                    result[0] = 0.5;

                                                    result[1] = 0.5;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[9] <= 77) {
                                            if (features[5] <= 112) {
                                                return 1;
                                            } else {
                                                if (features[5] <= 282) {
                                                    return 0;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            if (features[6] <= 56) {
                                                return 2;
                                            } else {
                                                if (features[0] <= 274) {
                                                    result[0] = 0.1111111111111111;

                                                    result[1] = 0.8888888888888888;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= -197) {
                        if (features[4] <= 192) {
                            if (features[1] <= -284) {
                                return 1;
                            } else {
                                if (features[5] <= -240) {
                                    return 2;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[6] <= 84) {
                            if (features[4] <= 80) {
                                if (features[2] <= 28) {
                                    if (features[7] <= 147) {
                                        if (features[3] <= 4) {
                                            if (features[0] <= 80) {
                                                return 4;
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            if (features[9] <= 43) {
                                                if (features[1] <= 2) {
                                                    result[0] = 0.3333333333333333;

                                                    result[4] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[5] <= 68) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[9] <= 98) {
                                    if (features[9] <= 32) {
                                        if (features[2] <= 66) {
                                            if (features[0] <= 22) {
                                                if (features[9] <= -75) {
                                                    return 3;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[0] <= 82) {
                                                    return 2;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            if (features[0] <= 122) {
                                                return 2;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[8] <= 64) {
                                        return 2;
                                    } else {
                                        if (features[8] <= 74) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= 112) {
                                if (features[7] <= 102) {
                                    if (features[1] <= -346) {
                                        return 0;
                                    } else {
                                        if (features[2] <= -8) {
                                            if (features[1] <= 35) {
                                                return 3;
                                            } else {
                                                if (features[6] <= 225) {
                                                    return 0;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            if (features[3] <= 150) {
                                                return 1;
                                            } else {
                                                if (features[9] <= 52) {
                                                    result[1] = 0.6666666666666666;

                                                    result[3] = 0.3333333333333333;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[7] <= 134) {
                                        if (features[4] <= 68) {
                                            if (features[7] <= 119) {
                                                if (features[2] <= -74) {
                                                    return 0;
                                                } else {
                                                    result[0] = 0.125;

                                                    result[1] = 0.875;

                                                    return 255;

                                                }
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            if (features[3] <= 122) {
                                                if (features[9] <= 85) {
                                                    return 3;
                                                } else {
                                                    result[0] = 0.6363636363636364;

                                                    result[1] = 0.36363636363636365;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[0] <= 134) {
                                                    return 0;
                                                } else {
                                                    return 2;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[3] <= 78) {
                                            if (features[6] <= 536) {
                                                if (features[1] <= -52) {
                                                    return 0;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            if (features[7] <= 354) {
                                                if (features[8] <= 42) {
                                                    return 1;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[3] <= 416) {
                                                    return 1;
                                                } else {
                                                    return 0;

                                                }

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[7] <= 72) {
                                    if (features[0] <= -2) {
                                        return 1;
                                    } else {
                                        if (features[0] <= 0) {
                                            return 0;
                                        } else {
                                            if (features[7] <= 26) {
                                                return 1;
                                            } else {
                                                if (features[4] <= 50) {
                                                    return 0;
                                                } else {
                                                    result[0] = 0.08695652173913043;

                                                    result[1] = 0.9130434782608695;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[0] <= 74) {
                                        if (features[3] <= 96) {
                                            if (features[6] <= 129) {
                                                return 1;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[0] <= 24) {
                                                return 1;
                                            } else {
                                                if (features[0] <= 26) {
                                                    return 0;
                                                } else {
                                                    return 1;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[2] <= -78) {
                                            return 0;
                                        } else {
                                            if (features[1] <= 76) {
                                                return 0;
                                            } else {
                                                if (features[3] <= -420) {
                                                    return 0;
                                                } else {
                                                    result[1] = 0.8571428571428571;

                                                    result[3] = 0.14285714285714285;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[9] <= -148) {
                if (features[1] <= 26) {
                    if (features[1] <= -300) {
                        if (features[5] <= 705) {
                            return 3;
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[3] <= -266) {
                            if (features[5] <= 621) {
                                return 3;
                            } else {
                                return 4;

                            }
                        } else {
                            return 3;

                        }

                    }
                } else {
                    if (features[8] <= -600) {
                        return 3;
                    } else {
                        if (features[6] <= 409) {
                            if (features[7] <= 44) {
                                return 3;
                            } else {
                                return 4;

                            }
                        } else {
                            return 4;

                        }

                    }

                }
            } else {
                if (features[9] <= 96) {
                    if (features[0] <= -179) {
                        if (features[6] <= 780) {
                            return 1;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[8] <= -154) {
                            if (features[5] <= 529) {
                                if (features[3] <= 194) {
                                    if (features[5] <= 312) {
                                        return 4;
                                    } else {
                                        if (features[4] <= -10) {
                                            if (features[9] <= -62) {
                                                return 4;
                                            } else {
                                                if (features[1] <= -108) {
                                                    return 3;
                                                } else {
                                                    return 4;

                                                }

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }
                                } else {
                                    return 4;

                                }
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[5] <= 742) {
                                if (features[3] <= -422) {
                                    return 0;
                                } else {
                                    return 4;

                                }
                            } else {
                                if (features[6] <= 86) {
                                    return 3;
                                } else {
                                    return 4;

                                }

                            }

                        }

                    }
                } else {
                    if (features[0] <= -332) {
                        return 0;
                    } else {
                        return 4;

                    }

                }

            }

        }

    }
}

unsigned char tree1(short* features, float* result){
    if (features[9] <= 40) {
        if (features[5] <= 44) {
            if (features[3] <= -0) {
                if (features[8] <= 71) {
                    if (features[6] <= 105) {
                        if (features[4] <= -506) {
                            if (features[1] <= -38) {
                                return 4;
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[3] <= -555) {
                                return 1;
                            } else {
                                if (features[2] <= -16) {
                                    if (features[0] <= -70) {
                                        if (features[2] <= -110) {
                                            if (features[7] <= -258) {
                                                return 1;
                                            } else {
                                                if (features[7] <= 59) {
                                                    return 4;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            if (features[6] <= -115) {
                                                return 0;
                                            } else {
                                                if (features[1] <= -70) {
                                                    return 4;
                                                } else {
                                                    result[0] = 0.25;

                                                    result[4] = 0.75;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[7] <= -75) {
                                            if (features[6] <= -183) {
                                                if (features[5] <= -152) {
                                                    return 1;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            if (features[2] <= -38) {
                                                return 1;
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[0] <= -118) {
                                        if (features[6] <= -211) {
                                            return 3;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[3] <= -77) {
                                            if (features[8] <= -159) {
                                                return 4;
                                            } else {
                                                if (features[5] <= -35) {
                                                    return 1;
                                                } else {
                                                    result[0] = 0.6666666666666666;

                                                    result[1] = 0.3333333333333333;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[6] <= -16) {
                                                if (features[1] <= 76) {
                                                    return 3;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[0] <= 0) {
                                                    return 3;
                                                } else {
                                                    return 1;

                                                }

                                            }

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[1] <= 6) {
                            if (features[3] <= -25) {
                                return 3;
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[3] <= -381) {
                                return 0;
                            } else {
                                if (features[2] <= 122) {
                                    return 2;
                                } else {
                                    return 3;

                                }

                            }

                        }

                    }
                } else {
                    if (features[8] <= 772) {
                        if (features[0] <= -14) {
                            if (features[3] <= -114) {
                                return 1;
                            } else {
                                if (features[9] <= 20) {
                                    return 3;
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[5] <= 24) {
                                if (features[8] <= 320) {
                                    return 1;
                                } else {
                                    if (features[7] <= 2442) {
                                        return 1;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[3] <= -515) {
                            return 1;
                        } else {
                            return 2;

                        }

                    }

                }
            } else {
                if (features[0] <= -114) {
                    if (features[0] <= -736) {
                        return 0;
                    } else {
                        if (features[8] <= -28) {
                            if (features[5] <= -144) {
                                if (features[6] <= 92) {
                                    if (features[2] <= -86) {
                                        if (features[6] <= -152) {
                                            return 1;
                                        } else {
                                            if (features[3] <= 448) {
                                                return 4;
                                            } else {
                                                return 0;

                                            }

                                        }
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[0] <= -156) {
                                        return 3;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                if (features[8] <= -1378) {
                                    return 3;
                                } else {
                                    if (features[8] <= -44) {
                                        if (features[6] <= -142) {
                                            if (features[0] <= -182) {
                                                return 4;
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[3] <= 484) {
                                            return 4;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[5] <= -28) {
                                if (features[6] <= -1578) {
                                    return 2;
                                } else {
                                    if (features[8] <= 334) {
                                        return 0;
                                    } else {
                                        if (features[3] <= 148) {
                                            return 3;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 140) {
                                    return 4;
                                } else {
                                    if (features[4] <= 374) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[3] <= 746) {
                        if (features[8] <= 285) {
                            if (features[6] <= 136) {
                                if (features[3] <= 28) {
                                    if (features[2] <= 194) {
                                        if (features[1] <= 3) {
                                            if (features[6] <= -250) {
                                                if (features[3] <= 2) {
                                                    return 2;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[2] <= -54) {
                                                    result[2] = 0.2;

                                                    result[3] = 0.8;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            if (features[6] <= -656) {
                                                return 2;
                                            } else {
                                                if (features[9] <= 4) {
                                                    result[1] = 0.782608695652174;

                                                    result[2] = 0.043478260869565216;

                                                    result[3] = 0.17391304347826086;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.14285714285714285;

                                                    result[2] = 0.5714285714285714;

                                                    result[3] = 0.2857142857142857;

                                                    return 255;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[8] <= 50) {
                                            if (features[1] <= -64) {
                                                if (features[7] <= 475) {
                                                    return 0;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                if (features[7] <= 412) {
                                                    result[1] = 0.3333333333333333;

                                                    result[3] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }

                                            }
                                        } else {
                                            return 2;

                                        }

                                    }
                                } else {
                                    if (features[9] <= -187) {
                                        return 2;
                                    } else {
                                        if (features[1] <= -4) {
                                            if (features[5] <= -5) {
                                                if (features[1] <= -186) {
                                                    return 0;
                                                } else {
                                                    result[0] = 0.35714285714285715;

                                                    result[1] = 0.6428571428571429;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[8] <= -4) {
                                                    return 4;
                                                } else {
                                                    return 0;

                                                }

                                            }
                                        } else {
                                            if (features[4] <= 81) {
                                                if (features[0] <= 68) {
                                                    return 3;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[8] <= 28) {
                                                    return 0;
                                                } else {
                                                    return 2;

                                                }

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 328) {
                                    if (features[3] <= 154) {
                                        return 3;
                                    } else {
                                        if (features[8] <= 12) {
                                            return 2;
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    return 3;

                                }

                            }
                        } else {
                            if (features[6] <= -995) {
                                return 2;
                            } else {
                                if (features[3] <= 450) {
                                    if (features[1] <= -1369) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[6] <= -1268) {
                            return 2;
                        } else {
                            if (features[6] <= 1926) {
                                return 0;
                            } else {
                                return 3;

                            }

                        }

                    }

                }

            }
        } else {
            if (features[8] <= 36) {
                if (features[7] <= 27) {
                    if (features[0] <= -345) {
                        if (features[4] <= 572) {
                            return 4;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[1] <= -6) {
                            if (features[7] <= 6) {
                                if (features[2] <= -191) {
                                    if (features[2] <= -234) {
                                        return 3;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[3] <= 1026) {
                                        if (features[7] <= -0) {
                                            return 3;
                                        } else {
                                            if (features[1] <= -18) {
                                                return 3;
                                            } else {
                                                if (features[0] <= -34) {
                                                    return 4;
                                                } else {
                                                    return 3;

                                                }

                                            }

                                        }
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[1] <= -48) {
                                    if (features[1] <= -568) {
                                        return 1;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[5] <= 84) {
                                        return 0;
                                    } else {
                                        if (features[9] <= -1) {
                                            if (features[0] <= -28) {
                                                if (features[7] <= 12) {
                                                    return 3;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            return 4;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[9] <= -128) {
                                if (features[9] <= -366) {
                                    return 3;
                                } else {
                                    if (features[5] <= 270) {
                                        if (features[1] <= 10) {
                                            if (features[7] <= -96) {
                                                return 2;
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            if (features[9] <= -262) {
                                                return 3;
                                            } else {
                                                if (features[6] <= 1189) {
                                                    return 2;
                                                } else {
                                                    return 3;

                                                }

                                            }

                                        }
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[5] <= 122) {
                                    if (features[2] <= -16) {
                                        if (features[9] <= -26) {
                                            return 2;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[3] <= 59) {
                                        if (features[7] <= -2) {
                                            if (features[6] <= 135) {
                                                return 3;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[3] <= -408) {
                                                return 0;
                                            } else {
                                                if (features[6] <= 12) {
                                                    return 3;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[9] <= -21) {
                                            if (features[5] <= 214) {
                                                return 3;
                                            } else {
                                                if (features[7] <= -112) {
                                                    return 4;
                                                } else {
                                                    return 2;

                                                }

                                            }
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 347) {
                        if (features[2] <= -122) {
                            if (features[7] <= 286) {
                                if (features[7] <= 187) {
                                    return 0;
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[5] <= 314) {
                                    return 3;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[8] <= -292) {
                                if (features[4] <= -234) {
                                    if (features[9] <= -110) {
                                        return 4;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[3] <= 532) {
                                        if (features[1] <= 45) {
                                            if (features[2] <= 68) {
                                                if (features[2] <= -53) {
                                                    result[3] = 0.75;

                                                    result[4] = 0.25;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                if (features[6] <= 1856) {
                                                    return 4;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[3] <= 268) {
                                    if (features[5] <= 122) {
                                        if (features[4] <= 18) {
                                            return 4;
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[9] <= 6) {
                                        return 0;
                                    } else {
                                        if (features[5] <= 262) {
                                            return 1;
                                        } else {
                                            return 4;

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[3] <= 548) {
                            if (features[9] <= 3) {
                                return 1;
                            } else {
                                return 0;

                            }
                        } else {
                            return 3;

                        }

                    }

                }
            } else {
                if (features[2] <= 164) {
                    if (features[3] <= -216) {
                        if (features[7] <= 7) {
                            return 1;
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[3] <= 176) {
                            return 4;
                        } else {
                            if (features[4] <= 478) {
                                return 1;
                            } else {
                                return 0;

                            }

                        }

                    }
                } else {
                    return 1;

                }

            }

        }
    } else {
        if (features[9] <= 254) {
            if (features[0] <= 70) {
                if (features[0] <= -172) {
                    if (features[6] <= 310) {
                        if (features[6] <= -387) {
                            if (features[6] <= -524) {
                                return 0;
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[3] <= -52) {
                                return 4;
                            } else {
                                return 0;

                            }

                        }
                    } else {
                        if (features[6] <= 710) {
                            if (features[7] <= 92) {
                                if (features[9] <= 132) {
                                    return 1;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            return 4;

                        }

                    }
                } else {
                    if (features[4] <= 48) {
                        if (features[5] <= 114) {
                            if (features[5] <= 48) {
                                if (features[6] <= 14) {
                                    if (features[3] <= 12) {
                                        if (features[3] <= -808) {
                                            return 1;
                                        } else {
                                            if (features[5] <= -100) {
                                                if (features[8] <= 491) {
                                                    result[0] = 0.2916666666666667;

                                                    result[1] = 0.041666666666666664;

                                                    result[2] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }
                                    } else {
                                        if (features[2] <= 1) {
                                            return 3;
                                        } else {
                                            if (features[7] <= -127) {
                                                return 0;
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[2] <= 29) {
                                        return 1;
                                    } else {
                                        if (features[2] <= 34) {
                                            return 2;
                                        } else {
                                            return 0;

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= 36) {
                                    if (features[1] <= 12) {
                                        if (features[1] <= -148) {
                                            if (features[8] <= 52) {
                                                return 1;
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            if (features[4] <= 26) {
                                                if (features[7] <= 48) {
                                                    return 3;
                                                } else {
                                                    result[2] = 0.8125;

                                                    result[3] = 0.1875;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= -22) {
                                                    result[3] = 0.2;

                                                    result[4] = 0.8;

                                                    return 255;
                                                } else {
                                                    return 3;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[6] <= 120) {
                                            if (features[3] <= 2) {
                                                return 2;
                                            } else {
                                                if (features[1] <= 24) {
                                                    return 3;
                                                } else {
                                                    result[1] = 0.16666666666666666;

                                                    result[2] = 0.8333333333333334;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[7] <= 172) {
                                                return 0;
                                            } else {
                                                return 1;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[1] <= 11) {
                                        if (features[3] <= 212) {
                                            return 3;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 4;

                                    }

                                }

                            }
                        } else {
                            if (features[4] <= 22) {
                                if (features[9] <= 124) {
                                    if (features[1] <= -20) {
                                        if (features[0] <= 2) {
                                            if (features[8] <= -344) {
                                                return 3;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[4] <= 18) {
                                                if (features[9] <= 56) {
                                                    return 4;
                                                } else {
                                                    result[3] = 0.8571428571428571;

                                                    result[4] = 0.14285714285714285;

                                                    return 255;

                                                }
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[0] <= 41) {
                                            if (features[9] <= 67) {
                                                if (features[4] <= -158) {
                                                    return 1;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[6] <= 213) {
                                                return 2;
                                            } else {
                                                return 4;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[5] <= 238) {
                                        return 2;
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                if (features[1] <= -38) {
                                    if (features[6] <= 84) {
                                        return 2;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[8] <= -124) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[5] <= 100) {
                            if (features[4] <= 72) {
                                if (features[7] <= 28) {
                                    if (features[6] <= -176) {
                                        return 2;
                                    } else {
                                        if (features[9] <= 80) {
                                            return 0;
                                        } else {
                                            if (features[6] <= 80) {
                                                return 2;
                                            } else {
                                                return 1;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[2] <= 13) {
                                        if (features[8] <= 108) {
                                            if (features[5] <= 66) {
                                                return 1;
                                            } else {
                                                if (features[9] <= 76) {
                                                    return 3;
                                                } else {
                                                    result[1] = 0.5;

                                                    result[3] = 0.5;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            return 2;

                                        }
                                    } else {
                                        if (features[7] <= 172) {
                                            if (features[6] <= 118) {
                                                return 0;
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            if (features[3] <= 15) {
                                                return 1;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[5] <= -212) {
                                    return 2;
                                } else {
                                    if (features[8] <= 25) {
                                        if (features[3] <= 83) {
                                            if (features[9] <= 75) {
                                                return 0;
                                            } else {
                                                return 3;

                                            }
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[2] <= 45) {
                                            if (features[4] <= 86) {
                                                if (features[3] <= 82) {
                                                    return 3;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 78) {
                                if (features[0] <= 30) {
                                    return 1;
                                } else {
                                    if (features[0] <= 54) {
                                        if (features[0] <= 50) {
                                            return 4;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        return 3;

                                    }

                                }
                            } else {
                                if (features[9] <= 96) {
                                    if (features[9] <= 76) {
                                        if (features[7] <= 157) {
                                            return 1;
                                        } else {
                                            if (features[4] <= 172) {
                                                return 0;
                                            } else {
                                                return 1;

                                            }

                                        }
                                    } else {
                                        if (features[5] <= 360) {
                                            return 1;
                                        } else {
                                            return 4;

                                        }

                                    }
                                } else {
                                    if (features[1] <= 50) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[2] <= -10) {
                    if (features[5] <= 64) {
                        if (features[1] <= 841) {
                            if (features[7] <= 34) {
                                return 1;
                            } else {
                                if (features[9] <= 134) {
                                    return 0;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[3] <= -52) {
                            if (features[9] <= 123) {
                                if (features[9] <= 72) {
                                    if (features[7] <= 208) {
                                        return 0;
                                    } else {
                                        if (features[7] <= 270) {
                                            if (features[8] <= -7) {
                                                return 0;
                                            } else {
                                                return 1;

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[4] <= 204) {
                                if (features[5] <= 98) {
                                    if (features[1] <= 152) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[3] <= -48) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                return 4;

                            }

                        }

                    }
                } else {
                    if (features[4] <= -97) {
                        return 1;
                    } else {
                        if (features[1] <= 49) {
                            if (features[8] <= 32) {
                                return 3;
                            } else {
                                if (features[7] <= 7) {
                                    return 3;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[5] <= 62) {
                                if (features[7] <= 8) {
                                    if (features[5] <= -21) {
                                        return 3;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 2;

                                }
                            } else {
                                if (features[6] <= 332) {
                                    if (features[2] <= 2) {
                                        if (features[9] <= 100) {
                                            if (features[7] <= 44) {
                                                return 0;
                                            } else {
                                                if (features[6] <= 220) {
                                                    return 1;
                                                } else {
                                                    return 0;

                                                }

                                            }
                                        } else {
                                            if (features[7] <= -90) {
                                                return 4;
                                            } else {
                                                return 1;

                                            }

                                        }
                                    } else {
                                        if (features[4] <= 105) {
                                            if (features[6] <= 86) {
                                                if (features[4] <= 40) {
                                                    return 1;
                                                } else {
                                                    result[0] = 0.2;

                                                    result[2] = 0.8;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[2] <= 30) {
                                                    result[1] = 0.9333333333333333;

                                                    result[2] = 0.06666666666666667;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            if (features[0] <= 120) {
                                                return 0;
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[3] <= -272) {
                                        return 0;
                                    } else {
                                        if (features[9] <= 77) {
                                            return 4;
                                        } else {
                                            return 3;

                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[5] <= 280) {
                if (features[9] <= 565) {
                    if (features[6] <= -349) {
                        if (features[0] <= -229) {
                            return 4;
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[4] <= -226) {
                            return 1;
                        } else {
                            if (features[5] <= -192) {
                                if (features[3] <= 4) {
                                    return 2;
                                } else {
                                    if (features[3] <= 6) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }

                                }
                            } else {
                                return 0;

                            }

                        }

                    }
                } else {
                    return 2;

                }
            } else {
                return 4;

            }

        }

    }
}

unsigned char tree2(short* features, float* result){
    if (features[3] <= -564) {
        if (features[4] <= 2) {
            if (features[1] <= 70) {
                if (features[0] <= -29) {
                    if (features[3] <= -1284) {
                        return 1;
                    } else {
                        if (features[5] <= -102) {
                            return 2;
                        } else {
                            return 4;

                        }

                    }
                } else {
                    return 1;

                }
            } else {
                if (features[5] <= 258) {
                    if (features[8] <= 2375) {
                        return 1;
                    } else {
                        return 2;

                    }
                } else {
                    if (features[7] <= 110) {
                        return 1;
                    } else {
                        return 0;

                    }

                }

            }
        } else {
            if (features[9] <= 4) {
                return 1;
            } else {
                if (features[5] <= 87) {
                    if (features[5] <= 52) {
                        return 1;
                    } else {
                        if (features[9] <= 88) {
                            return 1;
                        } else {
                            return 0;

                        }

                    }
                } else {
                    return 0;

                }

            }

        }
    } else {
        if (features[8] <= 30) {
            if (features[5] <= -116) {
                if (features[0] <= -98) {
                    if (features[8] <= -40) {
                        if (features[6] <= -130) {
                            if (features[5] <= -140) {
                                if (features[1] <= -106) {
                                    return 0;
                                } else {
                                    return 3;

                                }
                            } else {
                                if (features[4] <= 153) {
                                    return 1;
                                } else {
                                    return 4;

                                }

                            }
                        } else {
                            if (features[0] <= -252) {
                                if (features[4] <= 170) {
                                    return 4;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 2;

                            }

                        }
                    } else {
                        if (features[4] <= 182) {
                            if (features[0] <= -523) {
                                return 4;
                            } else {
                                if (features[9] <= 179) {
                                    return 0;
                                } else {
                                    return 2;

                                }

                            }
                        } else {
                            if (features[7] <= 6) {
                                return 0;
                            } else {
                                if (features[3] <= -0) {
                                    return 2;
                                } else {
                                    return 0;

                                }

                            }

                        }

                    }
                } else {
                    if (features[4] <= -111) {
                        if (features[6] <= -134) {
                            if (features[3] <= -399) {
                                if (features[8] <= -252) {
                                    return 0;
                                } else {
                                    if (features[4] <= -890) {
                                        return 1;
                                    } else {
                                        return 4;

                                    }

                                }
                            } else {
                                return 1;

                            }
                        } else {
                            return 1;

                        }
                    } else {
                        if (features[9] <= 99) {
                            if (features[2] <= 202) {
                                if (features[8] <= 0) {
                                    if (features[2] <= 2) {
                                        if (features[1] <= 10) {
                                            return 2;
                                        } else {
                                            if (features[6] <= -53) {
                                                return 3;
                                            } else {
                                                return 1;

                                            }

                                        }
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 3;

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            return 2;

                        }

                    }

                }
            } else {
                if (features[0] <= -104) {
                    if (features[5] <= 90) {
                        if (features[3] <= 952) {
                            if (features[4] <= 70) {
                                if (features[8] <= -1272) {
                                    return 3;
                                } else {
                                    if (features[6] <= 85) {
                                        if (features[9] <= -330) {
                                            if (features[2] <= -26) {
                                                return 4;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[0] <= -157) {
                                            return 1;
                                        } else {
                                            return 2;

                                        }

                                    }

                                }
                            } else {
                                if (features[1] <= -170) {
                                    if (features[0] <= -258) {
                                        return 4;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    if (features[3] <= 45) {
                                        return 0;
                                    } else {
                                        if (features[2] <= -38) {
                                            if (features[1] <= -140) {
                                                return 1;
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[6] <= 7) {
                                                return 1;
                                            } else {
                                                return 0;

                                            }

                                        }

                                    }

                                }

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[9] <= 25) {
                            if (features[0] <= -341) {
                                return 0;
                            } else {
                                if (features[3] <= 2304) {
                                    return 3;
                                } else {
                                    return 0;

                                }

                            }
                        } else {
                            if (features[4] <= -41) {
                                return 4;
                            } else {
                                return 1;

                            }

                        }

                    }
                } else {
                    if (features[9] <= -126) {
                        if (features[5] <= 272) {
                            if (features[8] <= -482) {
                                return 3;
                            } else {
                                if (features[1] <= 10) {
                                    if (features[3] <= 193) {
                                        if (features[5] <= 42) {
                                            if (features[1] <= -6) {
                                                return 3;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            return 3;

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[4] <= 146) {
                                        if (features[6] <= 302) {
                                            return 2;
                                        } else {
                                            if (features[2] <= -76) {
                                                return 2;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        return 3;

                                    }

                                }

                            }
                        } else {
                            if (features[8] <= 16) {
                                if (features[6] <= 422) {
                                    if (features[7] <= 34) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    if (features[9] <= -328) {
                                        if (features[1] <= 206) {
                                            return 3;
                                        } else {
                                            return 4;

                                        }
                                    } else {
                                        if (features[4] <= -120) {
                                            return 4;
                                        } else {
                                            if (features[5] <= 528) {
                                                return 3;
                                            } else {
                                                if (features[0] <= -16) {
                                                    result[3] = 0.5714285714285714;

                                                    result[4] = 0.42857142857142855;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }

                                    }

                                }
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        if (features[1] <= -630) {
                            if (features[9] <= 16) {
                                return 0;
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[0] <= 102) {
                                if (features[5] <= 110) {
                                    if (features[8] <= 0) {
                                        if (features[6] <= -24) {
                                            if (features[2] <= 2) {
                                                if (features[0] <= -58) {
                                                    return 4;
                                                } else {
                                                    result[1] = 0.875;

                                                    result[2] = 0.125;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[7] <= 426) {
                                                    result[0] = 0.25;

                                                    result[2] = 0.75;

                                                    return 255;
                                                } else {
                                                    return 2;

                                                }

                                            }
                                        } else {
                                            if (features[3] <= -23) {
                                                if (features[6] <= 181) {
                                                    result[0] = 0.38461538461538464;

                                                    result[1] = 0.6153846153846154;

                                                    return 255;
                                                } else {
                                                    result[2] = 0.16666666666666666;

                                                    result[3] = 0.75;

                                                    result[4] = 0.08333333333333333;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[0] <= 76) {
                                                    result[0] = 0.007246376811594203;

                                                    result[1] = 0.050724637681159424;

                                                    result[2] = 0.007246376811594203;

                                                    result[3] = 0.9347826086956522;

                                                    return 255;
                                                } else {
                                                    return 1;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[6] <= 22) {
                                            if (features[0] <= 16) {
                                                if (features[4] <= -15) {
                                                    result[1] = 0.3333333333333333;

                                                    result[4] = 0.6666666666666666;

                                                    return 255;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                if (features[5] <= -108) {
                                                    return 3;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            if (features[0] <= 13) {
                                                if (features[5] <= 67) {
                                                    return 0;
                                                } else {
                                                    result[1] = 0.6;

                                                    result[4] = 0.4;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[4] <= 12) {
                                                    return 1;
                                                } else {
                                                    result[1] = 0.3333333333333333;

                                                    result[3] = 0.6666666666666666;

                                                    return 255;

                                                }

                                            }

                                        }

                                    }
                                } else {
                                    if (features[8] <= -54) {
                                        if (features[4] <= 6) {
                                            if (features[9] <= -31) {
                                                if (features[4] <= -101) {
                                                    return 4;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                if (features[0] <= 8) {
                                                    return 4;
                                                } else {
                                                    result[3] = 0.2;

                                                    result[4] = 0.8;

                                                    return 255;

                                                }

                                            }
                                        } else {
                                            if (features[5] <= 490) {
                                                if (features[7] <= 100) {
                                                    result[2] = 0.006622516556291391;

                                                    result[3] = 0.9536423841059603;

                                                    result[4] = 0.039735099337748346;

                                                    return 255;
                                                } else {
                                                    result[1] = 0.1111111111111111;

                                                    result[3] = 0.1111111111111111;

                                                    result[4] = 0.7777777777777778;

                                                    return 255;

                                                }
                                            } else {
                                                return 4;

                                            }

                                        }
                                    } else {
                                        if (features[6] <= 192) {
                                            if (features[3] <= 110) {
                                                if (features[7] <= 8) {
                                                    result[1] = 0.034482758620689655;

                                                    result[3] = 0.13793103448275862;

                                                    result[4] = 0.8275862068965517;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                if (features[6] <= -103) {
                                                    return 4;
                                                } else {
                                                    return 1;

                                                }

                                            }
                                        } else {
                                            if (features[4] <= 67) {
                                                if (features[0] <= -5) {
                                                    return 4;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                if (features[9] <= -32) {
                                                    return 4;
                                                } else {
                                                    return 1;

                                                }

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[6] <= 222) {
                                    if (features[3] <= 76) {
                                        if (features[9] <= -88) {
                                            return 0;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        if (features[7] <= 32) {
                                            return 3;
                                        } else {
                                            return 2;

                                        }

                                    }
                                } else {
                                    if (features[4] <= 6) {
                                        return 3;
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }

                }

            }
        } else {
            if (features[3] <= 112) {
                if (features[5] <= 84) {
                    if (features[6] <= 48) {
                        if (features[0] <= -223) {
                            if (features[7] <= 66) {
                                if (features[1] <= -150) {
                                    if (features[4] <= 368) {
                                        return 4;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 0;

                                }
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[8] <= 285) {
                                if (features[4] <= 1) {
                                    if (features[1] <= 110) {
                                        if (features[6] <= -253) {
                                            return 2;
                                        } else {
                                            if (features[0] <= 50) {
                                                if (features[6] <= -78) {
                                                    result[0] = 0.07142857142857142;

                                                    result[3] = 0.9285714285714286;

                                                    return 255;
                                                } else {
                                                    result[2] = 0.84;

                                                    result[3] = 0.16;

                                                    return 255;

                                                }
                                            } else {
                                                if (features[3] <= -6) {
                                                    return 1;
                                                } else {
                                                    return 3;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[3] <= -34) {
                                            if (features[7] <= 92) {
                                                return 1;
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            if (features[4] <= -17) {
                                                return 2;
                                            } else {
                                                return 3;

                                            }

                                        }

                                    }
                                } else {
                                    if (features[9] <= -12) {
                                        if (features[5] <= -230) {
                                            return 0;
                                        } else {
                                            if (features[3] <= -163) {
                                                return 1;
                                            } else {
                                                return 3;

                                            }

                                        }
                                    } else {
                                        if (features[3] <= 60) {
                                            if (features[9] <= 56) {
                                                if (features[5] <= -27) {
                                                    return 0;
                                                } else {
                                                    return 2;

                                                }
                                            } else {
                                                return 2;

                                            }
                                        } else {
                                            if (features[6] <= -6) {
                                                if (features[7] <= -2) {
                                                    return 2;
                                                } else {
                                                    return 3;

                                                }
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }

                                }
                            } else {
                                if (features[3] <= -332) {
                                    if (features[5] <= -186) {
                                        return 2;
                                    } else {
                                        if (features[6] <= -130) {
                                            if (features[7] <= 24) {
                                                if (features[2] <= -106) {
                                                    return 2;
                                                } else {
                                                    return 1;

                                                }
                                            } else {
                                                if (features[2] <= -456) {
                                                    return 1;
                                                } else {
                                                    return 2;

                                                }

                                            }
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    if (features[0] <= 197) {
                                        return 2;
                                    } else {
                                        if (features[5] <= -376) {
                                            return 2;
                                        } else {
                                            if (features[1] <= 106) {
                                                return 1;
                                            } else {
                                                return 2;

                                            }

                                        }

                                    }

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 28) {
                            if (features[4] <= 14) {
                                if (features[7] <= 63) {
                                    if (features[1] <= -53) {
                                        return 4;
                                    } else {
                                        return 3;

                                    }
                                } else {
                                    if (features[7] <= 230) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[7] <= 74) {
                                if (features[6] <= 102) {
                                    return 0;
                                } else {
                                    if (features[3] <= -18) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }

                                }
                            } else {
                                if (features[6] <= 119) {
                                    if (features[3] <= -73) {
                                        if (features[3] <= -110) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    if (features[6] <= 280) {
                                        if (features[3] <= 58) {
                                            return 1;
                                        } else {
                                            return 0;

                                        }
                                    } else {
                                        return 0;

                                    }

                                }

                            }

                        }

                    }
                } else {
                    if (features[1] <= 70) {
                        if (features[9] <= 157) {
                            if (features[7] <= 52) {
                                if (features[4] <= 40) {
                                    if (features[5] <= 118) {
                                        return 3;
                                    } else {
                                        return 4;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[6] <= 106) {
                                    return 2;
                                } else {
                                    if (features[4] <= 46) {
                                        if (features[0] <= 2) {
                                            if (features[1] <= -137) {
                                                if (features[1] <= -144) {
                                                    return 4;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                return 4;

                                            }
                                        } else {
                                            if (features[5] <= 110) {
                                                if (features[6] <= 120) {
                                                    return 2;
                                                } else {
                                                    return 4;

                                                }
                                            } else {
                                                if (features[8] <= 108) {
                                                    result[3] = 0.5714285714285714;

                                                    result[4] = 0.42857142857142855;

                                                    return 255;
                                                } else {
                                                    return 4;

                                                }

                                            }

                                        }
                                    } else {
                                        if (features[9] <= 90) {
                                            if (features[1] <= -14) {
                                                return 1;
                                            } else {
                                                if (features[7] <= 96) {
                                                    return 4;
                                                } else {
                                                    return 3;

                                                }

                                            }
                                        } else {
                                            return 0;

                                        }

                                    }

                                }

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[0] <= 66) {
                            if (features[3] <= -44) {
                                if (features[1] <= 134) {
                                    return 2;
                                } else {
                                    return 0;

                                }
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[2] <= -0) {
                                if (features[3] <= -21) {
                                    if (features[0] <= 122) {
                                        return 0;
                                    } else {
                                        if (features[9] <= 114) {
                                            if (features[8] <= 61) {
                                                if (features[5] <= 144) {
                                                    return 1;
                                                } else {
                                                    return 0;

                                                }
                                            } else {
                                                return 0;

                                            }
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[4] <= 14) {
                                    if (features[6] <= 310) {
                                        if (features[0] <= 160) {
                                            return 0;
                                        } else {
                                            return 1;

                                        }
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    if (features[5] <= 246) {
                                        return 1;
                                    } else {
                                        return 4;

                                    }

                                }

                            }

                        }

                    }

                }
            } else {
                if (features[6] <= 81) {
                    if (features[8] <= 617) {
                        if (features[1] <= 2) {
                            if (features[3] <= 473) {
                                if (features[6] <= -588) {
                                    return 2;
                                } else {
                                    if (features[5] <= -546) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[3] <= 132) {
                                return 3;
                            } else {
                                if (features[8] <= 150) {
                                    if (features[0] <= 105) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 2;

                                }

                            }

                        }
                    } else {
                        if (features[5] <= -272) {
                            return 2;
                        } else {
                            if (features[1] <= -462) {
                                return 0;
                            } else {
                                return 2;

                            }

                        }

                    }
                } else {
                    if (features[9] <= 100) {
                        if (features[7] <= 157) {
                            if (features[3] <= 918) {
                                if (features[4] <= 124) {
                                    if (features[0] <= 56) {
                                        return 1;
                                    } else {
                                        if (features[5] <= 85) {
                                            return 0;
                                        } else {
                                            return 1;

                                        }

                                    }
                                } else {
                                    if (features[1] <= -156) {
                                        return 1;
                                    } else {
                                        return 0;

                                    }

                                }
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[8] <= 154) {
                                if (features[5] <= 112) {
                                    if (features[8] <= 43) {
                                        return 2;
                                    } else {
                                        return 0;

                                    }
                                } else {
                                    return 1;

                                }
                            } else {
                                if (features[5] <= -6) {
                                    return 1;
                                } else {
                                    return 0;

                                }

                            }

                        }
                    } else {
                        if (features[0] <= 0) {
                            if (features[0] <= -272) {
                                return 0;
                            } else {
                                if (features[5] <= 111) {
                                    if (features[6] <= 310) {
                                        return 0;
                                    } else {
                                        return 1;

                                    }
                                } else {
                                    return 1;

                                }

                            }
                        } else {
                            if (features[1] <= 48) {
                                return 0;
                            } else {
                                if (features[4] <= 234) {
                                    if (features[2] <= 172) {
                                        return 0;
                                    } else {
                                        return 2;

                                    }
                                } else {
                                    return 4;

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree3(float* features, float* result){
    if (features[0] <= 0.049951250) {
        if (features[5] <= 0.045717433) {
            if (features[9] <= 0.021093744) {
                if (features[1] <= -0.019714064) {
                    if (features[6] <= 0.077058632) {
                        if (features[8] <= 0.223897018) {
                            if (features[1] <= -0.121542040) {
                                result[1] = 0.9951923076923077;

                                result[4] = 0.004807692307692308;

                                return 255;
                            } else {
                                result[0] = 0.0364963503649635;

                                result[1] = 0.7299270072992701;

                                result[2] = 0.16058394160583941;

                                result[3] = 0.043795620437956206;

                                result[4] = 0.029197080291970802;

                                return 255;

                            }
                        } else {
                            if (features[3] <= 0.032661647) {
                                return 2;
                            } else {
                                result[1] = 0.5833333333333334;

                                result[2] = 0.4166666666666667;

                                return 255;

                            }

                        }
                    } else {
                        if (features[9] <= 0.001320219) {
                            result[1] = 0.125;

                            result[3] = 0.875;

                            return 255;
                        } else {
                            if (features[7] <= 0.081318241) {
                                result[0] = 0.7777777777777778;

                                result[1] = 0.2222222222222222;

                                return 255;
                            } else {
                                result[0] = 0.9841269841269841;

                                result[3] = 0.015873015873015872;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[1] <= 0.119850203) {
                        if (features[6] <= -0.058903662) {
                            if (features[5] <= -0.012477405) {
                                result[1] = 0.23076923076923078;

                                result[2] = 0.6923076923076923;

                                result[3] = 0.07692307692307693;

                                return 255;
                            } else {
                                result[0] = 0.01694915254237288;

                                result[2] = 0.9830508474576272;

                                return 255;

                            }
                        } else {
                            if (features[8] <= -0.065018296) {
                                result[1] = 0.009259259259259259;

                                result[3] = 0.9907407407407407;

                                return 255;
                            } else {
                                result[0] = 0.21717171717171718;

                                result[1] = 0.25252525252525254;

                                result[2] = 0.16666666666666666;

                                result[3] = 0.35353535353535354;

                                result[4] = 0.010101010101010102;

                                return 255;

                            }

                        }
                    } else {
                        if (features[5] <= 0.017949643) {
                            if (features[3] <= -0.044761665) {
                                result[0] = 0.9627329192546584;

                                result[1] = 0.006211180124223602;

                                result[3] = 0.031055900621118012;

                                return 255;
                            } else {
                                result[0] = 0.18181818181818182;

                                result[2] = 0.5454545454545454;

                                result[3] = 0.09090909090909091;

                                result[4] = 0.18181818181818182;

                                return 255;

                            }
                        } else {
                            return 1;

                        }

                    }

                }
            } else {
                if (features[4] <= 0.027042796) {
                    if (features[6] <= 0.018492258) {
                        if (features[0] <= 0.033566460) {
                            if (features[9] <= 0.025237929) {
                                result[2] = 0.85;

                                result[3] = 0.15;

                                return 255;
                            } else {
                                return 2;

                            }
                        } else {
                            result[0] = 0.3333333333333333;

                            result[2] = 0.6666666666666666;

                            return 255;

                        }
                    } else {
                        if (features[0] <= -0.006219687) {
                            if (features[4] <= -0.012296113) {
                                result[0] = 0.03225806451612903;

                                result[2] = 0.3870967741935484;

                                result[3] = 0.5806451612903226;

                                return 255;
                            } else {
                                result[1] = 0.09523809523809523;

                                result[2] = 0.9047619047619048;

                                return 255;

                            }
                        } else {
                            if (features[5] <= 0.021270480) {
                                result[0] = 0.6153846153846154;

                                result[2] = 0.23076923076923078;

                                result[3] = 0.15384615384615385;

                                return 255;
                            } else {
                                return 3;

                            }

                        }

                    }
                } else {
                    if (features[0] <= -0.019945779) {
                        if (features[4] <= 0.034998490) {
                            result[1] = 0.9166666666666666;

                            result[2] = 0.08333333333333333;

                            return 255;
                        } else {
                            return 1;

                        }
                    } else {
                        result[1] = 0.07692307692307693;

                        result[2] = 0.9230769230769231;

                        return 255;

                    }

                }

            }
        } else {
            if (features[8] <= -0.011057606) {
                if (features[7] <= 0.023407105) {
                    if (features[6] <= -0.038122624) {
                        result[3] = 0.1875;

                        result[4] = 0.8125;

                        return 255;
                    } else {
                        if (features[4] <= -0.003690090) {
                            if (features[8] <= -0.029222609) {
                                return 3;
                            } else {
                                result[0] = 0.1;

                                result[3] = 0.9;

                                return 255;

                            }
                        } else {
                            if (features[9] <= -0.029521707) {
                                return 3;
                            } else {
                                result[3] = 0.8;

                                result[4] = 0.2;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[8] <= -0.477819622) {
                        return 3;
                    } else {
                        if (features[7] <= 0.117514201) {
                            if (features[4] <= -0.007807415) {
                                result[3] = 0.9032258064516129;

                                result[4] = 0.0967741935483871;

                                return 255;
                            } else {
                                result[3] = 0.21951219512195122;

                                result[4] = 0.7804878048780488;

                                return 255;

                            }
                        } else {
                            if (features[4] <= 0.011247475) {
                                result[0] = 0.02127659574468085;

                                result[4] = 0.9787234042553191;

                                return 255;
                            } else {
                                result[3] = 0.23809523809523808;

                                result[4] = 0.7619047619047619;

                                return 255;

                            }

                        }

                    }

                }
            } else {
                if (features[0] <= -0.036810309) {
                    if (features[2] <= -0.029307324) {
                        if (features[4] <= -0.046579584) {
                            if (features[1] <= -0.042518619) {
                                result[3] = 0.3076923076923077;

                                result[4] = 0.6923076923076923;

                                return 255;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[7] <= 0.092070639) {
                                result[1] = 0.9772727272727273;

                                result[4] = 0.022727272727272728;

                                return 255;
                            } else {
                                result[0] = 0.3125;

                                result[1] = 0.6875;

                                return 255;

                            }

                        }
                    } else {
                        if (features[4] <= -0.031925540) {
                            if (features[5] <= 0.065561917) {
                                result[0] = 0.23076923076923078;

                                result[1] = 0.7692307692307693;

                                return 255;
                            } else {
                                result[0] = 0.9166666666666666;

                                result[4] = 0.08333333333333333;

                                return 255;

                            }
                        } else {
                            if (features[6] <= 0.130037323) {
                                result[0] = 0.75;

                                result[3] = 0.125;

                                result[4] = 0.125;

                                return 255;
                            } else {
                                return 0;

                            }

                        }

                    }
                } else {
                    if (features[4] <= -0.027391119) {
                        if (features[1] <= 0.051346838) {
                            if (features[6] <= 0.196022943) {
                                result[0] = 0.75;

                                result[3] = 0.16666666666666666;

                                result[4] = 0.08333333333333333;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            if (features[7] <= 0.071744099) {
                                result[0] = 0.7333333333333333;

                                result[1] = 0.2;

                                result[3] = 0.06666666666666667;

                                return 255;
                            } else {
                                result[0] = 0.08737864077669903;

                                result[1] = 0.912621359223301;

                                return 255;

                            }

                        }
                    } else {
                        if (features[9] <= 0.014355520) {
                            if (features[7] <= 0.022765803) {
                                result[1] = 0.058823529411764705;

                                result[3] = 0.9411764705882353;

                                return 255;
                            } else {
                                result[1] = 0.1724137931034483;

                                result[3] = 0.06896551724137931;

                                result[4] = 0.7586206896551724;

                                return 255;

                            }
                        } else {
                            return 4;

                        }

                    }

                }

            }

        }
    } else {
        if (features[4] <= -0.062831333) {
            if (features[5] <= 0.102647319) {
                if (features[2] <= 0.385904104) {
                    if (features[8] <= -0.150344640) {
                        result[0] = 0.7142857142857143;

                        result[4] = 0.2857142857142857;

                        return 255;
                    } else {
                        return 0;

                    }
                } else {
                    return 4;

                }
            } else {
                if (features[9] <= 0.067781575) {
                    result[0] = 0.4;

                    result[1] = 0.6;

                    return 255;
                } else {
                    return 1;

                }

            }
        } else {
            if (features[2] <= 0.048440130) {
                if (features[3] <= -0.139370486) {
                    if (features[8] <= -0.022255779) {
                        result[0] = 0.1;

                        result[4] = 0.9;

                        return 255;
                    } else {
                        if (features[6] <= 0.100728650) {
                            return 0;
                        } else {
                            result[0] = 0.8888888888888888;

                            result[1] = 0.1111111111111111;

                            return 255;

                        }

                    }
                } else {
                    if (features[5] <= 0.065890165) {
                        if (features[4] <= -0.009441643) {
                            result[0] = 0.3076923076923077;

                            result[1] = 0.23076923076923078;

                            result[2] = 0.15384615384615385;

                            result[4] = 0.3076923076923077;

                            return 255;
                        } else {
                            if (features[5] <= -0.052255146) {
                                result[2] = 0.36363636363636365;

                                result[4] = 0.6363636363636364;

                                return 255;
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        if (features[8] <= -0.020883741) {
                            return 3;
                        } else {
                            result[3] = 0.75;

                            result[4] = 0.25;

                            return 255;

                        }

                    }

                }
            } else {
                if (features[8] <= 0.271582887) {
                    return 4;
                } else {
                    result[2] = 0.38461538461538464;

                    result[4] = 0.6153846153846154;

                    return 255;

                }

            }

        }

    }
}

unsigned char tree4(float* features, float* result){
    if (features[8] <= -0.066691607) {
        if (features[6] <= 0.011943348) {
            if (features[0] <= 0.033701308) {
                if (features[4] <= 0.003401204) {
                    if (features[5] <= 0.175120570) {
                        result[0] = 0.1;

                        result[2] = 0.8;

                        result[3] = 0.1;

                        return 255;
                    } else {
                        return 3;

                    }
                } else {
                    if (features[7] <= -0.084442671) {
                        result[1] = 0.5384615384615384;

                        result[4] = 0.46153846153846156;

                        return 255;
                    } else {
                        return 1;

                    }

                }
            } else {
                if (features[4] <= -0.063477078) {
                    if (features[5] <= -0.027169642) {
                        return 0;
                    } else {
                        result[0] = 0.25;

                        result[4] = 0.75;

                        return 255;

                    }
                } else {
                    return 4;

                }

            }
        } else {
            if (features[7] <= 0.047069842) {
                if (features[1] <= 0.211884543) {
                    if (features[5] <= 0.156537876) {
                        if (features[4] <= 0.023581686) {
                            if (features[1] <= -0.025114201) {
                                result[3] = 0.9;

                                result[4] = 0.1;

                                return 255;
                            } else {
                                return 3;

                            }
                        } else {
                            result[3] = 0.8421052631578947;

                            result[4] = 0.15789473684210525;

                            return 255;

                        }
                    } else {
                        if (features[9] <= -0.036717403) {
                            return 3;
                        } else {
                            result[3] = 0.3888888888888889;

                            result[4] = 0.6111111111111112;

                            return 255;

                        }

                    }
                } else {
                    result[0] = 0.3181818181818182;

                    result[3] = 0.045454545454545456;

                    result[4] = 0.6363636363636364;

                    return 255;

                }
            } else {
                if (features[8] <= -0.315385416) {
                    if (features[3] <= 0.189766407) {
                        if (features[3] <= -0.088443514) {
                            result[3] = 0.8181818181818182;

                            result[4] = 0.18181818181818182;

                            return 255;
                        } else {
                            return 3;

                        }
                    } else {
                        result[3] = 0.2;

                        result[4] = 0.8;

                        return 255;

                    }
                } else {
                    if (features[5] <= 0.052023323) {
                        result[1] = 0.09090909090909091;

                        result[3] = 0.8181818181818182;

                        result[4] = 0.09090909090909091;

                        return 255;
                    } else {
                        if (features[6] <= 0.261667952) {
                            result[3] = 0.35714285714285715;

                            result[4] = 0.6428571428571429;

                            return 255;
                        } else {
                            if (features[5] <= 0.173172258) {
                                return 4;
                            } else {
                                result[3] = 0.1;

                                result[4] = 0.9;

                                return 255;

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[6] <= 0.048730718) {
            if (features[1] <= 0.058957422) {
                if (features[1] <= -0.129634619) {
                    if (features[3] <= -0.000281305) {
                        result[2] = 0.7142857142857143;

                        result[3] = 0.21428571428571427;

                        result[4] = 0.07142857142857142;

                        return 255;
                    } else {
                        if (features[1] <= -0.165025212) {
                            return 1;
                        } else {
                            result[1] = 0.875;

                            result[2] = 0.08333333333333333;

                            result[3] = 0.041666666666666664;

                            return 255;

                        }

                    }
                } else {
                    if (features[8] <= 0.047672631) {
                        if (features[0] <= -0.010827277) {
                            if (features[5] <= 0.028435792) {
                                result[0] = 0.08522727272727272;

                                result[1] = 0.6818181818181818;

                                result[2] = 0.18181818181818182;

                                result[3] = 0.05113636363636364;

                                return 255;
                            } else {
                                result[2] = 0.24444444444444444;

                                result[3] = 0.6222222222222222;

                                result[4] = 0.13333333333333333;

                                return 255;

                            }
                        } else {
                            if (features[3] <= -0.010059489) {
                                result[0] = 0.5231788079470199;

                                result[1] = 0.11920529801324503;

                                result[2] = 0.10596026490066225;

                                result[3] = 0.24503311258278146;

                                result[4] = 0.006622516556291391;

                                return 255;
                            } else {
                                result[0] = 0.09239130434782608;

                                result[1] = 0.07336956521739131;

                                result[2] = 0.4483695652173913;

                                result[3] = 0.35054347826086957;

                                result[4] = 0.035326086956521736;

                                return 255;

                            }

                        }
                    } else {
                        if (features[3] <= 0.120178934) {
                            if (features[0] <= 0.031886272) {
                                result[1] = 0.009876543209876543;

                                result[2] = 0.980246913580247;

                                result[3] = 0.0024691358024691358;

                                result[4] = 0.007407407407407408;

                                return 255;
                            } else {
                                result[0] = 0.3076923076923077;

                                result[2] = 0.6153846153846154;

                                result[3] = 0.07692307692307693;

                                return 255;

                            }
                        } else {
                            if (features[7] <= 0.028492871) {
                                result[1] = 0.9166666666666666;

                                result[2] = 0.08333333333333333;

                                return 255;
                            } else {
                                return 2;

                            }

                        }

                    }

                }
            } else {
                if (features[3] <= 0.002846752) {
                    if (features[8] <= -0.016268236) {
                        if (features[4] <= -0.041853940) {
                            return 0;
                        } else {
                            if (features[2] <= -0.040636504) {
                                return 0;
                            } else {
                                result[0] = 0.045454545454545456;

                                result[4] = 0.9545454545454546;

                                return 255;

                            }

                        }
                    } else {
                        if (features[1] <= 0.120799650) {
                            if (features[8] <= 0.052249391) {
                                return 0;
                            } else {
                                result[0] = 0.5333333333333333;

                                result[2] = 0.4666666666666667;

                                return 255;

                            }
                        } else {
                            if (features[0] <= 0.144473672) {
                                return 0;
                            } else {
                                result[0] = 0.925;

                                result[4] = 0.075;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[0] <= 0.048443213) {
                        if (features[8] <= 0.161827132) {
                            result[2] = 0.3;

                            result[3] = 0.6;

                            result[4] = 0.1;

                            return 255;
                        } else {
                            return 2;

                        }
                    } else {
                        if (features[5] <= -0.027026918) {
                            if (features[3] <= 0.243938394) {
                                result[0] = 0.2;

                                result[2] = 0.3;

                                result[4] = 0.5;

                                return 255;
                            } else {
                                return 4;

                            }
                        } else {
                            return 4;

                        }

                    }

                }

            }
        } else {
            if (features[0] <= -0.022993209) {
                if (features[5] <= 0.138921462) {
                    if (features[2] <= 0.003375768) {
                        if (features[7] <= 0.081000295) {
                            if (features[3] <= 0.001974233) {
                                result[1] = 0.25;

                                result[2] = 0.1875;

                                result[3] = 0.5625;

                                return 255;
                            } else {
                                return 1;

                            }
                        } else {
                            if (features[8] <= 0.061636673) {
                                result[0] = 0.8947368421052632;

                                result[2] = 0.05263157894736842;

                                result[3] = 0.02631578947368421;

                                result[4] = 0.02631578947368421;

                                return 255;
                            } else {
                                result[0] = 0.4339622641509434;

                                result[1] = 0.5660377358490566;

                                return 255;

                            }

                        }
                    } else {
                        if (features[6] <= 0.091241207) {
                            result[0] = 0.5;

                            result[1] = 0.5;

                            return 255;
                        } else {
                            if (features[7] <= 0.192900605) {
                                return 0;
                            } else {
                                result[0] = 0.7272727272727273;

                                result[1] = 0.18181818181818182;

                                result[4] = 0.09090909090909091;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[3] <= -0.059369592) {
                        return 4;
                    } else {
                        result[0] = 0.5333333333333333;

                        result[3] = 0.3333333333333333;

                        result[4] = 0.13333333333333333;

                        return 255;

                    }

                }
            } else {
                if (features[4] <= -0.009917554) {
                    if (features[3] <= -0.055521527) {
                        if (features[7] <= 0.071954582) {
                            if (features[6] <= 0.144552357) {
                                return 0;
                            } else {
                                result[0] = 0.16666666666666666;

                                result[1] = 0.8333333333333334;

                                return 255;

                            }
                        } else {
                            if (features[1] <= -0.026820528) {
                                return 4;
                            } else {
                                result[0] = 0.08900523560209424;

                                result[1] = 0.9109947643979057;

                                return 255;

                            }

                        }
                    } else {
                        if (features[5] <= 0.060291523) {
                            if (features[4] <= -0.014196240) {
                                return 1;
                            } else {
                                result[0] = 0.5;

                                result[1] = 0.4;

                                result[3] = 0.1;

                                return 255;

                            }
                        } else {
                            if (features[7] <= 0.021200684) {
                                result[3] = 0.8333333333333334;

                                result[4] = 0.16666666666666666;

                                return 255;
                            } else {
                                return 4;

                            }

                        }

                    }
                } else {
                    if (features[5] <= 0.021986448) {
                        if (features[0] <= 0.074339444) {
                            if (features[8] <= 0.002970974) {
                                result[0] = 0.14285714285714285;

                                result[1] = 0.07142857142857142;

                                result[3] = 0.7857142857142857;

                                return 255;
                            } else {
                                result[0] = 0.6206896551724138;

                                result[1] = 0.3448275862068966;

                                result[2] = 0.034482758620689655;

                                return 255;

                            }
                        } else {
                            return 4;

                        }
                    } else {
                        if (features[7] <= 0.043721354) {
                            if (features[9] <= -0.020200665) {
                                return 3;
                            } else {
                                result[3] = 0.1791044776119403;

                                result[4] = 0.8208955223880597;

                                return 255;

                            }
                        } else {
                            return 4;

                        }

                    }

                }

            }

        }

    }
}

unsigned char tree5(float* features, float* result){
    if (features[0] <= 0.065098505) {
        if (features[5] <= 0.053751228) {
            if (features[9] <= 0.020702804) {
                if (features[3] <= 0.181624778) {
                    if (features[8] <= -0.087120783) {
                        if (features[1] <= 0.265055507) {
                            if (features[6] <= 0.051398691) {
                                result[1] = 0.8888888888888888;

                                result[3] = 0.1111111111111111;

                                return 255;
                            } else {
                                return 3;

                            }
                        } else {
                            return 0;

                        }
                    } else {
                        if (features[8] <= 0.154178984) {
                            if (features[3] <= -0.123578679) {
                                result[0] = 0.8022598870056498;

                                result[1] = 0.1807909604519774;

                                result[2] = 0.011299435028248588;

                                result[3] = 0.005649717514124294;

                                return 255;
                            } else {
                                result[0] = 0.24826629680998613;

                                result[1] = 0.3550624133148405;

                                result[2] = 0.1608876560332871;

                                result[3] = 0.1914008321775312;

                                result[4] = 0.044382801664355064;

                                return 255;

                            }
                        } else {
                            if (features[3] <= -0.074966930) {
                                result[0] = 0.625;

                                result[2] = 0.375;

                                return 255;
                            } else {
                                return 2;

                            }

                        }

                    }
                } else {
                    if (features[6] <= 0.160092995) {
                        if (features[7] <= -0.132880613) {
                            result[1] = 0.9090909090909091;

                            result[4] = 0.09090909090909091;

                            return 255;
                        } else {
                            return 1;

                        }
                    } else {
                        result[0] = 0.75;

                        result[1] = 0.25;

                        return 255;

                    }

                }
            } else {
                if (features[4] <= 0.028058344) {
                    if (features[6] <= 0.018053759) {
                        if (features[9] <= 0.025212007) {
                            if (features[7] <= 0.016524508) {
                                result[0] = 0.18181818181818182;

                                result[2] = 0.2727272727272727;

                                result[3] = 0.5454545454545454;

                                return 255;
                            } else {
                                return 2;

                            }
                        } else {
                            if (features[0] <= 0.036127044) {
                                result[2] = 0.9926829268292683;

                                result[4] = 0.007317073170731708;

                                return 255;
                            } else {
                                result[0] = 0.3333333333333333;

                                result[2] = 0.5555555555555556;

                                result[4] = 0.1111111111111111;

                                return 255;

                            }

                        }
                    } else {
                        if (features[4] <= -0.036692832) {
                            if (features[1] <= -0.033160892) {
                                result[1] = 0.47368421052631576;

                                result[2] = 0.3684210526315789;

                                result[3] = 0.15789473684210525;

                                return 255;
                            } else {
                                return 0;

                            }
                        } else {
                            if (features[0] <= -0.006219687) {
                                result[1] = 0.018867924528301886;

                                result[2] = 0.7735849056603774;

                                result[3] = 0.20754716981132076;

                                return 255;
                            } else {
                                result[0] = 0.06;

                                result[2] = 0.18;

                                result[3] = 0.76;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[0] <= -0.009271227) {
                        if (features[6] <= -0.196243353) {
                            result[1] = 0.8;

                            result[2] = 0.2;

                            return 255;
                        } else {
                            return 1;

                        }
                    } else {
                        return 2;

                    }

                }

            }
        } else {
            if (features[8] <= -0.005122331) {
                if (features[7] <= 0.050585339) {
                    if (features[9] <= 0.045435550) {
                        if (features[7] <= 0.023847184) {
                            if (features[7] <= -0.227561422) {
                                result[3] = 0.7857142857142857;

                                result[4] = 0.21428571428571427;

                                return 255;
                            } else {
                                result[0] = 0.0032679738562091504;

                                result[3] = 0.9934640522875817;

                                result[4] = 0.0032679738562091504;

                                return 255;

                            }
                        } else {
                            if (features[4] <= -0.007835173) {
                                return 3;
                            } else {
                                result[3] = 0.42857142857142855;

                                result[4] = 0.5714285714285714;

                                return 255;

                            }

                        }
                    } else {
                        result[3] = 0.3076923076923077;

                        result[4] = 0.6923076923076923;

                        return 255;

                    }
                } else {
                    if (features[0] <= 0.023277437) {
                        if (features[7] <= 0.115933962) {
                            if (features[4] <= -0.023748194) {
                                result[3] = 0.7142857142857143;

                                result[4] = 0.2857142857142857;

                                return 255;
                            } else {
                                result[3] = 0.15384615384615385;

                                result[4] = 0.8461538461538461;

                                return 255;

                            }
                        } else {
                            if (features[9] <= -0.063843958) {
                                result[3] = 0.18181818181818182;

                                result[4] = 0.8181818181818182;

                                return 255;
                            } else {
                                return 4;

                            }

                        }
                    } else {
                        result[3] = 0.8636363636363636;

                        result[4] = 0.13636363636363635;

                        return 255;

                    }

                }
            } else {
                if (features[0] <= -0.036273830) {
                    if (features[6] <= 0.161101311) {
                        if (features[3] <= -0.042826634) {
                            result[0] = 0.6666666666666666;

                            result[3] = 0.2962962962962963;

                            result[4] = 0.037037037037037035;

                            return 255;
                        } else {
                            if (features[5] <= 0.092253912) {
                                result[0] = 0.017857142857142856;

                                result[1] = 0.9642857142857143;

                                result[3] = 0.017857142857142856;

                                return 255;
                            } else {
                                result[0] = 0.9333333333333333;

                                result[3] = 0.06666666666666667;

                                return 255;

                            }

                        }
                    } else {
                        if (features[2] <= -0.054093534) {
                            result[0] = 0.2;

                            result[1] = 0.2;

                            result[4] = 0.6;

                            return 255;
                        } else {
                            if (features[6] <= 0.273556367) {
                                return 0;
                            } else {
                                result[0] = 0.9;

                                result[4] = 0.1;

                                return 255;

                            }

                        }

                    }
                } else {
                    if (features[4] <= -0.031010465) {
                        if (features[1] <= 0.035727908) {
                            result[0] = 0.3125;

                            result[3] = 0.3125;

                            result[4] = 0.375;

                            return 255;
                        } else {
                            if (features[5] <= 0.089315545) {
                                result[0] = 0.4482758620689655;

                                result[1] = 0.5517241379310345;

                                return 255;
                            } else {
                                result[0] = 0.0125;

                                result[1] = 0.975;

                                result[3] = 0.0125;

                                return 255;

                            }

                        }
                    } else {
                        if (features[9] <= -0.005717008) {
                            if (features[5] <= 0.105207223) {
                                result[3] = 0.2;

                                result[4] = 0.8;

                                return 255;
                            } else {
                                return 3;

                            }
                        } else {
                            if (features[5] <= 0.081102736) {
                                result[1] = 0.3157894736842105;

                                result[4] = 0.6842105263157895;

                                return 255;
                            } else {
                                return 4;

                            }

                        }

                    }

                }

            }

        }
    } else {
        if (features[4] <= -0.067076534) {
            if (features[7] <= -0.093981393) {
                result[0] = 0.058823529411764705;

                result[4] = 0.9411764705882353;

                return 255;
            } else {
                if (features[5] <= 0.111090232) {
                    if (features[8] <= -0.130693227) {
                        result[0] = 0.8333333333333334;

                        result[4] = 0.16666666666666666;

                        return 255;
                    } else {
                        return 0;

                    }
                } else {
                    result[0] = 0.17647058823529413;

                    result[1] = 0.8235294117647058;

                    return 255;

                }

            }
        } else {
            if (features[2] <= 0.044194153) {
                if (features[4] <= 0.011054454) {
                    if (features[8] <= 0.002230933) {
                        if (features[5] <= 0.006276112) {
                            result[0] = 0.3333333333333333;

                            result[4] = 0.6666666666666666;

                            return 255;
                        } else {
                            result[0] = 0.09090909090909091;

                            result[3] = 0.8181818181818182;

                            result[4] = 0.09090909090909091;

                            return 255;

                        }
                    } else {
                        if (features[2] <= 0.013971142) {
                            return 0;
                        } else {
                            result[0] = 0.5384615384615384;

                            result[2] = 0.15384615384615385;

                            result[4] = 0.3076923076923077;

                            return 255;

                        }

                    }
                } else {
                    if (features[1] <= 0.013476949) {
                        result[2] = 0.2;

                        result[3] = 0.1;

                        result[4] = 0.7;

                        return 255;
                    } else {
                        return 4;

                    }

                }
            } else {
                if (features[9] <= 0.028191977) {
                    return 4;
                } else {
                    result[2] = 0.18181818181818182;

                    result[4] = 0.8181818181818182;

                    return 255;

                }

            }

        }

    }
}

void eval_forest1(short* args, float *result) {
result[0] = 0.0;
result[1] = 0.0;
result[2] = 0.0;
result[3] = 0.0;
result[4] = 0.0;
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char return_res = 0;
return_res = tree0(args, tree_res);
if (return_res == 255) {
result[0] += tree_res[0] / 3.0;
result[1] += tree_res[1] / 3.0;
result[2] += tree_res[2] / 3.0;
result[3] += tree_res[3] / 3.0;
result[4] += tree_res[4] / 3.0;
} else {
result[return_res] += 1.0 / 3.0;
}
return_res = tree1(args, tree_res);
if (return_res == 255) {
result[0] += tree_res[0] / 3.0;
result[1] += tree_res[1] / 3.0;
result[2] += tree_res[2] / 3.0;
result[3] += tree_res[3] / 3.0;
result[4] += tree_res[4] / 3.0;
} else {
result[return_res] += 1.0 / 3.0;
}
return_res = tree2(args, tree_res);
if (return_res == 255) {
result[0] += tree_res[0] / 3.0;
result[1] += tree_res[1] / 3.0;
result[2] += tree_res[2] / 3.0;
result[3] += tree_res[3] / 3.0;
result[4] += tree_res[4] / 3.0;
} else {
result[return_res] += 1.0 / 3.0;
}
}
void eval_forest2(float * args, float  *result) {
result[0] = 0.0;
result[1] = 0.0;
result[2] = 0.0;
result[3] = 0.0;
result[4] = 0.0;
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char return_res = 0;
return_res = tree3(args, tree_res);
if (return_res == 255) {
result[0] += tree_res[0] / 3.0;
result[1] += tree_res[1] / 3.0;
result[2] += tree_res[2] / 3.0;
result[3] += tree_res[3] / 3.0;
result[4] += tree_res[4] / 3.0;
} else {
result[return_res] += 1.0 / 3.0;
}
return_res = tree4(args, tree_res);
if (return_res == 255) {
result[0] += tree_res[0] / 3.0;
result[1] += tree_res[1] / 3.0;
result[2] += tree_res[2] / 3.0;
result[3] += tree_res[3] / 3.0;
result[4] += tree_res[4] / 3.0;
} else {
result[return_res] += 1.0 / 3.0;
}
return_res = tree5(args, tree_res);
if (return_res == 255) {
result[0] += tree_res[0] / 3.0;
result[1] += tree_res[1] / 3.0;
result[2] += tree_res[2] / 3.0;
result[3] += tree_res[3] / 3.0;
result[4] += tree_res[4] / 3.0;
} else {
result[return_res] += 1.0 / 3.0;
}
}
unsigned char evaluate_forest(float* float_args, short* int_args) {
float tree_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
float total_res[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
unsigned char result_map[5] = { 1, 2, 3, 4, 9 };
eval_forest1(int_args, tree_res);
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
eval_forest2(float_args, tree_res);
total_res[0] += tree_res[0];
total_res[1] += tree_res[1];
total_res[2] += tree_res[2];
total_res[3] += tree_res[3];
total_res[4] += tree_res[4];
unsigned char max_index = 0;
float max_value = 0;
for (unsigned char i = 0; i < 5; ++i) {
if (max_value < total_res[i]) {
max_value = total_res[i];
max_index = i;
}
}
return result_map[max_index];
}
